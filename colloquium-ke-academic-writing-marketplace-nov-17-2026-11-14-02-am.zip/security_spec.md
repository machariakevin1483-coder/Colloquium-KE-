# Colloquium KE — Firestore Security Specification

## 1. Core Security Invariants
1. **Strict Authentication & Ownership**: No unauthenticated reads or writes on `users`, `orders`, `orderPrivate`, `messages`, `withdrawals`, `reports`, or `settings/escrow`.
2. **Admin Exclusivity**: Admin access is granted ONLY when `request.auth.token.email == "machariakevin1483@gmail.com" && request.auth.token.email_verified == true` (or a pre-existing `users/{uid}.role == "admin"` set exclusively by that verified admin). No user can create or update `role: "admin"` or `isApproved: true` or `isVerified: true` on their own user profile.
3. **Zero PII Exposure**:
   - `users/{userId}` is readable ONLY by `request.auth.uid == userId` or `isAdmin()`.
   - `orderPrivate/{orderId}` (client full name, email, phone, M-Pesa screenshots) is readable ONLY by `order.clientId == request.auth.uid` or `isAdmin()`. Workers NEVER have read/list access.
   - `settings/escrow` (Paybill 247247 / Account 7770187709) is readable ONLY by authenticated Clients (`role == 'client'`) or Admin (`isAdmin()`). Workers and unauthenticated guests are explicitly denied.
4. **Role-Enforced Order State Machine**:
   - Clients can create orders (`status == 'Pending Payment'`) with `clientId == request.auth.uid` and valid positive pricing splits (`depositAmount >= 0`, `totalAmount > 0`).
   - Clients can update their own order ONLY for: uploading 25% deposit proof (`Pending Payment -> Paid`), paying 75% balance (`Completed`), adjusting delivery time (`deliveryHours`/`deadline`), rating worker (`Completed`/`Paid to Writer`), or blocking/unblocking chat.
   - Approved Workers (`isApproved == true`, not suspended) can read `Confirmed` jobs or jobs assigned to them, claim a `Confirmed` job (`Confirmed -> In Progress`, setting `assignedWorkerId = request.auth.uid`), submit completed work (`In Progress -> Completed`), or block/unblock chat on their assigned job.
   - Only Admin can confirm deposits (`Paid -> Confirmed`), manually assign/mark progress/completed, release 65% payouts (`Completed -> Paid to Writer`), approve/verify/suspend/unban users, manage reports, delete chat messages, and modify settings.
5. **Bounded Data & Strict Types**: Every string, array, and numeric field is type-checked and bounded in length/size (`size()` checks) to prevent abuse and document bloat.

## 2. Adversarial Test Vectors ("Dirty Dozen")
1. **Unauthenticated read/write**: Unauthenticated client attempts `getDoc(users/uid)`, `list(orders)`, `create(orders)` -> MUST FAIL (`PERMISSION_DENIED`).
2. **Self-elevation to Admin on signup**: Authenticated user creates `users/{myUid}` with `{ role: 'admin' }` -> MUST FAIL.
3. **Self-approval as Worker on signup**: Authenticated worker creates `users/{myUid}` with `{ role: 'worker', isApproved: true }` -> MUST FAIL.
4. **Privilege escalation on profile update**: Authenticated user updates `users/{myUid}` changing `role`, `isApproved`, `isSuspended`, or `isVerified` -> MUST FAIL.
5. **Cross-user PII snooping**: Worker A attempts `getDoc(users/clientUid)` or `getDoc(orderPrivate/orderId)` -> MUST FAIL.
6. **Worker reading Paybill escrow settings**: Authenticated Worker attempts `getDoc(settings/escrow)` -> MUST FAIL.
7. **Unapproved Worker claiming job**: Worker with `isApproved == false` attempts to claim `orders/CQ-1001` (`Confirmed -> In Progress`) -> MUST FAIL.
8. **Suspended user sending chat message**: User with `isSuspended == true` attempts to create `orders/CQ-1001/messages/m1` -> MUST FAIL.
9. **Sending message in blocked chat**: Participant attempts to create `orders/CQ-1001/messages/m1` when `order.isChatBlocked == true` -> MUST FAIL.
10. **Client forging Admin payment confirmation**: Client updates their own order from `Paid` to `Confirmed` -> MUST FAIL.
11. **Worker forging withdrawal for another worker**: Worker A creates `withdrawals/w1` with `workerId: 'workerB'` -> MUST FAIL.
12. **Client reading other client's orders or reports**: Client A queries `reports` or reads Client B's `orders/{orderB}` -> MUST FAIL.
