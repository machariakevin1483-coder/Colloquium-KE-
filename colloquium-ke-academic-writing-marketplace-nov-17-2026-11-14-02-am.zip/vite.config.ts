import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import {defineConfig, type Plugin} from 'vite';

function devZipDownloadPlugin(): Plugin {
  const artifactDir = path.resolve(
    import.meta.dirname,
    '.aistudio/artifacts/brain/b0885cfb-202d-4888-94d7-2d6e6190a2f1'
  );
  const zipRoutes: Record<string, {filePath: string; downloadName: string}> = {
    '/colloquium-ke-project.zip': {
      filePath: path.join(artifactDir, 'colloquium-ke-active-app.zip'),
      downloadName: 'colloquium-ke-active-app.zip',
    },
    '/colloquium-ke-netlify-dist.zip': {
      filePath: path.join(artifactDir, 'colloquium-ke-dist-build.zip'),
      downloadName: 'colloquium-ke-netlify-dist.zip',
    },
  };

  return {
    name: 'dev-zip-download',
    apply: 'serve',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        const reqPath = (req.url || '').split('?')[0];
        const match = zipRoutes[reqPath];
        if (!match) return next();

        if (!fs.existsSync(match.filePath)) {
          res.statusCode = 404;
          res.end('Archive not found.');
          return;
        }

        const stat = fs.statSync(match.filePath);
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Length', stat.size);
        res.setHeader(
          'Content-Disposition',
          `attachment; filename="${match.downloadName}"`
        );
        fs.createReadStream(match.filePath).pipe(res);
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), devZipDownloadPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
