/**
 * Firestore Security Rules Verification Suite ("Dirty Dozen" & Core Invariants)
 * Reference specification for @firebase/rules-unit-testing against firestore.rules.
 */

export const SECURITY_TEST_SCENARIOS = [
  {
    id: 'DD-01',
    name: 'Unauthenticated user cannot read or write users, orders, orderPrivate, withdrawals, reports, or settings/escrow',
    expected: 'DENY',
  },
  {
    id: 'DD-02',
    name: 'Normal user cannot create profile with role="admin"',
    expected: 'DENY',
  },
  {
    id: 'DD-03',
    name: 'Worker cannot create profile with isApproved=true or isVerified=true',
    expected: 'DENY',
  },
  {
    id: 'DD-04',
    name: 'Authenticated user cannot self-elevate role, isApproved, or clear isSuspended on update',
    expected: 'DENY',
  },
  {
    id: 'DD-05',
    name: 'Worker cannot read other users profiles or orderPrivate client PII/screenshots',
    expected: 'DENY',
  },
  {
    id: 'DD-06',
    name: 'Worker cannot read settings/escrow (Paybill 247247 / Account 7770187709)',
    expected: 'DENY',
  },
  {
    id: 'DD-07',
    name: 'Unapproved worker cannot claim Confirmed orders',
    expected: 'DENY',
  },
  {
    id: 'DD-08',
    name: 'Suspended user cannot send chat messages or create orders',
    expected: 'DENY',
  },
  {
    id: 'DD-09',
    name: 'Participants cannot send messages when order.isChatBlocked == true',
    expected: 'DENY',
  },
  {
    id: 'DD-10',
    name: 'Client cannot forge Admin deposit confirmation (Paid -> Confirmed)',
    expected: 'DENY',
  },
  {
    id: 'DD-11',
    name: 'Worker cannot create withdrawal record for another workerId',
    expected: 'DENY',
  },
  {
    id: 'DD-12',
    name: 'Verified Admin (machariakevin1483@gmail.com) can manage all orders, approve workers, manage reports, and update settings',
    expected: 'ALLOW',
  },
];
