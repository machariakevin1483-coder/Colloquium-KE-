/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { OrderProvider, useOrders } from './context/OrderContext';
import { Navbar } from './components/Navbar';
import { OnboardingLanding } from './components/OnboardingLanding';
import { HomeOrderForm } from './components/HomeOrderForm';
import { ClientRegister } from './components/ClientRegister';
import { WorkerRegister } from './components/WorkerRegister';
import { LoginPage } from './components/LoginPage';
import { CheckoutPage } from './components/CheckoutPage';
import { ClientDashboard } from './components/ClientDashboard';
import { WriterDashboard } from './components/WriterDashboard';
import { AdminPortal } from './components/AdminPortal';
import { DownloadAppPage } from './components/DownloadAppPage';
import { ColloquiumLogoIcon } from './components/ColloquiumLogoIcon';
import { ShieldCheck, Download, Loader2 } from 'lucide-react';

function AppContent() {
  const getInitialPath = (): string => {
    if (typeof window === 'undefined') return '/';
    if (window.location.hash && window.location.hash.startsWith('#/')) {
      return window.location.hash.slice(1);
    }
    return window.location.pathname || '/';
  };

  const [currentPath, setCurrentPath] = useState<string>(getInitialPath);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const { userRole, currentUser, authLoading } = useOrders();

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(getInitialPath());
    };
    window.addEventListener('popstate', handlePopState);
    window.addEventListener('hashchange', handlePopState);

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    const handleAppInstalled = () => {
      setDeferredPrompt(null);
    };
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('hashchange', handlePopState);
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const navigate = (path: string) => {
    try {
      window.history.pushState(null, '', path);
    } catch {
      window.location.hash = path;
    }
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const triggerPwaInstall = async () => {
    if (deferredPrompt && typeof deferredPrompt.prompt === 'function') {
      await deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice?.outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    } else {
      navigate('/download');
    }
  };

  // Route Dispatcher
  const renderRoute = () => {
    const isProtectedRoute =
      currentPath === '/admin' ||
      currentPath.startsWith('/admin/') ||
      currentPath === '/client/dashboard' ||
      currentPath === '/client' ||
      currentPath === '/worker/dashboard' ||
      currentPath === '/worker' ||
      currentPath.startsWith('/checkout/');

    if (authLoading && isProtectedRoute) {
      return (
        <div className="min-h-[60vh] flex flex-col items-center justify-center gap-3 text-slate-600">
          <Loader2 className="w-8 h-8 text-[#0E7A4C] animate-spin" />
          <p className="text-xs font-semibold">Restoring your verified session...</p>
        </div>
      );
    }

    // 1. Download App: /download
    if (currentPath === '/download') {
      return (
        <DownloadAppPage
          navigate={navigate}
          deferredPrompt={deferredPrompt}
          triggerPwaInstall={triggerPwaInstall}
        />
      );
    }

    // 2. Checkout: /checkout/[id]
    if (currentPath.startsWith('/checkout/')) {
      const orderId = currentPath.replace('/checkout/', '').split('/')[0].split('?')[0];
      return <CheckoutPage orderId={orderId} navigate={navigate} />;
    }

    // 3. Client registration: /client/register
    if (currentPath === '/client/register') {
      return <ClientRegister navigate={navigate} />;
    }

    // 4. Worker registration: /worker/register
    if (currentPath === '/worker/register') {
      return <WorkerRegister navigate={navigate} />;
    }

    // 6. Login routes: /login and /admin/login both route to standard LoginPage
    if (currentPath === '/login' || currentPath === '/admin/login') {
      return <LoginPage navigate={navigate} />;
    }

    // 7. Admin Portal: /admin
    if (currentPath === '/admin' || currentPath.startsWith('/admin/')) {
      return <AdminPortal navigate={navigate} />;
    }

    // 8. Client Dashboard: /client/dashboard
    if (currentPath === '/client/dashboard' || currentPath === '/client') {
      if (!currentUser || (userRole !== 'client' && userRole !== 'admin')) {
        return <LoginPage navigate={navigate} />;
      }
      return <ClientDashboard navigate={navigate} />;
    }

    // 9. Worker Dashboard: /worker/dashboard
    if (currentPath === '/worker/dashboard' || currentPath === '/worker') {
      if (!currentUser || (userRole !== 'worker' && userRole !== 'admin')) {
        return <LoginPage navigate={navigate} />;
      }
      return <WriterDashboard navigate={navigate} />;
    }

    // 10. Order Form: /order
    if (currentPath === '/order') {
      return <HomeOrderForm navigate={navigate} />;
    }

    // 11. Default /: Onboarding Landing
    return <OnboardingLanding navigate={navigate} />;
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Navigation Bar */}
      <Navbar
        currentPath={currentPath}
        navigate={navigate}
        deferredPrompt={deferredPrompt}
        triggerPwaInstall={triggerPwaInstall}
      />

      {/* Dynamic Route View */}
      <main className="flex-1">
        {renderRoute()}
      </main>

      {/* Footer (Paybill strictly invisible to public per Requirement 1) */}
      <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 text-xs py-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-slate-800 pb-6">
            <div className="flex items-center gap-2.5 text-white">
              <div className="w-9 h-9 rounded-lg bg-[#0E7A4C] flex items-center justify-center font-bold shadow-inner border border-emerald-700/50">
                <ColloquiumLogoIcon className="w-5 h-5 text-white" strokeWidth={2.2} />
              </div>
              <div>
                <div className="font-extrabold text-base tracking-tight">Colloquium KE</div>
                <div className="text-[11px] text-slate-400">
                  Academic, Digital &amp; Creative Services
                </div>
              </div>
            </div>

            {/* Navigation quick links */}
            <div className="flex flex-wrap items-center gap-4 text-xs font-medium">
              <button
                onClick={() => navigate('/')}
                className={`hover:text-white transition ${currentPath === '/' ? 'text-emerald-400 font-bold' : ''}`}
              >
                Onboarding (/)
              </button>
              <span>·</span>
              <button
                onClick={() => navigate('/order')}
                className={`hover:text-white transition ${currentPath === '/order' ? 'text-emerald-400 font-bold' : ''}`}
              >
                Order Task (/order)
              </button>
              <span>·</span>
              <button
                onClick={() => navigate('/client/dashboard')}
                className={`hover:text-white transition ${currentPath === '/client/dashboard' ? 'text-emerald-400 font-bold' : ''}`}
              >
                Client Portal (/client/dashboard)
              </button>
              <span>·</span>
              <button
                onClick={() => navigate('/worker/dashboard')}
                className={`hover:text-white transition ${currentPath === '/worker/dashboard' ? 'text-emerald-400 font-bold' : ''}`}
              >
                Worker Portal (/worker/dashboard)
              </button>
              <span>·</span>
              <button
                onClick={() => navigate('/download')}
                className={`hover:text-white transition flex items-center gap-1 ${
                  currentPath === '/download' ? 'text-emerald-400 font-bold' : ''
                }`}
              >
                <Download className="w-3 h-3 text-emerald-400" />
                <span>Download App</span>
              </button>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px]">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
              <span>Verified Specialists · Secure Order Management</span>
            </div>
            <div>
              © {new Date().getFullYear()} Colloquium KE. Strict privacy policy &amp; verified marketplace.
            </div>
          </div>
        </div>
      </footer>

      {!isOnline && (
        <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-lg bg-amber-500 px-3 py-1.5 text-xs font-semibold text-white shadow-lg">
          <span className="h-2 w-2 rounded-full bg-white animate-pulse" />
          <span>Offline Mode — Cached shell active</span>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <OrderProvider>
      <AppContent />
    </OrderProvider>
  );
}
