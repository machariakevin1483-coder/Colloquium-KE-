import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useMemo,
  ReactNode,
} from 'react';
import {
  User as FirebaseUser,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signOut,
  sendPasswordResetEmail,
  sendEmailVerification,
  updateProfile,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  writeBatch,
} from 'firebase/firestore';
import {
  auth,
  db,
  googleProvider,
  ADMIN_EMAIL,
  OperationType,
  handleFirestoreError,
  mapFirebaseAuthError,
} from '../firebase';
import {
  Order,
  OrderStatus,
  AppSettings,
  WithdrawalRecord,
  User,
  UserRole,
  JobCategory,
  ServiceType,
  ChatMessage,
  TaskFile,
  ChatReport,
} from '../types';
import {
  DEFAULT_PLATFORM_SETTINGS,
  DEFAULT_ESCROW_SETTINGS,
} from '../data/initialOrders';
import { calculateServicePrice } from '../utils/pricingCalculator';
import { filterContactSharing, BLOCKED_CONTACT_WARNING } from '../utils/contactFilter';

export interface CreateOrderInput {
  topic: string;
  category: JobCategory;
  serviceType: ServiceType;
  serviceTier?: string;
  quantityValue: number;
  quantityUnit: string;
  pages?: number;
  deliveryHours: number;
  deadline: string;
  academicLevel?: any;
  citationStyle?: any;
  instructions: string;
  totalAmount?: number;
  depositAmount?: number;
  balanceAmount?: number;
  workerPayAmount?: number;
  adminProfitAmount?: number;
  files?: TaskFile[];
}

interface AuthActionResult {
  success: boolean;
  user?: User;
  role?: UserRole;
  message?: string;
  needsVerification?: boolean;
}

interface OrderContextType {
  orders: Order[];
  users: User[];
  currentUser: User | null;
  firebaseUser: FirebaseUser | null;
  userRole: UserRole | null;
  authLoading: boolean;
  dataLoading: boolean;
  adminNeedsVerification: boolean;
  pendingOrderDraft: CreateOrderInput | null;
  setPendingOrderDraft: (draft: CreateOrderInput | null) => void;
  settings: AppSettings;
  withdrawals: WithdrawalRecord[];
  wallet: {
    totalEarned: number;
    pendingPayout: number;
    availableBalance: number;
  };
  login: (
    email: string,
    password: string,
    enforceRole?: 'client' | 'worker' | 'admin'
  ) => Promise<AuthActionResult>;
  loginWithGoogle: (enforceRole?: 'client' | 'worker') => Promise<AuthActionResult>;
  sendPasswordReset: (email: string) => Promise<{ success: boolean; message: string }>;
  resendVerificationEmail: () => Promise<{ success: boolean; message: string }>;
  registerClient: (
    data: Omit<User, 'id' | 'role' | 'joinedAt'> & { password: string }
  ) => Promise<AuthActionResult>;
  registerWorker: (
    data: Omit<User, 'id' | 'role' | 'joinedAt'> & { password: string }
  ) => Promise<AuthActionResult>;
  logout: () => Promise<void>;
  verifyWorker: (workerId: string, isVerified: boolean) => Promise<void>;
  approveWorker: (workerId: string, approved: boolean) => Promise<void>;
  createOrder: (input: CreateOrderInput, overrideClient?: User) => Promise<Order>;
  getOrderById: (id: string) => Order | undefined;
  uploadScreenshotAndPay: (
    orderId: string,
    screenshotUrl: string,
    screenshotName: string,
    refCode?: string
  ) => Promise<boolean>;
  payBalance: (
    orderId: string,
    screenshotUrl: string,
    screenshotName: string,
    refCode?: string
  ) => Promise<boolean>;
  editDeliveryTime: (orderId: string, hoursDelta: number) => Promise<void>;
  updateAdminNotes: (orderId: string, notes: string) => Promise<void>;
  updateOrderStatus: (
    orderId: string,
    newStatus: OrderStatus,
    additionalFields?: Partial<Order>
  ) => Promise<void>;
  confirmPaymentByAdmin: (orderId: string) => Promise<void>;
  markInProgress: (orderId: string, workerId?: string) => Promise<void>;
  markCompleted: (
    orderId: string,
    notes?: string,
    documentName?: string,
    docUrl?: string
  ) => Promise<void>;
  payWorker: (orderId: string) => Promise<void>;
  payWriter: (orderId: string) => Promise<void>;
  claimJobByWorker: (orderId: string, workerId: string, workerName: string) => Promise<boolean>;
  submitWorkerSolution: (
    orderId: string,
    notes: string,
    docName: string,
    docUrl?: string
  ) => Promise<boolean>;
  rateWorker: (orderId: string, rating: number, feedback?: string) => Promise<void>;
  sendOrderMessage: (
    orderId: string,
    text: string,
    attachmentName?: string,
    attachmentUrl?: string
  ) => Promise<{ success: boolean; blocked?: boolean; message?: string }>;
  subscribeOrderMessages: (
    orderId: string,
    onUpdate: (messages: ChatMessage[]) => void
  ) => () => void;
  reports: ChatReport[];
  reportChat: (
    orderId: string,
    reason: string,
    details?: string
  ) => Promise<{ success: boolean; message: string }>;
  blockChatConversation: (orderId: string, reason?: string) => Promise<void>;
  unblockChatConversation: (orderId: string) => Promise<void>;
  deleteOrderChat: (orderId: string) => Promise<void>;
  warnUserByAdmin: (userId: string, reportId?: string) => Promise<void>;
  suspendUserByAdmin: (userId: string, reason?: string, reportId?: string) => Promise<void>;
  unbanUserByAdmin: (userId: string) => Promise<void>;
  withdrawEarnings: (
    amount: number,
    mpesaPhone: string
  ) => Promise<{ success: boolean; message: string; ref?: string }>;
  updateSettings: (newSettings: Partial<AppSettings>) => Promise<void>;
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

function formatDisplayName(fullName: string, fallbackSuffix: string): string {
  const parts = fullName.trim().split(/\s+/).filter(Boolean);
  if (parts.length > 1) {
    return `${parts[0]} ${parts[parts.length - 1][0].toUpperCase()}.`;
  }
  return parts[0] ? `${parts[0]} ${fallbackSuffix}` : `User ${fallbackSuffix}`;
}

export const OrderProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userRole, setUserRole] = useState<UserRole | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [dataLoading, setDataLoading] = useState<boolean>(false);
  const [adminNeedsVerification, setAdminNeedsVerification] = useState<boolean>(false);
  const [pendingOrderDraft, setPendingOrderDraft] = useState<CreateOrderInput | null>(null);

  const [platformSettings, setPlatformSettings] = useState(DEFAULT_PLATFORM_SETTINGS);
  const [escrowSettings, setEscrowSettings] = useState<{ paybill: string; account: string }>({
    paybill: '',
    account: '',
  });

  const [rawOrders, setRawOrders] = useState<Order[]>([]);
  const [privateOrdersMap, setPrivateOrdersMap] = useState<Record<string, any>>({});
  const [users, setUsers] = useState<User[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRecord[]>([]);
  const [reports, setReports] = useState<ChatReport[]>([]);

  // Clear legacy demo localStorage keys from previous versions on boot
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const legacyKeys = [
      'colloquium_orders_v3',
      'colloquium_users_v3',
      'colloquium_withdrawals_v3',
      'colloquium_current_user_v3',
      'colloquium_reports_v3',
      'userRole',
      'admin_email',
      'admin_password',
      'admin_configured',
      'paybill',
      'account',
    ];
    legacyKeys.forEach((k) => {
      try {
        localStorage.removeItem(k);
      } catch {
        // ignore storage errors
      }
    });
  }, []);

  // Merge orders with private client/receipt metadata (only present for Client owner & Admin)
  const orders: Order[] = useMemo(() => {
    return rawOrders
      .map((order) => {
        const priv = privateOrdersMap[order.id];
        if (!priv) return order;
        return {
          ...order,
          clientFullName: priv.clientFullName ?? order.clientFullName,
          clientEmail: priv.clientEmail ?? order.clientEmail,
          clientPhone: priv.clientPhone ?? order.clientPhone,
          screenshotUrl: priv.screenshotUrl ?? order.screenshotUrl,
          screenshotName: priv.screenshotName ?? order.screenshotName,
          paymentReference: priv.paymentReference ?? order.paymentReference,
          balanceScreenshotUrl: priv.balanceScreenshotUrl ?? order.balanceScreenshotUrl,
          balanceScreenshotName: priv.balanceScreenshotName ?? order.balanceScreenshotName,
          balancePaymentReference: priv.balancePaymentReference ?? order.balancePaymentReference,
        };
      })
      .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
  }, [rawOrders, privateOrdersMap]);

  const settings: AppSettings = useMemo(() => {
    const canSeeEscrow = userRole === 'client' || userRole === 'admin';
    return {
      ...platformSettings,
      paybill: canSeeEscrow ? escrowSettings.paybill || DEFAULT_ESCROW_SETTINGS.paybill : '',
      account: canSeeEscrow ? escrowSettings.account || DEFAULT_ESCROW_SETTINGS.account : '',
      adminEmail: ADMIN_EMAIL,
    };
  }, [platformSettings, escrowSettings, userRole]);

  // 1. Public platform settings subscription (prices, ratios, APK link — NO Paybill)
  useEffect(() => {
    const unsub = onSnapshot(
      doc(db, 'settings', 'platform'),
      (snap) => {
        if (snap.exists()) {
          const data = snap.data() as Partial<AppSettings>;
          setPlatformSettings({
            businessName: data.businessName || DEFAULT_PLATFORM_SETTINGS.businessName,
            pricePerPage: Number(data.pricePerPage) || DEFAULT_PLATFORM_SETTINGS.pricePerPage,
            depositPercentage: Number(data.depositPercentage) || DEFAULT_PLATFORM_SETTINGS.depositPercentage,
            writerPercentage: Number(data.writerPercentage) || DEFAULT_PLATFORM_SETTINGS.writerPercentage,
            adminPercentage: Number(data.adminPercentage) || DEFAULT_PLATFORM_SETTINGS.adminPercentage,
            appApkLink: data.appApkLink || '',
          });
        }
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, 'settings/platform', false);
      }
    );
    return () => unsub();
  }, []);

  // 2. Firebase Auth state listener + user profile loader
  useEffect(() => {
    let unsubUserDoc: (() => void) | null = null;

    const unsubAuth = onAuthStateChanged(auth, (fbUser) => {
      if (unsubUserDoc) {
        unsubUserDoc();
        unsubUserDoc = null;
      }

      setFirebaseUser(fbUser);

      if (!fbUser) {
        setCurrentUser(null);
        setUserRole(null);
        setAdminNeedsVerification(false);
        setRawOrders([]);
        setPrivateOrdersMap({});
        setUsers([]);
        setWithdrawals([]);
        setReports([]);
        setEscrowSettings({ paybill: '', account: '' });
        setAuthLoading(false);
        return;
      }

      const emailLower = (fbUser.email || '').trim().toLowerCase();
      if (emailLower === ADMIN_EMAIL) {
        if (fbUser.emailVerified) {
          setAdminNeedsVerification(false);
          const adminUser: User = {
            id: fbUser.uid,
            role: 'admin',
            fullName: fbUser.displayName || 'Colloquium KE Administrator',
            displayName: 'Master Administrator',
            email: fbUser.email || ADMIN_EMAIL,
            phone: '+254700000000',
            joinedAt: fbUser.metadata.creationTime || new Date().toISOString(),
          };
          setCurrentUser(adminUser);
          setUserRole('admin');
          setAuthLoading(false);
        } else {
          // Admin email must be verified for Firestore rules
          setAdminNeedsVerification(true);
          setCurrentUser(null);
          setUserRole(null);
          setAuthLoading(false);
        }
        return;
      }

      setAdminNeedsVerification(false);
      // Normal user: subscribe to users/{uid}
      unsubUserDoc = onSnapshot(
        doc(db, 'users', fbUser.uid),
        (snap) => {
          if (snap.exists()) {
            const profile = snap.data() as User;
            setCurrentUser(profile);
            setUserRole(profile.role);
          } else {
            setCurrentUser(null);
            setUserRole(null);
          }
          setAuthLoading(false);
        },
        (err) => {
          handleFirestoreError(err, OperationType.GET, `users/${fbUser.uid}`, false);
          setAuthLoading(false);
        }
      );
    });

    return () => {
      unsubAuth();
      if (unsubUserDoc) unsubUserDoc();
    };
  }, []);

  // 3. Role-scoped real-time Firestore subscriptions
  useEffect(() => {
    if (!firebaseUser || !userRole) {
      setRawOrders([]);
      setPrivateOrdersMap({});
      setUsers([]);
      setWithdrawals([]);
      setReports([]);
      return;
    }

    const unsubs: (() => void)[] = [];
    setDataLoading(true);

    if (userRole === 'admin') {
      // Admin escrow settings
      unsubs.push(
        onSnapshot(
          doc(db, 'settings', 'escrow'),
          (snap) => {
            if (snap.exists()) {
              const d = snap.data();
              setEscrowSettings({
                paybill: d.paybill || DEFAULT_ESCROW_SETTINGS.paybill,
                account: d.account || DEFAULT_ESCROW_SETTINGS.account,
              });
            } else {
              setEscrowSettings({
                paybill: DEFAULT_ESCROW_SETTINGS.paybill,
                account: DEFAULT_ESCROW_SETTINGS.account,
              });
            }
          },
          (err) => handleFirestoreError(err, OperationType.GET, 'settings/escrow', false)
        )
      );

      // All orders
      unsubs.push(
        onSnapshot(
          collection(db, 'orders'),
          (snap) => {
            setRawOrders(snap.docs.map((d) => d.data() as Order));
            setDataLoading(false);
          },
          (err) => {
            handleFirestoreError(err, OperationType.LIST, 'orders', false);
            setDataLoading(false);
          }
        )
      );

      // All private order billing & screenshots
      unsubs.push(
        onSnapshot(
          collection(db, 'orderPrivate'),
          (snap) => {
            const map: Record<string, any> = {};
            snap.docs.forEach((d) => {
              map[d.id] = d.data();
            });
            setPrivateOrdersMap(map);
          },
          (err) => handleFirestoreError(err, OperationType.LIST, 'orderPrivate', false)
        )
      );

      // All users
      unsubs.push(
        onSnapshot(
          collection(db, 'users'),
          (snap) => {
            setUsers(snap.docs.map((d) => d.data() as User));
          },
          (err) => handleFirestoreError(err, OperationType.LIST, 'users', false)
        )
      );

      // All withdrawals
      unsubs.push(
        onSnapshot(
          collection(db, 'withdrawals'),
          (snap) => {
            setWithdrawals(
              snap.docs
                .map((d) => d.data() as WithdrawalRecord)
                .sort((a, b) => (b.createdAtMs || 0) - (a.createdAtMs || 0))
            );
          },
          (err) => handleFirestoreError(err, OperationType.LIST, 'withdrawals', false)
        )
      );

      // All reports
      unsubs.push(
        onSnapshot(
          collection(db, 'reports'),
          (snap) => {
            setReports(
              snap.docs
                .map((d) => d.data() as ChatReport)
                .sort((a, b) => (b.reportedAt || '').localeCompare(a.reportedAt || ''))
            );
          },
          (err) => handleFirestoreError(err, OperationType.LIST, 'reports', false)
        )
      );
    } else if (userRole === 'client') {
      // Client escrow settings (Paybill 247247 / Account)
      unsubs.push(
        onSnapshot(
          doc(db, 'settings', 'escrow'),
          (snap) => {
            if (snap.exists()) {
              const d = snap.data();
              setEscrowSettings({
                paybill: d.paybill || DEFAULT_ESCROW_SETTINGS.paybill,
                account: d.account || DEFAULT_ESCROW_SETTINGS.account,
              });
            } else {
              setEscrowSettings({
                paybill: DEFAULT_ESCROW_SETTINGS.paybill,
                account: DEFAULT_ESCROW_SETTINGS.account,
              });
            }
          },
          (err) => handleFirestoreError(err, OperationType.GET, 'settings/escrow', false)
        )
      );

      // Client's own orders
      unsubs.push(
        onSnapshot(
          query(collection(db, 'orders'), where('clientId', '==', firebaseUser.uid)),
          (snap) => {
            setRawOrders(snap.docs.map((d) => d.data() as Order));
            setDataLoading(false);
          },
          (err) => {
            handleFirestoreError(err, OperationType.LIST, 'orders', false);
            setDataLoading(false);
          }
        )
      );

      // Client's own private receipts
      unsubs.push(
        onSnapshot(
          query(collection(db, 'orderPrivate'), where('clientId', '==', firebaseUser.uid)),
          (snap) => {
            const map: Record<string, any> = {};
            snap.docs.forEach((d) => {
              map[d.id] = d.data();
            });
            setPrivateOrdersMap(map);
          },
          (err) => handleFirestoreError(err, OperationType.LIST, 'orderPrivate', false)
        )
      );
    } else if (userRole === 'worker') {
      setEscrowSettings({ paybill: '', account: '' });
      setPrivateOrdersMap({});

      const isApproved = Boolean(
        currentUser?.isApproved === true &&
          currentUser?.isSuspended !== true &&
          currentUser?.isBlockedByAdmin !== true
      );

      if (!isApproved) {
        setRawOrders([]);
        setWithdrawals([]);
        setDataLoading(false);
      } else {
        let confirmedDocs: Order[] = [];
        let assignedDocs: Order[] = [];

        const mergeWorkerOrders = () => {
          const map = new Map<string, Order>();
          confirmedDocs.forEach((o) => map.set(o.id, o));
          assignedDocs.forEach((o) => map.set(o.id, o));
          setRawOrders(Array.from(map.values()));
          setDataLoading(false);
        };

        unsubs.push(
          onSnapshot(
            query(collection(db, 'orders'), where('status', '==', 'Confirmed')),
            (snap) => {
              confirmedDocs = snap.docs.map((d) => d.data() as Order);
              mergeWorkerOrders();
            },
            (err) => {
              handleFirestoreError(err, OperationType.LIST, 'orders(Confirmed)', false);
              setDataLoading(false);
            }
          )
        );

        unsubs.push(
          onSnapshot(
            query(collection(db, 'orders'), where('assignedWorkerId', '==', firebaseUser.uid)),
            (snap) => {
              assignedDocs = snap.docs.map((d) => d.data() as Order);
              mergeWorkerOrders();
            },
            (err) => {
              handleFirestoreError(err, OperationType.LIST, 'orders(assigned)', false);
              setDataLoading(false);
            }
          )
        );

        unsubs.push(
          onSnapshot(
            query(collection(db, 'withdrawals'), where('workerId', '==', firebaseUser.uid)),
            (snap) => {
              setWithdrawals(
                snap.docs
                  .map((d) => d.data() as WithdrawalRecord)
                  .sort((a, b) => (b.createdAtMs || 0) - (a.createdAtMs || 0))
              );
            },
            (err) => handleFirestoreError(err, OperationType.LIST, 'withdrawals', false)
          )
        );
      }
    }

    return () => {
      unsubs.forEach((u) => u());
    };
  }, [firebaseUser, userRole, currentUser?.isApproved, currentUser?.isSuspended, currentUser?.isBlockedByAdmin]);

  // Wallet computation strictly for logged-in worker
  const activeWorkerId = currentUser?.role === 'worker' ? currentUser.id : '';
  const workerJobs = activeWorkerId
    ? orders.filter((o) => o.assignedWorkerId === activeWorkerId)
    : [];

  const totalEarned = workerJobs
    .filter((o) => o.status === 'Completed' || o.status === 'Paid to Writer')
    .reduce((sum, o) => sum + (o.workerPayAmount || o.writerPayoutAmount || 0), 0);

  const pendingPayout = workerJobs
    .filter((o) => o.status === 'In Progress' || o.status === 'Completed')
    .reduce((sum, o) => sum + (o.workerPayAmount || o.writerPayoutAmount || 0), 0);

  const totalWithdrawn = activeWorkerId
    ? withdrawals
        .filter((w) => w.workerId === activeWorkerId && w.status === 'Completed')
        .reduce((sum, w) => sum + w.amount, 0)
    : 0;

  const availableBalance = Math.max(0, totalEarned - totalWithdrawn);

  // =========================================================
  // AUTH ACTIONS
  // =========================================================

  const login = async (
    email: string,
    password: string,
    enforceRole?: 'client' | 'worker' | 'admin'
  ): Promise<AuthActionResult> => {
    const cleanEmail = email.trim().toLowerCase();
    try {
      const cred = await signInWithEmailAndPassword(auth, cleanEmail, password);
      const fbUser = cred.user;
      const loggedEmail = (fbUser.email || cleanEmail).toLowerCase();

      if (loggedEmail === ADMIN_EMAIL) {
        if (!fbUser.emailVerified) {
          await sendEmailVerification(fbUser).catch(() => {});
          setAdminNeedsVerification(true);
          return {
            success: false,
            needsVerification: true,
            message:
              'Admin email verification required. A verification link was sent to machariakevin1483@gmail.com — verify your email or use Continue with Google.',
          };
        }
        const adminUser: User = {
          id: fbUser.uid,
          role: 'admin',
          fullName: fbUser.displayName || 'Colloquium KE Administrator',
          displayName: 'Master Administrator',
          email: loggedEmail,
          phone: '+254700000000',
          joinedAt: fbUser.metadata.creationTime || new Date().toISOString(),
        };
        setCurrentUser(adminUser);
        setUserRole('admin');
        return { success: true, user: adminUser, role: 'admin' };
      }

      const snap = await getDoc(doc(db, 'users', fbUser.uid));
      if (!snap.exists()) {
        await signOut(auth);
        return {
          success: false,
          message: 'Account profile incomplete. Please register as a Client or Worker first.',
        };
      }

      const profile = snap.data() as User;
      if (enforceRole && profile.role !== enforceRole) {
        await signOut(auth);
        return {
          success: false,
          message: `This account is registered as a ${profile.role.toUpperCase()}. Please switch to the ${profile.role.toUpperCase()} tab to sign in.`,
        };
      }

      setCurrentUser(profile);
      setUserRole(profile.role);
      return { success: true, user: profile, role: profile.role };
    } catch (err) {
      return { success: false, message: mapFirebaseAuthError(err) };
    }
  };

  const loginWithGoogle = async (
    enforceRole?: 'client' | 'worker'
  ): Promise<AuthActionResult> => {
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      const fbUser = cred.user;
      const loggedEmail = (fbUser.email || '').trim().toLowerCase();

      if (loggedEmail === ADMIN_EMAIL) {
        const adminUser: User = {
          id: fbUser.uid,
          role: 'admin',
          fullName: fbUser.displayName || 'Colloquium KE Administrator',
          displayName: 'Master Administrator',
          email: loggedEmail,
          phone: '+254700000000',
          joinedAt: fbUser.metadata.creationTime || new Date().toISOString(),
        };
        setCurrentUser(adminUser);
        setUserRole('admin');
        return { success: true, user: adminUser, role: 'admin' };
      }

      const userRef = doc(db, 'users', fbUser.uid);
      const snap = await getDoc(userRef);

      if (snap.exists()) {
        const profile = snap.data() as User;
        if (enforceRole && profile.role !== enforceRole) {
          await signOut(auth);
          return {
            success: false,
            message: `This Google account is registered as a ${profile.role.toUpperCase()}. Please switch to the ${profile.role.toUpperCase()} tab to sign in.`,
          };
        }
        setCurrentUser(profile);
        setUserRole(profile.role);
        return { success: true, user: profile, role: profile.role };
      }

      // First-time Google sign-in: never create Admin or bypass Worker application
      if (enforceRole === 'worker') {
        await signOut(auth);
        return {
          success: false,
          message:
            'No specialist profile found for this Google account. Please submit the Worker Application form first.',
        };
      }

      const fullName = fbUser.displayName || loggedEmail.split('@')[0] || 'Client User';
      const newClient: User = {
        id: fbUser.uid,
        role: 'client',
        fullName,
        displayName: formatDisplayName(fullName, 'C.'),
        email: loggedEmail,
        phone: fbUser.phoneNumber || 'Not Provided',
        institution: 'Colloquium Client',
        joinedAt: new Date().toISOString().split('T')[0],
        totalTasksCompleted: 0,
        contactViolationCount: 0,
        isSuspended: false,
        isBlockedByAdmin: false,
      };
      await setDoc(userRef, newClient);
      setCurrentUser(newClient);
      setUserRole('client');
      return { success: true, user: newClient, role: 'client' };
    } catch (err) {
      return { success: false, message: mapFirebaseAuthError(err) };
    }
  };

  const registerClient = async (
    data: Omit<User, 'id' | 'role' | 'joinedAt'> & { password: string }
  ): Promise<AuthActionResult> => {
    const cleanEmail = data.email.trim().toLowerCase();
    if (cleanEmail === ADMIN_EMAIL) {
      return {
        success: false,
        message: 'This email is reserved. Please use Sign In instead.',
      };
    }

    try {
      const cred = await createUserWithEmailAndPassword(auth, cleanEmail, data.password);
      await updateProfile(cred.user, { displayName: data.fullName.trim() }).catch(() => {});
      await sendEmailVerification(cred.user).catch(() => {});

      const newUser: User = {
        id: cred.user.uid,
        role: 'client',
        fullName: data.fullName.trim(),
        displayName: formatDisplayName(data.fullName, 'C.'),
        email: cleanEmail,
        phone: data.phone.trim(),
        institution: data.institution?.trim() || 'Kenyan University',
        joinedAt: new Date().toISOString().split('T')[0],
        totalTasksCompleted: 0,
        contactViolationCount: 0,
        isSuspended: false,
        isBlockedByAdmin: false,
      };

      await setDoc(doc(db, 'users', cred.user.uid), newUser);
      setCurrentUser(newUser);
      setUserRole('client');
      return { success: true, user: newUser, role: 'client' };
    } catch (err) {
      return { success: false, message: mapFirebaseAuthError(err) };
    }
  };

  const registerWorker = async (
    data: Omit<User, 'id' | 'role' | 'joinedAt'> & { password: string }
  ): Promise<AuthActionResult> => {
    const cleanEmail = data.email.trim().toLowerCase();
    if (cleanEmail === ADMIN_EMAIL) {
      return {
        success: false,
        message: 'This email is reserved. Please use Sign In instead.',
      };
    }

    try {
      const cred = await createUserWithEmailAndPassword(auth, cleanEmail, data.password);
      await updateProfile(cred.user, { displayName: data.fullName.trim() }).catch(() => {});
      await sendEmailVerification(cred.user).catch(() => {});

      const newUser: User = {
        id: cred.user.uid,
        role: 'worker',
        fullName: data.fullName.trim(),
        displayName: formatDisplayName(data.fullName, 'M.'),
        email: cleanEmail,
        phone: data.phone.trim(),
        ...(data.idNumber ? { idNumber: data.idNumber.trim() } : {}),
        mpesaFullName: data.mpesaFullName?.trim() || data.fullName.trim(),
        mpesaPhoneNumber: data.mpesaPhoneNumber?.trim() || data.phone.trim(),
        ...(data.bankName ? { bankName: data.bankName.trim() } : {}),
        ...(data.bankAccountNumber ? { bankAccountNumber: data.bankAccountNumber.trim() } : {}),
        ...(data.paypalEmail ? { paypalEmail: data.paypalEmail.trim() } : {}),
        skills: data.skills || [],
        highestEducation: data.highestEducation || "Bachelor's Degree",
        about: data.about?.trim() || '',
        joinedAt: new Date().toISOString().split('T')[0],
        isApproved: false,
        approvalStatus: 'pending',
        isVerified: false,
        rating: 5.0,
        totalTasksCompleted: 0,
        contactViolationCount: 0,
        isSuspended: false,
        isBlockedByAdmin: false,
      };

      await setDoc(doc(db, 'users', cred.user.uid), newUser);
      setCurrentUser(newUser);
      setUserRole('worker');
      return { success: true, user: newUser, role: 'worker' };
    } catch (err) {
      return { success: false, message: mapFirebaseAuthError(err) };
    }
  };

  const sendPasswordReset = async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email.trim().toLowerCase());
      return {
        success: true,
        message: 'Password reset email sent. Check your inbox (and spam folder).',
      };
    } catch (err) {
      return { success: false, message: mapFirebaseAuthError(err) };
    }
  };

  const resendVerificationEmail = async () => {
    if (!auth.currentUser) {
      return { success: false, message: 'No signed-in account found.' };
    }
    try {
      await sendEmailVerification(auth.currentUser);
      return {
        success: true,
        message: `Verification email sent to ${auth.currentUser.email}. Click the link and then sign in again.`,
      };
    } catch (err) {
      return { success: false, message: mapFirebaseAuthError(err) };
    }
  };

  const logout = async () => {
    await signOut(auth);
  };

  // =========================================================
  // ADMIN USER MANAGEMENT
  // =========================================================

  const approveWorker = async (workerId: string, approved: boolean) => {
    try {
      await updateDoc(doc(db, 'users', workerId), {
        isApproved: approved,
        approvalStatus: approved ? 'approved' : 'rejected',
        isVerified: approved,
        updatedAt: new Date().toISOString(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${workerId}`);
    }
  };

  const verifyWorker = async (workerId: string, isVerified: boolean) => {
    try {
      await updateDoc(doc(db, 'users', workerId), {
        isVerified,
        updatedAt: new Date().toISOString(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${workerId}`);
    }
  };

  // =========================================================
  // ORDERS CRUD
  // =========================================================

  const getOrderById = (id: string): Order | undefined => {
    return orders.find((o) => o.id.toLowerCase() === id.toLowerCase());
  };

  const createOrder = async (orderInput: CreateOrderInput, overrideClient?: User): Promise<Order> => {
    const activeClient = overrideClient || currentUser;
    if (!activeClient || !auth.currentUser) {
      throw new Error('You must sign in as a Client before placing an order.');
    }

    let { totalAmount, depositAmount, balanceAmount, workerPayAmount, adminProfitAmount } =
      orderInput;

    if (!totalAmount) {
      const calc = calculateServicePrice({
        serviceType: orderInput.serviceType,
        academicLevel: orderInput.academicLevel,
        deliveryHours: orderInput.deliveryHours,
        pages: orderInput.pages || orderInput.quantityValue,
        slides: orderInput.quantityValue,
        audioMinutes: orderInput.quantityValue,
        imagesCount: orderInput.quantityValue,
        videoMinutes: orderInput.quantityValue,
        tier: (orderInput.serviceTier as any) || 'Basic',
      });
      totalAmount = calc.totalPrice;
      depositAmount = calc.depositAmount;
      balanceAmount = calc.balanceAmount;
      workerPayAmount = calc.workerPay;
      adminProfitAmount = calc.adminProfit;
    } else {
      depositAmount = depositAmount ?? Math.round(totalAmount * 0.25);
      balanceAmount = balanceAmount ?? totalAmount - depositAmount;
      workerPayAmount = workerPayAmount ?? Math.floor(totalAmount * 0.65);
      adminProfitAmount = adminProfitAmount ?? totalAmount - workerPayAmount;
    }

    const nextId = `CQ-${Date.now().toString().slice(-4)}${Math.floor(10 + Math.random() * 89)}`;
    const calculatedPages =
      orderInput.pages || (orderInput.quantityUnit === 'pages' ? orderInput.quantityValue : 1);

    const newOrderDoc: Record<string, any> = {
      id: nextId,
      topic: orderInput.topic,
      category: orderInput.category,
      serviceType: orderInput.serviceType,
      quantityValue: orderInput.quantityValue,
      quantityUnit: orderInput.quantityUnit,
      pages: calculatedPages,
      wordCount: calculatedPages * 275,
      deliveryHours: orderInput.deliveryHours,
      deadline: orderInput.deadline,
      instructions: orderInput.instructions,
      files: (orderInput.files || []).slice(0, 10),
      totalAmount,
      depositAmount,
      balanceAmount,
      workerPayoutAmount: workerPayAmount,
      writerPayoutAmount: workerPayAmount,
      workerPayAmount,
      adminProfitAmount,
      status: 'Pending Payment',
      createdAt: new Date().toISOString(),
      clientId: activeClient.id,
      clientDisplayName: activeClient.displayName || 'Client C.',
      adminNotes: `Task placed. 25% escrow deposit (KES ${depositAmount.toLocaleString()}) pending.`,
    };

    if (orderInput.serviceTier) newOrderDoc.serviceTier = orderInput.serviceTier;
    if (orderInput.academicLevel) newOrderDoc.academicLevel = orderInput.academicLevel;
    if (orderInput.citationStyle) newOrderDoc.citationStyle = orderInput.citationStyle;

    const privateDoc = {
      orderId: nextId,
      clientId: activeClient.id,
      clientFullName: activeClient.fullName,
      clientEmail: activeClient.email,
      clientPhone: activeClient.phone,
    };

    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'orders', nextId), newOrderDoc);
      batch.set(doc(db, 'orderPrivate', nextId), privateDoc);
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `orders/${nextId}`);
    }

    return {
      ...(newOrderDoc as Order),
      clientFullName: activeClient.fullName,
      clientEmail: activeClient.email,
      clientPhone: activeClient.phone,
      messages: [],
    };
  };

  const uploadScreenshotAndPay = async (
    orderId: string,
    screenshotUrl: string,
    screenshotName: string,
    refCode?: string
  ): Promise<boolean> => {
    const existing = getOrderById(orderId);
    if (!existing) return false;

    const now = new Date().toISOString();
    const cleanRef = refCode?.trim() || `MP${Date.now().toString().slice(-6)}`;
    const cleanName = screenshotName || `receipt_${orderId}.jpg`;

    try {
      const batch = writeBatch(db);
      batch.update(doc(db, 'orders', existing.id), {
        status: 'Paid',
        paymentReference: cleanRef,
        paymentUploadedAt: now,
        adminNotes:
          'Client uploaded 25% deposit payment proof. Awaiting admin escrow confirmation.',
      });
      batch.set(
        doc(db, 'orderPrivate', existing.id),
        {
          orderId: existing.id,
          clientId: existing.clientId,
          clientFullName: existing.clientFullName || currentUser?.fullName || 'Client',
          clientEmail: existing.clientEmail || currentUser?.email || 'client@colloquium.ke',
          clientPhone: existing.clientPhone || currentUser?.phone || 'N/A',
          screenshotUrl: screenshotUrl || '',
          screenshotName: cleanName,
          paymentReference: cleanRef,
          paymentUploadedAt: now,
        },
        { merge: true }
      );
      await batch.commit();
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${existing.id}`);
      return false;
    }
  };

  const payBalance = async (
    orderId: string,
    screenshotUrl: string,
    screenshotName: string,
    refCode?: string
  ): Promise<boolean> => {
    const existing = getOrderById(orderId);
    if (!existing) return false;

    const now = new Date().toISOString();
    const cleanRef = refCode?.trim() || `MP${Date.now().toString().slice(-6)}`;
    const cleanName = screenshotName || `balance_receipt_${orderId}.jpg`;

    try {
      const batch = writeBatch(db);
      batch.update(doc(db, 'orders', existing.id), {
        balancePaid: true,
        balancePaymentReference: cleanRef,
        balancePaidAt: now,
        adminNotes: `Client approved work and paid 75% balance (KES ${existing.balanceAmount.toLocaleString()}). Ready for admin release to specialist.`,
      });
      batch.set(
        doc(db, 'orderPrivate', existing.id),
        {
          orderId: existing.id,
          clientId: existing.clientId,
          clientFullName: existing.clientFullName || currentUser?.fullName || 'Client',
          clientEmail: existing.clientEmail || currentUser?.email || 'client@colloquium.ke',
          clientPhone: existing.clientPhone || currentUser?.phone || 'N/A',
          balanceScreenshotUrl: screenshotUrl || '',
          balanceScreenshotName: cleanName,
          balancePaymentReference: cleanRef,
          balancePaidAt: now,
        },
        { merge: true }
      );
      await batch.commit();
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${existing.id}`);
      return false;
    }
  };

  const editDeliveryTime = async (orderId: string, hoursDelta: number) => {
    const existing = getOrderById(orderId);
    if (!existing) return;

    const newHours = Math.max(3, existing.deliveryHours + hoursDelta);
    const currentDeadline = new Date(existing.deadline).getTime();
    const newDeadline = new Date(currentDeadline + hoursDelta * 3600 * 1000).toISOString();

    try {
      await updateDoc(doc(db, 'orders', existing.id), {
        deliveryHours: newHours,
        deadline: newDeadline,
        adminNotes: `${existing.adminNotes ? existing.adminNotes + ' | ' : ''}Delivery time adjusted (${hoursDelta > 0 ? '+' : ''}${hoursDelta}H).`,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${existing.id}`);
    }
  };

  const updateAdminNotes = async (orderId: string, notes: string) => {
    const existing = getOrderById(orderId);
    if (!existing) return;
    try {
      await updateDoc(doc(db, 'orders', existing.id), { adminNotes: notes });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${existing.id}`);
    }
  };

  const updateOrderStatus = async (
    orderId: string,
    newStatus: OrderStatus,
    additionalFields: Partial<Order> = {}
  ) => {
    const existing = getOrderById(orderId);
    const docId = existing?.id || orderId;
    try {
      await updateDoc(doc(db, 'orders', docId), {
        status: newStatus,
        ...additionalFields,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${docId}`);
    }
  };

  const confirmPaymentByAdmin = async (orderId: string) => {
    await updateOrderStatus(orderId, 'Confirmed', {
      adminNotes: '25% escrow deposit confirmed by Admin. Available on Specialist Job Board.',
    });
  };

  const markInProgress = async (orderId: string, workerId?: string) => {
    const worker =
      users.find((u) => u.id === workerId) ||
      users.find((u) => u.role === 'worker' && u.isApproved);
    if (!worker) return;
    const workerName = `${worker.displayName} (★ ${worker.rating || 4.9})`;
    await updateOrderStatus(orderId, 'In Progress', {
      assignedWorkerId: worker.id,
      workerDisplayName: workerName,
      adminNotes: 'Specialist assigned. Drafting in progress.',
    });
  };

  const markCompleted = async (
    orderId: string,
    notes: string = 'Task completed to standard. Plagiarism checked.',
    documentName: string = 'Finished_Task_Solution.docx',
    docUrl?: string
  ) => {
    const payload: Partial<Order> = {
      completedAt: new Date().toISOString(),
      submissionNotes: notes,
      solutionDocumentName: documentName,
      adminNotes: 'Specialist delivered completed solution. Awaiting client review & 75% balance.',
    };
    if (docUrl) {
      payload.solutionDocumentUrl = docUrl;
    }
    await updateOrderStatus(orderId, 'Completed', payload);
  };

  const payWriter = async (orderId: string) => {
    const order = getOrderById(orderId);
    const workerPay = order?.workerPayAmount || order?.writerPayoutAmount || 0;
    const adminProfit = order?.adminProfitAmount || 0;

    await updateOrderStatus(orderId, 'Paid to Writer', {
      workerPaidAt: new Date().toISOString(),
      adminNotes: `Admin released 65% payout (KES ${workerPay.toLocaleString()}) to worker via M-Pesa. Admin profit (35% - KES ${adminProfit.toLocaleString()}) retained.`,
    });
  };

  const payWorker = payWriter;

  const claimJobByWorker = async (
    orderId: string,
    workerId: string,
    workerDisplayName: string
  ): Promise<boolean> => {
    const order = getOrderById(orderId);
    if (!order || order.status !== 'Confirmed') return false;
    await updateOrderStatus(orderId, 'In Progress', {
      assignedWorkerId: workerId,
      workerDisplayName,
      adminNotes: `Specialist ${workerDisplayName} accepted and claimed task.`,
    });
    return true;
  };

  const submitWorkerSolution = async (
    orderId: string,
    notes: string,
    docName: string,
    docUrl?: string
  ): Promise<boolean> => {
    const order = getOrderById(orderId);
    if (!order || order.status !== 'In Progress') return false;
    await markCompleted(orderId, notes, docName, docUrl);
    return true;
  };

  const rateWorker = async (orderId: string, rating: number, feedback?: string) => {
    const existing = getOrderById(orderId);
    if (!existing) return;
    try {
      await updateDoc(doc(db, 'orders', existing.id), {
        clientRating: rating,
        clientFeedback: feedback || '',
        clientRatedAt: new Date().toISOString(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${existing.id}`);
    }
  };

  // =========================================================
  // REAL-TIME CHAT & CONTACT SHIELD
  // =========================================================

  const subscribeOrderMessages = (
    orderId: string,
    onUpdate: (messages: ChatMessage[]) => void
  ) => {
    const q = query(
      collection(db, 'orders', orderId, 'messages'),
      orderBy('createdAtMs', 'asc')
    );
    return onSnapshot(
      q,
      (snap) => {
        onUpdate(snap.docs.map((d) => d.data() as ChatMessage));
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, `orders/${orderId}/messages`, false);
      }
    );
  };

  const sendOrderMessage = async (
    orderId: string,
    text: string,
    attachmentName?: string,
    attachmentUrl?: string
  ): Promise<{ success: boolean; blocked?: boolean; message?: string }> => {
    const order = getOrderById(orderId);
    if (!order) {
      return { success: false, message: 'Order not found.' };
    }

    if (!currentUser || !auth.currentUser) {
      return { success: false, message: 'Please sign in to send messages.' };
    }

    if (currentUser.isSuspended || currentUser.isBlockedByAdmin) {
      return {
        success: false,
        message: 'Your account is suspended due to safety policy violations. Contact admin.',
      };
    }

    if (order.isChatBlocked) {
      return {
        success: false,
        message: `This conversation has been closed or blocked (${order.chatBlockedReason || 'Safety restriction'}).`,
      };
    }

    const allowedStatuses: OrderStatus[] = [
      'In Progress',
      'Completed',
      'Paid to Writer',
      'Confirmed',
    ];
    if (!allowedStatuses.includes(order.status) && userRole !== 'admin') {
      return {
        success: false,
        message:
          'Chat only opens after a task is booked and confirmed. Please complete escrow deposit to activate chat.',
      };
    }

    const trimmedText = text.trim();
    if (!trimmedText && !attachmentName) {
      return { success: false, message: 'Message cannot be empty.' };
    }

    if (trimmedText && userRole !== 'admin') {
      const filterResult = filterContactSharing(trimmedText);
      if (filterResult.isBlocked) {
        const nextCount = (currentUser.contactViolationCount || 0) + 1;
        try {
          await updateDoc(doc(db, 'users', currentUser.id), {
            contactViolationCount: nextCount,
            updatedAt: new Date().toISOString(),
          });

          const newReportId = `REP-${Date.now()}-${Math.floor(100 + Math.random() * 899)}`;
          const autoReport: ChatReport = {
            id: newReportId,
            orderId: order.id,
            orderTopic: order.topic,
            reporterId: 'SYSTEM_FILTER',
            reporterName: 'Automated Contact Shield',
            reporterRole: 'client',
            reportedUserId: currentUser.id,
            reportedUserName: currentUser.displayName || 'User',
            reportedUserRole: userRole === 'worker' ? 'worker' : 'client',
            reason: 'Attempted Contact Sharing',
            details: `Blocked categories: ${filterResult.matchedCategories.join(', ')}. Blocked text preview: ${filterResult.censoredText}`,
            reportedAt: new Date().toISOString(),
            status: 'Pending Review',
            adminNotes: `User attempted to share prohibited contact info. Warning shown, message not sent. Violation #${nextCount}.`,
          };
          await setDoc(doc(db, 'reports', newReportId), autoReport);
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, 'reports', false);
        }

        return {
          success: false,
          blocked: true,
          message: BLOCKED_CONTACT_WARNING,
        };
      }
    }

    const senderRole = userRole || 'client';
    const senderName =
      currentUser.displayName || (senderRole === 'admin' ? 'Admin Support' : 'User');
    const createdAtMs = Date.now();
    const msgId = `msg-${createdAtMs}-${Math.floor(Math.random() * 1000)}`;

    const newMessage: Record<string, any> = {
      id: msgId,
      senderId: currentUser.id,
      senderName,
      senderRole,
      text: trimmedText,
      timestamp: new Date().toLocaleTimeString('en-KE', {
        hour: '2-digit',
        minute: '2-digit',
      }),
      createdAtMs,
    };

    if (attachmentName) newMessage.attachmentName = attachmentName;
    if (attachmentUrl) newMessage.attachmentUrl = attachmentUrl;

    try {
      await setDoc(doc(db, 'orders', order.id, 'messages', msgId), newMessage);
      return { success: true };
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `orders/${order.id}/messages/${msgId}`);
      return { success: false, message: 'Failed to send message.' };
    }
  };

  const reportChat = async (
    orderId: string,
    reason: string,
    details?: string
  ): Promise<{ success: boolean; message: string }> => {
    const order = getOrderById(orderId);
    if (!order || !currentUser) return { success: false, message: 'Order not found.' };

    const isClientReporting = userRole === 'client';
    const reportedUserId = isClientReporting
      ? order.assignedWorkerId || 'UNKNOWN'
      : order.clientId;
    const reportedUserName = isClientReporting
      ? order.workerDisplayName || 'Specialist'
      : order.clientDisplayName;
    const reportedUserRole = isClientReporting ? 'worker' : 'client';

    const reportId = `REP-${Date.now()}-${Math.floor(100 + Math.random() * 899)}`;
    const newReport: ChatReport = {
      id: reportId,
      orderId: order.id,
      orderTopic: order.topic,
      reporterId: currentUser.id,
      reporterName: currentUser.displayName || 'User',
      reporterRole: isClientReporting ? 'client' : 'worker',
      reportedUserId,
      reportedUserName,
      reportedUserRole,
      reason,
      details: details || '',
      reportedAt: new Date().toISOString(),
      status: 'Pending Review',
      adminNotes: 'User submitted chat safety report.',
    };

    try {
      await setDoc(doc(db, 'reports', reportId), newReport);
      return {
        success: true,
        message: 'Report submitted to Colloquium KE Trust & Safety team for immediate review.',
      };
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `reports/${reportId}`);
      return { success: false, message: 'Failed to submit report.' };
    }
  };

  const blockChatConversation = async (
    orderId: string,
    reason: string = 'User blocked conversation'
  ) => {
    const existing = getOrderById(orderId);
    if (!existing) return;
    try {
      await updateDoc(doc(db, 'orders', existing.id), {
        isChatBlocked: true,
        chatBlockedReason: reason,
        chatBlockedByRole: userRole || 'client',
        adminNotes: `${existing.adminNotes ? existing.adminNotes + ' | ' : ''}Chat blocked by ${userRole || 'user'} (${reason}).`,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${existing.id}`);
    }
  };

  const unblockChatConversation = async (orderId: string) => {
    const existing = getOrderById(orderId);
    if (!existing) return;
    try {
      await updateDoc(doc(db, 'orders', existing.id), {
        isChatBlocked: false,
        chatBlockedReason: '',
        chatBlockedByRole: '',
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${existing.id}`);
    }
  };

  const deleteOrderChat = async (orderId: string) => {
    const existing = getOrderById(orderId);
    const docId = existing?.id || orderId;
    try {
      const msgsSnap = await getDocs(collection(db, 'orders', docId, 'messages'));
      const batch = writeBatch(db);
      msgsSnap.docs.forEach((d) => batch.delete(d.ref));
      batch.update(doc(db, 'orders', docId), {
        adminNotes: `${existing?.adminNotes ? existing.adminNotes + ' | ' : ''}Chat history cleared by Administrator.`,
      });
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `orders/${docId}/messages`);
    }
  };

  const warnUserByAdmin = async (userId: string, reportId?: string) => {
    try {
      const userObj = users.find((u) => u.id === userId);
      const nextCount = (userObj?.contactViolationCount || 0) + 1;
      await updateDoc(doc(db, 'users', userId), {
        contactViolationCount: nextCount,
        updatedAt: new Date().toISOString(),
      });
      if (reportId) {
        await updateDoc(doc(db, 'reports', reportId), {
          status: 'Warned',
          adminNotes: 'Admin issued official policy warning.',
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${userId}`);
    }
  };

  const suspendUserByAdmin = async (
    userId: string,
    reason: string = 'Violation of non-contact policy',
    reportId?: string
  ) => {
    try {
      await updateDoc(doc(db, 'users', userId), {
        isSuspended: true,
        isBlockedByAdmin: true,
        suspensionReason: reason,
        updatedAt: new Date().toISOString(),
      });
      if (reportId) {
        await updateDoc(doc(db, 'reports', reportId), {
          status: 'Suspended',
          adminNotes: `Admin suspended user: ${reason}`,
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${userId}`);
    }
  };

  const unbanUserByAdmin = async (userId: string) => {
    try {
      await updateDoc(doc(db, 'users', userId), {
        isSuspended: false,
        isBlockedByAdmin: false,
        suspensionReason: '',
        contactViolationCount: 0,
        updatedAt: new Date().toISOString(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${userId}`);
    }
  };

  // =========================================================
  // WORKER WITHDRAWALS & ADMIN SETTINGS
  // =========================================================

  const withdrawEarnings = async (amount: number, mpesaPhone: string) => {
    if (!currentUser || currentUser.role !== 'worker') {
      return { success: false, message: 'Sign in as an approved specialist to withdraw.' };
    }
    if (amount <= 0) {
      return { success: false, message: 'Amount must be greater than KES 0.' };
    }
    if (amount > availableBalance) {
      return {
        success: false,
        message: `Insufficient balance. Available: KES ${availableBalance.toLocaleString()}`,
      };
    }

    const nowMs = Date.now();
    const id = `W-${nowMs.toString().slice(-6)}`;
    const ref = `WTH${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    const newRecord: WithdrawalRecord = {
      id,
      workerId: currentUser.id,
      workerName: currentUser.fullName,
      amount,
      mpesaNumber: mpesaPhone.trim(),
      date: new Date().toLocaleString('en-KE', { timeZone: 'Africa/Nairobi' }),
      status: 'Completed',
      reference: ref,
      createdAtMs: nowMs,
    };

    try {
      await setDoc(doc(db, 'withdrawals', id), newRecord);
      return {
        success: true,
        message: `KES ${amount.toLocaleString()} withdrawal recorded for ${mpesaPhone} (Ref: ${ref}).`,
        ref,
      };
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `withdrawals/${id}`);
      return { success: false, message: 'Failed to submit withdrawal request.' };
    }
  };

  const updateSettings = async (newSettings: Partial<AppSettings>) => {
    const now = new Date().toISOString();
    const updatedPlatform = {
      businessName: newSettings.businessName ?? platformSettings.businessName,
      pricePerPage: Number(newSettings.pricePerPage ?? platformSettings.pricePerPage),
      depositPercentage: Number(
        newSettings.depositPercentage ?? platformSettings.depositPercentage
      ),
      writerPercentage: Number(newSettings.writerPercentage ?? platformSettings.writerPercentage),
      adminPercentage: Number(newSettings.adminPercentage ?? platformSettings.adminPercentage),
      appApkLink: newSettings.appApkLink ?? platformSettings.appApkLink ?? '',
      updatedAt: now,
    };

    const updatedEscrow = {
      paybill: newSettings.paybill ?? (escrowSettings.paybill || DEFAULT_ESCROW_SETTINGS.paybill),
      account: newSettings.account ?? (escrowSettings.account || DEFAULT_ESCROW_SETTINGS.account),
      businessName: updatedPlatform.businessName,
      updatedAt: now,
    };

    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'settings', 'platform'), updatedPlatform);
      batch.set(doc(db, 'settings', 'escrow'), updatedEscrow);
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'settings');
    }
  };

  return (
    <OrderContext.Provider
      value={{
        orders,
        users,
        currentUser,
        firebaseUser,
        userRole,
        authLoading,
        dataLoading,
        adminNeedsVerification,
        pendingOrderDraft,
        setPendingOrderDraft,
        settings,
        withdrawals,
        wallet: {
          totalEarned,
          pendingPayout,
          availableBalance,
        },
        login,
        loginWithGoogle,
        sendPasswordReset,
        resendVerificationEmail,
        registerClient,
        registerWorker,
        logout,
        verifyWorker,
        approveWorker,
        createOrder,
        getOrderById,
        uploadScreenshotAndPay,
        payBalance,
        editDeliveryTime,
        updateAdminNotes,
        updateOrderStatus,
        confirmPaymentByAdmin,
        markInProgress,
        markCompleted,
        payWorker,
        payWriter,
        claimJobByWorker,
        submitWorkerSolution,
        rateWorker,
        sendOrderMessage,
        subscribeOrderMessages,
        reports,
        reportChat,
        blockChatConversation,
        unblockChatConversation,
        deleteOrderChat,
        warnUserByAdmin,
        suspendUserByAdmin,
        unbanUserByAdmin,
        withdrawEarnings,
        updateSettings,
      }}
    >
      {children}
    </OrderContext.Provider>
  );
};

export const useOrders = (): OrderContextType => {
  const context = useContext(OrderContext);
  if (!context) {
    throw new Error('useOrders must be used within an OrderProvider');
  }
  return context;
};
