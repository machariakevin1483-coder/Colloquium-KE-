export type OrderStatus =
  | 'Pending Payment' // Client placed order, needs to pay 25% Escrow
  | 'Paid' // Client paid 25% Escrow, waiting for Admin confirmation
  | 'Confirmed' // Admin confirmed 25% Escrow, Available for approved Workers to claim
  | 'In Progress' // Worker assigned and working on task
  | 'Completed' // Worker submitted solution, client approved or reviewing
  | 'Paid to Writer'; // Client paid 75% balance & Admin released 65% to Worker

export type UserRole = 'client' | 'worker' | 'admin';

export type ServiceType =
  | 'Academic'
  | 'Proofreading'
  | 'PowerPoint'
  | 'Transcription'
  | 'Photo Editing'
  | 'Video Editing'
  | 'Logo Making'
  | 'Web Design'
  | 'Other';

export type JobCategory =
  | 'Academic Writing'
  | 'Essays'
  | 'Assignments'
  | 'Research'
  | 'Proofreading'
  | 'PowerPoint Presentation'
  | 'Transcription'
  | 'Photo Editing'
  | 'Video Editing'
  | 'Logo Making'
  | 'Web Design'
  | 'Data Entry'
  | 'Discussion Post'
  | 'Typing'
  | 'Copy Writing'
  | 'Translation'
  | 'Computer Tasks'
  | 'Excel'
  | 'SPSS'
  | 'Coding'
  | 'CV Writing';

export const ALL_JOB_CATEGORIES: JobCategory[] = [
  'Academic Writing',
  'Essays',
  'Assignments',
  'Research',
  'Proofreading',
  'PowerPoint Presentation',
  'Transcription',
  'Photo Editing',
  'Video Editing',
  'Logo Making',
  'Web Design',
  'Data Entry',
  'Discussion Post',
  'Typing',
  'Copy Writing',
  'Translation',
  'Computer Tasks',
  'Excel',
  'SPSS',
  'Coding',
  'CV Writing',
];

export type AcademicLevel = 'High School' | 'Diploma' | 'Undergraduate' | 'Master\'s' | 'PhD';

export type CitationStyle = 'APA 7th' | 'MLA 9th' | 'Harvard' | 'Chicago' | 'IEEE';

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: 'client' | 'worker' | 'admin';
  text: string;
  timestamp: string;
  createdAtMs?: number;
  attachmentName?: string;
  attachmentUrl?: string;
}

export interface TaskFile {
  name: string;
  url: string;
  size?: string;
  uploadedAt: string;
  uploadedByRole: 'client' | 'worker' | 'admin';
}

export interface ChatReport {
  id: string;
  orderId: string;
  orderTopic: string;
  reporterId: string;
  reporterName: string;
  reporterRole: 'client' | 'worker';
  reportedUserId: string;
  reportedUserName: string;
  reportedUserRole: 'client' | 'worker';
  reason: string;
  details?: string;
  reportedAt: string;
  status: 'Pending Review' | 'Warned' | 'Suspended' | 'Dismissed';
  adminNotes?: string;
  messagesSnapshot?: ChatMessage[];
}

export interface User {
  id: string;
  role: UserRole;
  fullName: string;
  displayName: string;
  email: string;
  phone: string;
  institution?: string;
  profilePhoto?: string;
  joinedAt: string;
  contactViolationCount?: number;
  isSuspended?: boolean;
  isBlockedByAdmin?: boolean;
  suspensionReason?: string;
  idNumber?: string;
  mpesaFullName?: string;
  mpesaPhoneNumber?: string;
  bankName?: string;
  bankAccountNumber?: string;
  paypalEmail?: string;
  skills?: JobCategory[];
  highestEducation?: string;
  about?: string;
  isApproved?: boolean;
  approvalStatus?: 'pending' | 'approved' | 'rejected';
  sampleWorkUrl?: string;
  sampleWorkName?: string;
  portfolioDescription?: string;
  isVerified?: boolean;
  rating?: number;
  totalTasksCompleted?: number;
}

export interface Order {
  id: string;
  topic: string;
  category: JobCategory;
  serviceType: ServiceType;
  serviceTier?: string;
  quantityValue: number;
  quantityUnit: string;
  pages: number;
  wordCount: number;
  deliveryHours: number;
  urgencyMultiplier?: number;
  deadline: string;
  academicLevel?: AcademicLevel;
  citationStyle?: CitationStyle;
  instructions: string;
  files?: TaskFile[];

  totalAmount: number;
  depositAmount: number;
  balanceAmount: number;
  workerPayoutAmount: number;
  writerPayoutAmount: number;
  workerPayAmount: number;
  adminProfitAmount: number;

  status: OrderStatus;
  createdAt: string;

  clientId: string;
  clientDisplayName: string;
  clientFullName?: string;
  clientEmail?: string;
  clientPhone?: string;

  screenshotUrl?: string;
  screenshotName?: string;
  paymentReference?: string;
  paymentUploadedAt?: string;

  balancePaid?: boolean;
  balanceScreenshotUrl?: string;
  balanceScreenshotName?: string;
  balancePaymentReference?: string;
  balancePaidAt?: string;

  assignedWorkerId?: string;
  workerDisplayName?: string;
  workerPaidAt?: string;
  writerPaidAt?: string;

  completedAt?: string;
  submissionNotes?: string;
  solutionDocumentName?: string;
  solutionDocumentUrl?: string;

  clientRating?: number;
  clientFeedback?: string;
  clientRatedAt?: string;

  messages?: ChatMessage[];
  isChatBlocked?: boolean;
  chatBlockedReason?: string;
  chatBlockedByRole?: 'client' | 'worker' | 'admin';

  adminNotes?: string;
}

export interface AppSettings {
  paybill: string;
  account: string;
  businessName: string;
  pricePerPage: number;
  depositPercentage: number;
  writerPercentage: number;
  adminPercentage: number;
  adminEmail?: string;
  appApkLink?: string;
}

export interface WithdrawalRecord {
  id: string;
  workerId: string;
  workerName: string;
  amount: number;
  mpesaNumber: string;
  date: string;
  status: 'Completed' | 'Processing';
  reference: string;
  createdAtMs?: number;
}
