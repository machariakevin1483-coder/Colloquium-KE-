/**
 * Colloquium KE - Strict Contact & External Link Filter
 * 
 * Rules:
 * 1. Phone numbers: 07, 01, +254, 254, 070-079, etc.
 * 2. Emails: @, gmail, yahoo, outlook, .com, .co.ke, etc.
 * 3. Social apps & call/text requests: whatsapp, telegram, instagram, facebook, tiktok, call me, text me, inbox me, dm me
 * 4. Links: http, https, www., bit.ly, etc.
 */

export interface ContactFilterResult {
  isBlocked: boolean;
  censoredText: string;
  matchedCategories: string[];
  warningMessage: string;
}

export const BLOCKED_CONTACT_WARNING =
  'For your safety, please keep all communication inside Colloquium KE. Sharing phone numbers, emails or social media is not allowed.';

// 1. Phone number patterns (Kenya & international formats, separated by spaces/dots/dashes)
const PHONE_PATTERNS = [
  /\b(?:\+?254|0)(?:7\d{8}|1\d{8})\b/gi,
  /\b(?:\+?254|254|07\d|01\d)[0-9\s\-._]{6,12}\b/gi,
  /\b0[71][0-9][0-9\s\-._]{6,10}\b/gi,
  /\b(?:\+?254\s?7\d{2}\s?\d{3}\s?\d{3})\b/gi,
  /\b(?:\+?254\s?1\d{2}\s?\d{3}\s?\d{3})\b/gi,
  /\b(?:070|071|072|073|074|075|076|077|078|079|010|011)[0-9\s\-._]{5,10}\b/gi,
  /\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b/gi, // General 10 digit phone format
];

// 2. Email patterns & common providers
const EMAIL_PATTERNS = [
  /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/gi,
  /\b[a-zA-Z0-9._%+-]+\s*(?:@|\[at\]|\(at\))\s*[a-zA-Z0-9.-]+\s*(?:\.|\(dot\)|\[dot\])\s*(?:com|co\.ke|ke|org|net|edu)\b/gi,
  /\b(?:gmail|yahoo|outlook|hotmail|icloud|protonmail)(?:\.com|\.co\.ke)?\b/gi,
  /\b[a-zA-Z0-9.-]+\.(?:com|co\.ke|org|net|io|me|ke)\b/gi,
];

// 3. Social media & direct solicitation phrases
const SOCIAL_PATTERNS = [
  /\b(?:whatsapp|whats\s*app|watsup|watsapp|wasap)\b/gi,
  /\b(?:telegram|tele\s*gram|t\.me)\b/gi,
  /\b(?:instagram|insta|ig\b|ig handle)/gi,
  /\b(?:facebook|fb\b|fb\.com)\b/gi,
  /\b(?:tiktok|tik\s*tok)\b/gi,
  /\b(?:snapchat|snap\b)\b/gi,
  /\b(?:twitter|x\.com)\b/gi,
  /\b(?:call\s*me|text\s*me|inbox\s*me|dm\s*me|reach\s*me\s*on|message\s*me\s*on)\b/gi,
  /\b(?:direct\s*message|my\s*number|my\s*digits|hit\s*me\s*up)\b/gi,
];

// 4. Web links
const LINK_PATTERNS = [
  /\bhttps?:\/\/[^\s]+/gi,
  /\bwww\.[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}[^\s]*/gi,
  /\bbit\.ly\/[a-zA-Z0-9]+/gi,
  /\bwa\.me\/[0-9]+/gi,
];

/**
 * Checks a message against all safety filter rules.
 * If blocked: returns isBlocked = true and censoredText with blocked content replaced with ****.
 */
export function filterContactSharing(message: string): ContactFilterResult {
  if (!message || typeof message !== 'string') {
    return {
      isBlocked: false,
      censoredText: '',
      matchedCategories: [],
      warningMessage: '',
    };
  }

  const matchedCategories: string[] = [];
  let censoredText = message;
  let isBlocked = false;

  // Check and censor phone patterns
  for (const pattern of PHONE_PATTERNS) {
    pattern.lastIndex = 0;
    if (pattern.test(message)) {
      isBlocked = true;
      if (!matchedCategories.includes('Phone Number')) matchedCategories.push('Phone Number');
      censoredText = censoredText.replace(pattern, '****');
    }
  }

  // Check and censor email patterns
  for (const pattern of EMAIL_PATTERNS) {
    pattern.lastIndex = 0;
    if (pattern.test(message)) {
      isBlocked = true;
      if (!matchedCategories.includes('Email Address')) matchedCategories.push('Email Address');
      censoredText = censoredText.replace(pattern, '****');
    }
  }

  // Check and censor social / solicitation patterns
  for (const pattern of SOCIAL_PATTERNS) {
    pattern.lastIndex = 0;
    if (pattern.test(message)) {
      isBlocked = true;
      if (!matchedCategories.includes('Social Media / Direct Contact')) {
        matchedCategories.push('Social Media / Direct Contact');
      }
      censoredText = censoredText.replace(pattern, '****');
    }
  }

  // Check and censor link patterns
  for (const pattern of LINK_PATTERNS) {
    pattern.lastIndex = 0;
    if (pattern.test(message)) {
      isBlocked = true;
      if (!matchedCategories.includes('External Link')) matchedCategories.push('External Link');
      censoredText = censoredText.replace(pattern, '****');
    }
  }

  return {
    isBlocked,
    censoredText,
    matchedCategories,
    warningMessage: isBlocked ? BLOCKED_CONTACT_WARNING : '',
  };
}

/**
 * Sanitizes existing message history so any stored contact info is displayed as ****.
 */
export function censorChatHistory(text: string): string {
  if (!text) return '';
  const result = filterContactSharing(text);
  return result.censoredText;
}
