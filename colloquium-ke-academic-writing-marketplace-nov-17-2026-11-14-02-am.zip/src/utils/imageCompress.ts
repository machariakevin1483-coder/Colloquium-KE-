import { TaskFile } from '../types';

/**
 * Compresses an uploaded image file (e.g. M-Pesa screenshot) into a compact JPEG Data URL
 * so it stays well within Firestore's 1MB document limit.
 */
export function compressReceiptImage(file: File, maxWidth = 1000, quality = 0.72): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('Please select a valid image file (PNG, JPG, or WEBP).'));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image file.'));
    reader.onload = (ev) => {
      const dataUrl = ev.target?.result;
      if (typeof dataUrl !== 'string') {
        reject(new Error('Invalid image data.'));
        return;
      }

      const img = new Image();
      img.onerror = () => reject(new Error('Unable to decode image.'));
      img.onload = () => {
        const scale = img.width > maxWidth ? maxWidth / img.width : 1;
        const targetW = Math.max(1, Math.round(img.width * scale));
        const targetH = Math.max(1, Math.round(img.height * scale));

        const canvas = document.createElement('canvas');
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(dataUrl);
          return;
        }
        ctx.drawImage(img, 0, 0, targetW, targetH);
        const compressed = canvas.toDataURL('image/jpeg', quality);
        resolve(compressed);
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  });
}

/**
 * Converts a task or chat attachment into a shareable Data URL (for files <= 350 KB)
 * so files uploaded on one device can be downloaded on another device.
 */
export function fileToSafeTaskFile(
  file: File,
  uploadedByRole: 'client' | 'worker' | 'admin'
): Promise<TaskFile> {
  return new Promise((resolve, reject) => {
    const maxBytes = 350 * 1024;
    if (file.type.startsWith('image/')) {
      compressReceiptImage(file, 1000, 0.7)
        .then((url) => {
          resolve({
            name: file.name,
            size: `${(file.size / 1024).toFixed(1)} KB`,
            url,
            uploadedAt: new Date().toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit' }),
            uploadedByRole,
          });
        })
        .catch(reject);
      return;
    }

    if (file.size > maxBytes) {
      reject(new Error(`"${file.name}" is larger than 350 KB. Please attach a smaller document.`));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error(`Failed to read "${file.name}".`));
    reader.onload = (ev) => {
      const url = typeof ev.target?.result === 'string' ? ev.target.result : '';
      resolve({
        name: file.name,
        size: `${(file.size / 1024).toFixed(1)} KB`,
        url,
        uploadedAt: new Date().toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit' }),
        uploadedByRole,
      });
    };
    reader.readAsDataURL(file);
  });
}
