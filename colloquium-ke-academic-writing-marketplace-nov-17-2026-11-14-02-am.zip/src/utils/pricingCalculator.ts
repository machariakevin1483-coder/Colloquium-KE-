import { AcademicLevel, ServiceType } from '../types';

export interface PricingCalculationResult {
  totalPrice: number;
  depositAmount: number; // 25% Escrow
  balanceAmount: number; // 75% Balance
  workerPay: number; // 65% of total
  adminProfit: number; // 35% of total
  unitRate: number;
  urgencyMultiplier: number;
  breakdownSummary: string;
}

export type UrgencyHours = 6 | 12 | 24 | 48 | 72 | 96 | 120;

export function getUrgencyMultiplier(deliveryHours: number): { multiplier: number; label: string } {
  if (deliveryHours <= 6) {
    return { multiplier: 2.0, label: '+100% Rush (6 Hours)' };
  }
  if (deliveryHours <= 12) {
    return { multiplier: 1.5, label: '+50% Urgent (12 Hours)' };
  }
  if (deliveryHours <= 24) {
    return { multiplier: 1.3, label: '+30% Expedited (24 Hours)' };
  }
  return { multiplier: 1.0, label: 'Standard (48+ Hours)' };
}

export interface CalculatePriceParams {
  serviceType: ServiceType;
  academicLevel?: AcademicLevel;
  deliveryHours?: number;
  // Specific quantities
  pages?: number; // for Academic, Proofreading, Web Design
  slides?: number; // for PowerPoint (min 5)
  audioMinutes?: number; // for Transcription (min 200 KES)
  imagesCount?: number; // for Photo Editing
  videoMinutes?: number; // for Video Editing (min 1500 KES)
  tier?: 'Basic' | 'Premium' | 'Advanced' | 'Clear' | 'Difficult';
}

export function calculateServicePrice(params: CalculatePriceParams): PricingCalculationResult {
  const { serviceType, academicLevel = 'Undergraduate', deliveryHours = 48, tier = 'Basic' } = params;
  const { multiplier, label: urgencyLabel } = getUrgencyMultiplier(deliveryHours);

  let rawTotal = 0;
  let unitRate = 0;
  let breakdownSummary = '';

  switch (serviceType) {
    case 'Academic': {
      // High School: 400 KES/page, Diploma: 550 KES/page, Undergraduate: 700 KES/page, Masters: 1000 KES/page, PhD: 1500 KES/page
      const pages = Math.max(1, params.pages || 1);
      const levelRates: Record<AcademicLevel, number> = {
        'High School': 400,
        Diploma: 550,
        Undergraduate: 700,
        "Master's": 1000,
        PhD: 1500,
      };
      unitRate = levelRates[academicLevel] || 700;
      rawTotal = Math.round(pages * unitRate * multiplier);
      breakdownSummary = `${pages} ${pages === 1 ? 'page' : 'pages'} (${pages * 275} words) @ KES ${unitRate}/pg · ${academicLevel} · Urgency: ${urgencyLabel}`;
      break;
    }

    case 'Proofreading': {
      // Proofreading: 200 KES/page (High/Diploma), 300 KES/page (Undergrad), 500 KES/page (Masters/PhD)
      const pages = Math.max(1, params.pages || 1);
      let rate = 300;
      if (academicLevel === 'High School' || academicLevel === 'Diploma') rate = 200;
      else if (academicLevel === 'Undergraduate') rate = 300;
      else if (academicLevel === "Master's" || academicLevel === 'PhD') rate = 500;

      unitRate = rate;
      rawTotal = Math.round(pages * unitRate * multiplier);
      breakdownSummary = `${pages} ${pages === 1 ? 'page' : 'pages'} proofreading @ KES ${unitRate}/pg · ${academicLevel} · Urgency: ${urgencyLabel}`;
      break;
    }

    case 'PowerPoint': {
      // PowerPoint: 250 KES/slide Basic, 400 KES/slide Premium. Min 5 slides
      const slides = Math.max(5, params.slides || 5);
      unitRate = tier === 'Premium' ? 400 : 250;
      rawTotal = slides * unitRate;
      breakdownSummary = `${slides} slides @ KES ${unitRate}/slide (${tier} presentation design, min 5 slides)`;
      break;
    }

    case 'Transcription': {
      // Transcription: 40 KES/audio minute Clear, 70 KES/audio minute Difficult. Min 200 KES
      const minutes = Math.max(1, params.audioMinutes || 5);
      unitRate = tier === 'Difficult' ? 70 : 40;
      rawTotal = Math.max(200, Math.round(minutes * unitRate));
      breakdownSummary = `${minutes} audio minutes @ KES ${unitRate}/min (${tier} audio quality, min KES 200)`;
      break;
    }

    case 'Photo Editing': {
      // Photo Editing: 300 KES/image Basic, 700 KES/image Advanced
      const count = Math.max(1, params.imagesCount || 1);
      unitRate = tier === 'Advanced' ? 700 : 300;
      rawTotal = count * unitRate;
      breakdownSummary = `${count} ${count === 1 ? 'image' : 'images'} @ KES ${unitRate}/image (${tier} retouching & color grade)`;
      break;
    }

    case 'Video Editing': {
      // Video Editing: 1000 KES/minute Basic, 2000 KES/minute Advanced. Min 1500 KES
      const minutes = Math.max(1, params.videoMinutes || 1);
      unitRate = tier === 'Advanced' ? 2000 : 1000;
      rawTotal = Math.max(1500, Math.round(minutes * unitRate));
      breakdownSummary = `${minutes} min final video @ KES ${unitRate}/min (${tier} edit & sound design, min KES 1,500)`;
      break;
    }

    case 'Logo Making': {
      // Logo Making: 3000 KES Basic (2 concepts), 6000 KES Premium (4 concepts + Revisions)
      unitRate = tier === 'Premium' ? 6000 : 3000;
      rawTotal = unitRate;
      breakdownSummary =
        tier === 'Premium'
          ? 'Premium Logo Package: 4 initial concepts, high-res vector files + unlimited revisions (KES 6,000)'
          : 'Basic Logo Package: 2 initial design concepts with transparent PNGs (KES 3,000)';
      break;
    }

    case 'Web Design': {
      // Web Design: 5000 KES/page Basic, 12000 KES/page Premium. Min 1 page
      const pages = Math.max(1, params.pages || 1);
      unitRate = tier === 'Premium' ? 12000 : 5000;
      rawTotal = pages * unitRate;
      breakdownSummary = `${pages} ${pages === 1 ? 'page' : 'pages'} web design @ KES ${unitRate.toLocaleString()}/pg (${tier} responsive development, min 1 page)`;
      break;
    }

    default: {
      const pages = Math.max(1, params.pages || 1);
      unitRate = 700;
      rawTotal = Math.round(pages * unitRate * multiplier);
      breakdownSummary = `${pages} units @ KES ${unitRate}/unit`;
      break;
    }
  }

  // Exact prompt requirements:
  // Deposit = Total * 0.25 (25% Escrow)
  // Balance = Total * 0.75 (75% on Delivery)
  // Worker Pay = 65% of Total
  // Admin Profit = 35% of Total
  const depositAmount = Math.round(rawTotal * 0.25);
  const balanceAmount = rawTotal - depositAmount; // Guaranteed exact sum
  const workerPay = Math.floor(rawTotal * 0.65);
  const adminProfit = rawTotal - workerPay;

  return {
    totalPrice: rawTotal,
    depositAmount,
    balanceAmount,
    workerPay,
    adminProfit,
    unitRate,
    urgencyMultiplier: multiplier,
    breakdownSummary,
  };
}
