import React, { useState, useRef } from 'react';
import { useOrders } from '../context/OrderContext';
import { StatusBadge } from './StatusBadge';
import { compressReceiptImage } from '../utils/imageCompress';
import {
  CreditCard,
  Copy,
  Check,
  UploadCloud,
  FileCheck,
  AlertCircle,
  Clock,
  ArrowRight,
  ShieldCheck,
  Eye,
  Trash2,
  FileText,
  Smartphone,
  Lock,
} from 'lucide-react';

interface CheckoutPageProps {
  orderId: string;
  navigate: (path: string) => void;
}

export const CheckoutPage: React.FC<CheckoutPageProps> = ({ orderId, navigate }) => {
  const { getOrderById, settings, uploadScreenshotAndPay, currentUser, userRole } = useOrders();
  const order = getOrderById(orderId);
  const isClientLoggedIn = (userRole === 'client' && currentUser !== null) || userRole === 'admin';

  const [screenshotPreview, setScreenshotPreview] = useState<string>(order?.screenshotUrl || '');
  const [screenshotFileName, setScreenshotFileName] = useState<string>(order?.screenshotName || '');
  const [mpesaRef, setMpesaRef] = useState<string>(order?.paymentReference || '');
  const [copiedPaybill, setCopiedPaybill] = useState(false);
  const [copiedAccount, setCopiedAccount] = useState(false);
  const [copiedAmount, setCopiedAmount] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successPaid, setSuccessPaid] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!order) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center">
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-3" />
          <h2 className="text-xl font-bold text-slate-900 mb-2">Order Not Found</h2>
          <p className="text-sm text-slate-600 mb-6">
            We could not locate order reference <span className="font-mono font-bold text-slate-800">{orderId}</span>.
          </p>
          <button
            onClick={() => navigate('/order')}
            className="px-5 py-2.5 bg-[#0E7A4C] hover:bg-[#0b633d] text-white text-xs font-bold rounded-lg shadow-sm"
          >
            Create New Order
          </button>
        </div>
      </div>
    );
  }

  // ANTI-SCAM GUARD: If worker role tries to access checkout, redirect to worker dashboard
  if (currentUser?.role === 'worker') {
    return (
      <div className="max-w-md mx-auto my-16 bg-white p-6 rounded-2xl border border-red-200 text-center space-y-3">
        <Lock className="w-10 h-10 text-red-500 mx-auto" />
        <h3 className="font-bold text-base text-slate-900">Restricted Checkout Area</h3>
        <p className="text-xs text-slate-600">
          Paybill details are strictly restricted to Client escrow. Workers receive payouts directly from Admin via M-Pesa.
        </p>
        <button
          onClick={() => navigate('/worker/dashboard')}
          className="px-4 py-2 bg-[#0E7A4C] text-white text-xs font-bold rounded-lg"
        >
          Go to Worker Dashboard
        </button>
      </div>
    );
  }

  const handleCopyPaybill = () => {
    navigator.clipboard.writeText(settings.paybill);
    setCopiedPaybill(true);
    setTimeout(() => setCopiedPaybill(false), 2000);
  };

  const handleCopyAccount = () => {
    navigator.clipboard.writeText(settings.account);
    setCopiedAccount(true);
    setTimeout(() => setCopiedAccount(false), 2000);
  };

  const handleCopyAmount = () => {
    navigator.clipboard.writeText(order.depositAmount.toString());
    setCopiedAmount(true);
    setTimeout(() => setCopiedAmount(false), 2000);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMessage('Please upload an image receipt (PNG, JPG, or WEBP).');
      return;
    }

    setErrorMessage('');
    setScreenshotFileName(file.name);

    try {
      const compressed = await compressReceiptImage(file);
      setScreenshotPreview(compressed);
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Unable to process image.');
    }
  };

  const handleRemoveScreenshot = () => {
    setScreenshotPreview('');
    setScreenshotFileName('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleIHavePaid = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    setIsSubmitting(true);
    try {
      const ok = await uploadScreenshotAndPay(
        order.id,
        screenshotPreview || '',
        screenshotFileName || `payment_${order.id}.jpg`,
        mpesaRef || `MP-${Date.now().toString().slice(-6)}`
      );
      if (ok) {
        setSuccessPaid(true);
      } else {
        setErrorMessage('Failed to record payment. Please check your connection and try again.');
      }
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Failed to record payment.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const isAlreadyPaid = order.status !== 'Pending Payment' || successPaid;

  return (
    <div className="min-h-screen bg-slate-50 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <button onClick={() => navigate('/')} className="hover:text-slate-900 transition">
              Home
            </button>
            <span>/</span>
            <span className="text-slate-900 font-semibold">Order Checkout: {order.id}</span>
          </div>
          <button
            onClick={() => navigate('/client/dashboard')}
            className="text-[#0E7A4C] font-semibold hover:underline flex items-center gap-1"
          >
            <span>My Client Orders</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Header Title */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              {isClientLoggedIn ? 'Escrow Deposit Payment (25%)' : 'Order Checkout'}
            </h1>
            <p className="text-xs text-slate-600 mt-1">
              Order Reference <strong className="font-mono text-[#0E7A4C]">{order.id}</strong>
            </p>
          </div>
          <div>
            <StatusBadge status={successPaid ? 'Paid' : order.status} size="lg" />
          </div>
        </div>

        {/* Success Banner if Paid: Awaiting Admin Confirmation */}
        {isAlreadyPaid && (
          <div className="bg-emerald-50 border-2 border-emerald-300 rounded-xl p-5 text-emerald-950 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
            <div className="flex items-start gap-3">
              <ShieldCheck className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <h2 className="font-bold text-base text-emerald-950">Payment Recorded (Awaiting Admin Confirmation)</h2>
                <p className="text-xs text-emerald-800 mt-1 leading-relaxed">
                  Thank you! You have marked this order as paid. <strong>The Administrator will now verify your payment via Equity Paybill {settings.paybill} before a verified specialist begins drafting your task.</strong>
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => navigate('/client/dashboard')}
                className="px-4 py-2 bg-[#0E7A4C] hover:bg-[#0b633d] text-white text-xs font-bold rounded-lg transition shadow-sm flex items-center gap-1.5"
              >
                <span>Go to Client Orders</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Task Summary & EXACT PRICING BREAKDOWN */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 space-y-5">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h2 className="font-bold text-base text-slate-900 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[#0E7A4C]" />
                  <span>Order Summary</span>
                </h2>
                <span className="font-mono font-bold text-xs text-slate-500">{order.id}</span>
              </div>

              <div>
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                  Service &amp; Topic
                </span>
                <span className="inline-block px-2 py-0.5 bg-emerald-50 text-[#0E7A4C] font-semibold rounded text-[11px] mb-1">
                  {order.category}
                </span>
                <p className="font-bold text-sm text-slate-900 leading-snug">
                  {order.topic}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded-lg border border-slate-100">
                <div>
                  <span className="text-slate-500 block">Level / Tier:</span>
                  <span className="font-semibold text-slate-800">{order.academicLevel || order.serviceTier || 'Standard'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Turnaround:</span>
                  <span className="font-semibold text-[#0E7A4C]">{order.deliveryHours} Hours</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Units:</span>
                  <span className="font-semibold text-slate-800">
                    {order.quantityValue} {order.quantityUnit || 'units'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Expected Delivery:</span>
                  <span className="font-semibold text-slate-800">
                    {new Date(order.deadline).toLocaleDateString('en-KE')}
                  </span>
                </div>
              </div>

              {/* Requirement 1 EXACT PRICING BREAKDOWN:
                  Total Price = [Calculated Price]
                  Pay Now to Start (25% Escrow) = [Total x 0.25]
                  Balance After Delivery (75%) = [Total x 0.75]
              */}
              <div className="pt-3 border-t border-slate-200 space-y-2.5 text-xs">
                <div className="flex justify-between items-center text-slate-700 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                  <span className="font-semibold">Total Price:</span>
                  <span className="font-black text-sm text-slate-900 font-mono">
                    KES {order.totalAmount.toLocaleString()}
                  </span>
                </div>

                {isClientLoggedIn && (
                  <>
                    <div className="flex justify-between items-center text-emerald-900 font-semibold bg-emerald-50 p-2.5 rounded-lg border border-emerald-200">
                      <span>Pay Now to Start (25% Escrow):</span>
                      <span className="font-black text-base font-mono text-[#0E7A4C]">
                        KES {order.depositAmount.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex justify-between items-center text-slate-600 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span>Balance After Delivery (75%):</span>
                      <span className="font-bold text-slate-900 font-mono">
                        KES {order.balanceAmount.toLocaleString()}
                      </span>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Right Column: CLIENT ONLY PAYBILL INSTRUCTIONS & [I HAVE PAID] BUTTON */}
          <div className="lg:col-span-7 space-y-6">
            {!isClientLoggedIn ? (
              <div className="bg-white rounded-2xl shadow-md border-2 border-slate-200 p-8 text-center space-y-5">
                <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-[#0E7A4C] flex items-center justify-center mx-auto shadow-inner border border-emerald-100">
                  <ShieldCheck className="w-9 h-9" />
                </div>
                <div>
                  <h2 className="text-xl font-black text-slate-900 leading-snug">
                    Secure Escrow Payment - Sign up as Client to view payment details
                  </h2>
                  <p className="text-xs text-slate-600 max-w-md mx-auto mt-2 leading-relaxed">
                    Colloquium KE protects clients and specialists. Equity Paybill instructions and escrow verification are strictly accessible only to authenticated Clients.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                  <button
                    onClick={() => navigate('/client/register')}
                    className="w-full sm:w-auto px-6 py-3 bg-[#0E7A4C] hover:bg-[#0b633d] text-white text-xs font-bold rounded-xl shadow-md transition flex items-center justify-center gap-2"
                  >
                    <span>Sign Up as Client</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => navigate('/login')}
                    className="w-full sm:w-auto px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition"
                  >
                    Sign In
                  </button>
                </div>
              </div>
            ) : (
              <>
                {/* Paybill Card with FULL Account Number and 3 Copy Buttons */}
                <div className="bg-white rounded-xl shadow-md border-2 border-[#0E7A4C]/30 overflow-hidden">
                  <div className="bg-[#0E7A4C] text-white px-6 py-4 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-lg bg-white/20 flex items-center justify-center font-bold">
                        <CreditCard className="w-5 h-5 text-emerald-100" />
                      </div>
                      <div>
                        <h2 className="text-base font-extrabold text-white">Equity Paybill {settings.paybill}</h2>
                        <p className="text-xs text-emerald-100">Lipa na M-Pesa to Equity Bank Escrow</p>
                      </div>
                    </div>
                    <span className="text-xs bg-white/20 px-2.5 py-1 rounded-full font-semibold uppercase tracking-wider text-emerald-100">
                      25% Deposit
                    </span>
                  </div>

                  <div className="p-6 space-y-5">
                    {/* Step-by-step payment instructions */}
                    <div className="bg-emerald-50 border-2 border-emerald-300 rounded-xl p-4 text-[#0E7A4C]">
                      <div className="flex items-start gap-2.5">
                        <Smartphone className="w-5 h-5 text-[#0E7A4C] shrink-0 mt-0.5" />
                        <div>
                          <span className="text-xs uppercase font-extrabold tracking-wider block text-emerald-900 mb-1">
                            Lipa na M-Pesa Step-by-Step Instructions:
                          </span>
                          <p className="text-xs sm:text-sm font-bold text-[#0E7A4C] leading-relaxed">
                            Lipa na M-Pesa &gt; Paybill &gt; Enter Business No: <strong className="font-mono underline">{settings.paybill}</strong> &gt; Account No: <strong className="font-mono underline">{settings.account}</strong> &gt; Amount: <strong className="font-mono underline">KES {order.depositAmount.toLocaleString()}</strong> &gt; Enter PIN &amp; Send.
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Exact 3 Buttons: [Copy Paybill] [Copy Account Number] [Copy Amount] */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {/* 1. Paybill Button */}
                      <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl flex flex-col justify-between">
                        <div>
                          <span className="text-[10px] text-slate-500 uppercase font-semibold block">
                            Equity Paybill
                          </span>
                          <span className="font-black font-mono text-xl text-slate-900 block mt-0.5">
                            {settings.paybill}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={handleCopyPaybill}
                          className="mt-2 w-full py-1.5 px-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-[#0E7A4C] text-xs font-bold rounded-lg transition flex items-center justify-center gap-1"
                        >
                          {copiedPaybill ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedPaybill ? 'Copied!' : 'Copy Paybill'}</span>
                        </button>
                      </div>

                      {/* 2. Full Account Number Button (NO CUT OFF) */}
                      <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl flex flex-col justify-between">
                        <div>
                          <span className="text-[10px] text-slate-500 uppercase font-semibold block">
                            Account Number
                          </span>
                          {/* FULL ACCOUNT NUMBER SHOWN COMPLETELY, NEVER TRUNCATED */}
                          <span className="font-black font-mono text-base text-slate-900 block mt-0.5 select-all whitespace-nowrap">
                            {settings.account}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={handleCopyAccount}
                          className="mt-2 w-full py-1.5 px-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-[#0E7A4C] text-xs font-bold rounded-lg transition flex items-center justify-center gap-1"
                        >
                          {copiedAccount ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedAccount ? 'Copied!' : 'Copy Account Number'}</span>
                        </button>
                      </div>

                      {/* 3. Copy Amount Button */}
                      <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl flex flex-col justify-between">
                        <div>
                          <span className="text-[10px] text-slate-500 uppercase font-semibold block">
                            Amount (25% Deposit)
                          </span>
                          <span className="font-black font-mono text-base text-[#0E7A4C] block mt-0.5">
                            KES {order.depositAmount.toLocaleString()}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={handleCopyAmount}
                          className="mt-2 w-full py-1.5 px-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-[#0E7A4C] text-xs font-bold rounded-lg transition flex items-center justify-center gap-1"
                        >
                          {copiedAmount ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedAmount ? 'Copied!' : 'Copy Amount'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Proof Attachment & [I Have Paid] Card */}
                <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 space-y-4">
                  <div>
                    <h2 className="font-bold text-base text-slate-900 flex items-center gap-2">
                      <UploadCloud className="w-5 h-5 text-[#0E7A4C]" />
                      <span>Attach Payment Proof (Optional)</span>
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Upload your M-Pesa SMS screenshot or enter the transaction reference code to expedite verification.
                    </p>
                  </div>

                  {errorMessage && (
                    <div className="bg-red-50 border border-red-200 text-red-700 px-3 py-2 rounded-lg text-xs flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{errorMessage}</span>
                    </div>
                  )}

                  {!screenshotPreview ? (
                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="border-2 border-dashed border-slate-300 hover:border-[#0E7A4C] rounded-xl p-6 text-center cursor-pointer transition bg-slate-50/50 hover:bg-emerald-50/20"
                    >
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                      <UploadCloud className="w-8 h-8 text-slate-400 mx-auto mb-1" />
                      <p className="text-xs font-semibold text-slate-700">
                        Click to select M-Pesa confirmation screenshot
                      </p>
                      <p className="text-[10px] text-slate-500 mt-0.5">PNG, JPG, or WEBP</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="relative border border-slate-200 rounded-xl p-3 bg-slate-50 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-lg bg-white border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center">
                            <img
                              src={screenshotPreview}
                              alt="Payment proof"
                              className="w-full h-full object-contain"
                            />
                          </div>
                          <div>
                            <div className="text-xs font-bold text-slate-900 truncate max-w-[200px] sm:max-w-xs">
                              {screenshotFileName || 'mpesa_payment_proof.png'}
                            </div>
                            <div className="text-[11px] text-emerald-600 font-medium flex items-center gap-1 mt-0.5">
                              <Check className="w-3 h-3" />
                              <span>Screenshot Attached</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={handleRemoveScreenshot}
                            className="p-1.5 rounded-md hover:bg-red-50 text-red-600 transition"
                            title="Remove"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  <div>
                    <label htmlFor="checkout-mpesa-transcode-input" className="block text-xs font-semibold text-slate-700 mb-1">
                      M-Pesa Transaction Code (Optional)
                    </label>
                    <input
                      id="checkout-mpesa-transcode-input"
                      type="text"
                      value={mpesaRef}
                      onChange={(e) => setMpesaRef(e.target.value.toUpperCase())}
                      placeholder="e.g. QK884920KP"
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs uppercase focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                    />
                  </div>

                  {/* Requirement 1: [I Have Paid] Button */}
                  <div className="pt-3">
                    <button
                      type="button"
                      onClick={handleIHavePaid}
                      disabled={isSubmitting}
                      className="w-full py-3.5 px-6 rounded-xl text-sm font-black transition flex items-center justify-center gap-2 shadow-lg bg-[#0E7A4C] hover:bg-[#0b633d] text-white cursor-pointer active:scale-[0.99]"
                    >
                      <FileCheck className="w-5 h-5" />
                      <span>{isSubmitting ? 'Recording Payment...' : 'I Have Paid'}</span>
                    </button>
                    <p className="text-[11px] text-center text-slate-600 mt-2 font-medium">
                      After you click <strong>I Have Paid</strong>, the Administrator will confirm your payment before the specialist starts your task.
                    </p>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
