import React, { useState, useEffect } from 'react';
import { useOrders } from '../context/OrderContext';
import { ColloquiumLogoIcon } from './ColloquiumLogoIcon';
import {
  Download,
  Smartphone,
  Share2,
  PlusSquare,
  MoreVertical,
  CheckCircle2,
  ShieldCheck,
  Laptop,
  ArrowRight,
  ExternalLink,
  Sparkles,
} from 'lucide-react';

interface DownloadAppPageProps {
  navigate: (path: string) => void;
  deferredPrompt?: any;
  triggerPwaInstall?: () => void;
}

export const DownloadAppPage: React.FC<DownloadAppPageProps> = ({
  navigate,
  deferredPrompt,
  triggerPwaInstall,
}) => {
  const { settings } = useOrders();
  const [installed, setInstalled] = useState(false);
  const [platformTab, setPlatformTab] = useState<'android' | 'ios' | 'desktop'>('android');

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const isStandalone =
        window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as any).standalone === true;
      if (isStandalone) {
        setInstalled(true);
      }
    }

    // Detect device platform
    if (typeof navigator !== 'undefined') {
      const ua = navigator.userAgent || '';
      if (/iPhone|iPad|iPod/i.test(ua)) {
        setPlatformTab('ios');
      } else if (/Android/i.test(ua)) {
        setPlatformTab('android');
      } else {
        setPlatformTab('desktop');
      }
    }

    const handleAppInstalled = () => {
      setInstalled(true);
    };
    window.addEventListener('appinstalled', handleAppInstalled);
    return () => window.removeEventListener('appinstalled', handleAppInstalled);
  }, []);

  const handleDownloadOrInstall = () => {
    // If admin configured an APK link, prioritize direct APK download
    if (settings.appApkLink && settings.appApkLink.trim()) {
      window.location.href = settings.appApkLink.trim();
      return;
    }

    // Otherwise trigger PWA prompt if available
    if (triggerPwaInstall) {
      triggerPwaInstall();
      return;
    }

    if (deferredPrompt && typeof deferredPrompt.prompt === 'function') {
      deferredPrompt.prompt();
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header Breadcrumb */}
        <div className="flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <button onClick={() => navigate('/')} className="hover:text-slate-900 transition">
              Home
            </button>
            <span>/</span>
            <span className="text-slate-900 font-semibold">Download Colloquium KE App</span>
          </div>
          <button
            onClick={() => navigate('/order')}
            className="text-[#0E7A4C] font-semibold hover:underline flex items-center gap-1"
          >
            <span>Order Task</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Hero Card */}
        <div className="bg-gradient-to-br from-[#0E7A4C] via-[#0b633d] to-[#08432a] text-white rounded-3xl p-8 sm:p-10 shadow-xl border border-emerald-700/50 relative overflow-hidden">
          <div className="relative z-10 max-w-2xl space-y-4">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md px-3.5 py-1.5 rounded-full text-xs font-semibold text-emerald-200 border border-white/20">
              <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
              <span>Official Progressive Web App (PWA) &amp; Android Package</span>
            </div>

            <div className="flex items-center gap-4 pt-2">
              <div className="w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-md border-2 border-white/20 flex items-center justify-center shadow-lg shrink-0">
                <ColloquiumLogoIcon className="w-10 h-10 text-white" strokeWidth={2.2} />
              </div>
              <div>
                <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight leading-tight">
                  Colloquium KE App
                </h1>
                <p className="text-xs sm:text-sm text-emerald-100 mt-1">
                  Install Kenya's premier academic marketplace directly on your mobile device or computer for instant task tracking.
                </p>
              </div>
            </div>

            {/* Action Download / Install Button */}
            <div className="pt-4 flex flex-wrap items-center gap-3">
              {installed ? (
                <div className="bg-emerald-400 text-slate-950 font-extrabold text-xs px-5 py-3 rounded-xl flex items-center gap-2 shadow-md">
                  <CheckCircle2 className="w-4 h-4 text-emerald-950" />
                  <span>App Already Installed on this Device</span>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={handleDownloadOrInstall}
                  className="bg-white text-[#0E7A4C] hover:bg-emerald-50 active:scale-95 font-extrabold text-sm px-6 py-3.5 rounded-xl transition shadow-lg flex items-center gap-2.5"
                >
                  <Download className="w-5 h-5 text-[#0E7A4C]" />
                  <span>
                    {settings.appApkLink && settings.appApkLink.trim()
                      ? 'Download Android APK'
                      : 'Install Colloquium KE App'}
                  </span>
                </button>
              )}

              {settings.appApkLink && (
                <a
                  href={settings.appApkLink}
                  target="_blank"
                  rel="noreferrer"
                  className="bg-white/15 hover:bg-white/25 text-white font-semibold text-xs px-4 py-3.5 rounded-xl transition border border-white/20 flex items-center gap-1.5"
                >
                  <span>Direct APK Mirror</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}

              <a
                href="/icon.svg"
                download="colloquium-ke-icon.svg"
                className="bg-white/15 hover:bg-white/25 text-white font-semibold text-xs px-4 py-3.5 rounded-xl transition border border-white/20 flex items-center gap-1.5"
                title="Download official app icon SVG"
              >
                <span>App Icon (SVG)</span>
                <Download className="w-3.5 h-3.5" />
              </a>
            </div>

            <div className="flex flex-wrap items-center gap-4 text-xs text-emerald-200 pt-2">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" /> No Play Store required
              </span>
              <span>·</span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" /> Less than 2 MB storage
              </span>
              <span>·</span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" /> Real-time order status
              </span>
            </div>
          </div>
        </div>

        {/* Platform Selector Tabs */}
        <div className="flex items-center justify-center gap-2 bg-white p-1.5 rounded-2xl border border-slate-200 shadow-sm">
          <button
            onClick={() => setPlatformTab('android')}
            className={`flex-1 sm:flex-initial px-5 py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
              platformTab === 'android'
                ? 'bg-[#0E7A4C] text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>Android (Chrome)</span>
          </button>
          <button
            onClick={() => setPlatformTab('ios')}
            className={`flex-1 sm:flex-initial px-5 py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
              platformTab === 'ios'
                ? 'bg-[#0E7A4C] text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>iPhone / iPad (Safari)</span>
          </button>
          <button
            onClick={() => setPlatformTab('desktop')}
            className={`flex-1 sm:flex-initial px-5 py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
              platformTab === 'desktop'
                ? 'bg-[#0E7A4C] text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Laptop className="w-4 h-4" />
            <span>Windows / Mac (PC)</span>
          </button>
        </div>

        {/* Step-by-Step Instructions Based on Active Platform */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
          {platformTab === 'android' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-[#0E7A4C]" />
                  <span>How to Install on Android</span>
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Follow these simple steps using Google Chrome, Samsung Internet, or Brave Browser:
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-[#0E7A4C] text-white font-bold flex items-center justify-center text-xs">
                    1
                  </div>
                  <h4 className="font-bold text-slate-900">Tap Browser Menu</h4>
                  <p className="text-slate-600 leading-relaxed">
                    In Google Chrome on your Android phone, tap the <strong className="text-slate-800">three dots (⋮)</strong> in the top-right corner.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-[#0E7A4C] text-white font-bold flex items-center justify-center text-xs">
                    2
                  </div>
                  <h4 className="font-bold text-slate-900">Select "Install App"</h4>
                  <p className="text-slate-600 leading-relaxed">
                    Tap <strong className="text-[#0E7A4C]">"Install App"</strong> or <strong className="text-slate-800">"Add to Home screen"</strong> from the dropdown menu.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-[#0E7A4C] text-white font-bold flex items-center justify-center text-xs">
                    3
                  </div>
                  <h4 className="font-bold text-slate-900">Confirm &amp; Launch</h4>
                  <p className="text-slate-600 leading-relaxed">
                    Tap <strong className="text-slate-800">Install</strong>. The green Colloquium KE icon will appear on your phone home screen immediately.
                  </p>
                </div>
              </div>

              {settings.appApkLink && (
                <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-xs text-emerald-900 flex items-center justify-between gap-4">
                  <div>
                    <span className="font-bold block text-sm">Direct Android APK Package</span>
                    <span className="text-[11px] text-emerald-700">
                      An Android APK build has been configured by the admin for direct download.
                    </span>
                  </div>
                  <a
                    href={settings.appApkLink}
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-2 bg-[#0E7A4C] hover:bg-[#0b633d] text-white font-bold rounded-lg shrink-0 transition"
                  >
                    Download .APK
                  </a>
                </div>
              )}
            </div>
          )}

          {platformTab === 'ios' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-[#0E7A4C]" />
                  <span>How to Install on iPhone / iPad (Safari)</span>
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Apple requires Safari to install Progressive Web Apps:
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-[#0E7A4C] text-white font-bold flex items-center justify-center text-xs">
                    1
                  </div>
                  <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                    <span>Tap Share Button</span>
                    <Share2 className="w-3.5 h-3.5 text-[#0E7A4C]" />
                  </h4>
                  <p className="text-slate-600 leading-relaxed">
                    Open Colloquium KE in <strong className="text-slate-800">Safari</strong>, then tap the <strong className="text-slate-800">Share icon</strong> (square with arrow pointing up) at the bottom toolbar.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-[#0E7A4C] text-white font-bold flex items-center justify-center text-xs">
                    2
                  </div>
                  <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                    <span>"Add to Home Screen"</span>
                    <PlusSquare className="w-3.5 h-3.5 text-[#0E7A4C]" />
                  </h4>
                  <p className="text-slate-600 leading-relaxed">
                    Scroll down the share options list and tap <strong className="text-[#0E7A4C]">"Add to Home Screen"</strong>.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-[#0E7A4C] text-white font-bold flex items-center justify-center text-xs">
                    3
                  </div>
                  <h4 className="font-bold text-slate-900">Tap "Add" in Top-Right</h4>
                  <p className="text-slate-600 leading-relaxed">
                    Tap <strong className="text-slate-800">"Add"</strong> in the top-right corner. The Colloquium KE app icon is now on your home screen.
                  </p>
                </div>
              </div>
            </div>
          )}

          {platformTab === 'desktop' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Laptop className="w-5 h-5 text-[#0E7A4C]" />
                  <span>How to Install on Computer (Windows, Mac, Linux)</span>
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Enjoy fullscreen windowed operation with fast offline caching:
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-[#0E7A4C] text-white font-bold flex items-center justify-center text-xs">
                    1
                  </div>
                  <h4 className="font-bold text-slate-900">Look at Address Bar</h4>
                  <p className="text-slate-600 leading-relaxed">
                    In Chrome, Edge, or Brave, look at the right end of the URL address bar at the top of your browser.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-[#0E7A4C] text-white font-bold flex items-center justify-center text-xs">
                    2
                  </div>
                  <h4 className="font-bold text-slate-900">Click Install Icon</h4>
                  <p className="text-slate-600 leading-relaxed">
                    Click the small <strong className="text-[#0E7A4C]">Install icon</strong> (computer screen with a down arrow).
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-[#0E7A4C] text-white font-bold flex items-center justify-center text-xs">
                    3
                  </div>
                  <h4 className="font-bold text-slate-900">Click "Install"</h4>
                  <p className="text-slate-600 leading-relaxed">
                    Confirm by clicking Install. The app opens in its own clean window without browser tab bars.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Official App Icon Showcase */}
          <div className="border-t border-slate-200 pt-8 mt-6">
            <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row items-center gap-6 shadow-xl border border-slate-800">
              <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl overflow-hidden shadow-2xl border-2 border-white/20 shrink-0 bg-[#0E7A4C] flex items-center justify-center">
                <img
                  src="/app-icon.jpg"
                  alt="Colloquium KE Official App Icon"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    // Fallback to SVG if image not yet loaded
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              </div>

              <div className="space-y-3 text-center sm:text-left flex-1">
                <div className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-300 text-[11px] font-bold px-2.5 py-1 rounded-full border border-emerald-500/30">
                  <span>Official Brand Asset</span>
                </div>
                <h3 className="text-xl font-extrabold text-white tracking-tight">
                  Colloquium KE App Icon
                </h3>
                <p className="text-xs text-slate-300 max-w-lg leading-relaxed">
                  The verified brand icon featuring the emerald green squircle container with open academic research book and hand drafting with pen.
                </p>

                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 pt-1">
                  <a
                    href="/app-icon.jpg"
                    download="colloquium-ke-app-icon.jpg"
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl transition flex items-center gap-2 shadow-md"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download App Icon (HD Image)</span>
                  </a>

                  <a
                    href="/icon.svg"
                    download="colloquium-ke-app-icon.svg"
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold rounded-xl transition flex items-center gap-2"
                  >
                    <Download className="w-4 h-4 text-emerald-400" />
                    <span>Download Vector (SVG)</span>
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Key Advantages */}
          <div className="border-t border-slate-200 pt-6">
            <h4 className="font-bold text-xs uppercase tracking-wider text-slate-500 mb-3">
              App Capabilities
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="flex items-center gap-2 text-slate-700">
                <ShieldCheck className="w-4 h-4 text-[#0E7A4C] shrink-0" />
                <span>Real-Time Order Updates</span>
              </div>
              <div className="flex items-center gap-2 text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-[#0E7A4C] shrink-0" />
                <span>Offline Cached Dashboard</span>
              </div>
              <div className="flex items-center gap-2 text-slate-700">
                <Download className="w-4 h-4 text-[#0E7A4C] shrink-0" />
                <span>Zero Storage Overhead</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Navigation CTA */}
        <div className="text-center">
          <button
            onClick={() => navigate('/')}
            className="text-xs text-slate-600 hover:text-slate-900 font-semibold underline"
          >
            ← Return to Homepage
          </button>
        </div>
      </div>
    </div>
  );
};
