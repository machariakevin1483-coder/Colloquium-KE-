import React, { useState, useRef } from 'react';
import { useOrders } from '../context/OrderContext';
import { Order } from '../types';
import { StatusBadge } from './StatusBadge';
import { ReceiptViewerModal } from './ReceiptViewerModal';
import { TaskChatModal } from './TaskChatModal';
import { compressReceiptImage } from '../utils/imageCompress';
import {
  FileText,
  Search,
  Eye,
  PlusCircle,
  CreditCard,
  Download,
  Clock,
  CheckCircle2,
  FileCheck2,
  X,
  Plus,
  Minus,
  MessageSquare,
  Star,
  UploadCloud,
  Check,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';

interface ClientDashboardProps {
  navigate: (path: string) => void;
}

export const ClientDashboard: React.FC<ClientDashboardProps> = ({ navigate }) => {
  const {
    orders,
    editDeliveryTime,
    settings,
    currentUser,
    userRole,
    payBalance,
    rateWorker,
  } = useOrders();

  const isClientLoggedIn = (userRole === 'client' && currentUser !== null) || userRole === 'admin';
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [viewScreenshotOrder, setViewScreenshotOrder] = useState<Order | null>(null);

  // Chat modal state
  const [chatOrder, setChatOrder] = useState<Order | null>(null);

  // Delivery time edit modal
  const [editingDeliveryOrder, setEditingDeliveryOrder] = useState<Order | null>(null);

  // 75% Balance Payment modal
  const [payingBalanceOrder, setPayingBalanceOrder] = useState<Order | null>(null);
  const [balanceReceiptPreview, setBalanceReceiptPreview] = useState<string>('');
  const [balanceReceiptName, setBalanceReceiptName] = useState<string>('');
  const [balanceMpesaRef, setBalanceMpesaRef] = useState<string>('');
  const [balanceErrorMessage, setBalanceErrorMessage] = useState('');
  const [isSubmittingBalance, setIsSubmittingBalance] = useState(false);
  const balanceFileInputRef = useRef<HTMLInputElement>(null);

  // Rate Specialist modal
  const [ratingOrder, setRatingOrder] = useState<Order | null>(null);
  const [ratingStars, setRatingStars] = useState<number>(5);
  const [ratingFeedback, setRatingFeedback] = useState<string>('');

  // Filter client's orders strictly to authenticated client (or admin)
  const clientOrders = orders.filter((o) => {
    if (userRole === 'admin') return true;
    if (currentUser?.id) {
      return o.clientId === currentUser.id;
    }
    return false;
  });

  const filteredOrders = clientOrders.filter((o) => {
    const matchesSearch =
      o.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.topic.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.category.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'All' || o.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Calculate live hours remaining
  const getHoursRemaining = (deadlineStr: string) => {
    const diffMs = new Date(deadlineStr).getTime() - Date.now();
    const diffHours = Math.round(diffMs / (3600 * 1000));
    if (diffHours < 0) {
      return { text: `${Math.abs(diffHours)}h overdue`, isOverdue: true };
    }
    return { text: `${diffHours}h left`, isOverdue: false };
  };

  const handleOpenBalancePayment = (order: Order) => {
    setPayingBalanceOrder(order);
    setBalanceReceiptPreview('');
    setBalanceReceiptName('');
    setBalanceMpesaRef('');
    setBalanceErrorMessage('');
  };

  const handleSubmitBalancePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payingBalanceOrder) return;
    if (!balanceReceiptPreview) {
      setBalanceErrorMessage('Please upload proof of your 75% balance payment.');
      return;
    }

    setIsSubmittingBalance(true);
    setBalanceErrorMessage('');
    try {
      const ok = await payBalance(
        payingBalanceOrder.id,
        balanceReceiptPreview,
        balanceReceiptName || `balance_${payingBalanceOrder.id}.jpg`,
        balanceMpesaRef
      );
      if (ok) {
        setPayingBalanceOrder(null);
      } else {
        setBalanceErrorMessage('Unable to submit balance proof. Please try again.');
      }
    } catch (err) {
      setBalanceErrorMessage(err instanceof Error ? err.message : 'Unable to submit balance proof.');
    } finally {
      setIsSubmittingBalance(false);
    }
  };

  const handleOpenRating = (order: Order) => {
    setRatingOrder(order);
    setRatingStars(order.clientRating || 5);
    setRatingFeedback(order.clientFeedback || '');
  };

  const handleSubmitRating = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ratingOrder) return;
    await rateWorker(ratingOrder.id, ratingStars, ratingFeedback.trim());
    setRatingOrder(null);
  };

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-[#0E7A4C] uppercase tracking-wider">
                Client Portal
              </span>
              <span>·</span>
              <span className="text-xs text-slate-500">
                {currentUser?.displayName ? `Signed in as ${currentUser.displayName}` : 'Client Dashboard'}
              </span>
            </div>
            <h1 className="text-2xl font-black text-slate-900 mt-0.5">
              My Academic &amp; Creative Orders
            </h1>
            <p className="text-xs text-slate-600 mt-1">
              Protected Escrow: 25% deposit held safely until completion · 75% balance payable after delivery review.
            </p>
          </div>

          <button
            onClick={() => navigate('/order')}
            className="px-4 py-2.5 bg-[#0E7A4C] hover:bg-[#0b633d] text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-2 shadow-sm self-start sm:self-auto"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Place New Order</span>
          </button>
        </div>

        {/* Search & Filters */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between">
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by topic, ID, or category..."
              className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
            />
          </div>

          <div className="flex items-center gap-1 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 text-xs">
            {['All', 'Pending Payment', 'Paid', 'Confirmed', 'In Progress', 'Completed'].map((tab) => (
              <button
                key={tab}
                onClick={() => setStatusFilter(tab)}
                className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition ${
                  statusFilter === tab
                    ? 'bg-[#0E7A4C] text-white font-semibold shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Client Tasks Table */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase">
                <tr>
                  <th className="py-3.5 px-4">Order ID</th>
                  <th className="py-3.5 px-4">Service &amp; Topic</th>
                  <th className="py-3.5 px-4">Assigned Specialist</th>
                  <th className="py-3.5 px-4">Delivery Timer</th>
                  <th className="py-3.5 px-4 text-right">Price / 25% Deposit</th>
                  <th className="py-3.5 px-4 text-center">Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredOrders.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-12 text-slate-400">
                      <FileText className="w-8 h-8 mx-auto mb-2 opacity-50" />
                      <p className="font-semibold text-sm">No orders found</p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Click "Place New Order" to request essays, presentations, or digital services.
                      </p>
                    </td>
                  </tr>
                ) : (
                  filteredOrders.map((order) => {
                    const timer = getHoursRemaining(order.deadline);

                    return (
                      <tr key={order.id} className="hover:bg-slate-50/80 transition-colors">
                        {/* Order ID */}
                        <td className="py-3.5 px-4 font-mono font-bold text-slate-900 whitespace-nowrap">
                          <button
                            onClick={() => setSelectedOrder(order)}
                            className="text-[#0E7A4C] hover:underline"
                          >
                            {order.id}
                          </button>
                        </td>

                        {/* Service & Topic */}
                        <td className="py-3.5 px-4 max-w-xs sm:max-w-md">
                          <span className="inline-block px-1.5 py-0.2 bg-emerald-50 text-[#0E7A4C] font-semibold text-[10px] rounded mb-0.5">
                            {order.category}
                          </span>
                          <div className="font-semibold text-slate-900 line-clamp-1">
                            {order.topic}
                          </div>
                          <div className="text-[11px] text-slate-500">
                            {order.quantityValue} {order.quantityUnit || 'units'} · {order.academicLevel || order.serviceTier || 'Standard'}
                          </div>
                        </td>

                        {/* Assigned Specialist (Worker contact hidden for privacy) */}
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          {order.workerDisplayName ? (
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-1.5 font-semibold text-slate-800">
                                <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                                <span>{order.workerDisplayName}</span>
                              </div>
                              <button
                                onClick={() => setChatOrder(order)}
                                className="text-[10px] text-[#0E7A4C] font-semibold hover:underline flex items-center gap-1"
                              >
                                <MessageSquare className="w-3 h-3" />
                                <span>Open Task Chat</span>
                              </button>
                            </div>
                          ) : (
                            <span className="text-slate-400 italic text-[11px]">Matching specialist...</span>
                          )}
                        </td>

                        {/* Countdown */}
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <div className="flex items-center gap-1.5">
                            <Clock className={`w-3.5 h-3.5 ${timer.isOverdue ? 'text-red-500' : 'text-amber-600'}`} />
                            <span className={`font-mono font-bold ${timer.isOverdue ? 'text-red-600' : 'text-slate-800'}`}>
                              {timer.text}
                            </span>
                          </div>
                          <button
                            onClick={() => setEditingDeliveryOrder(order)}
                            className="text-[10px] text-blue-600 hover:underline mt-0.5 block font-semibold"
                          >
                            Adjust Deadline
                          </button>
                        </td>

                        {/* Price & Deposit (Client CANNOT see worker pay) */}
                        <td className="py-3.5 px-4 text-right whitespace-nowrap">
                          <div className="font-mono font-bold text-slate-900">
                            KES {order.totalAmount.toLocaleString()}
                          </div>
                          <div className="text-[11px] text-[#0E7A4C] font-semibold">
                            25% Escrow: KES {order.depositAmount.toLocaleString()}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            Balance: KES {order.balanceAmount.toLocaleString()}
                          </div>
                        </td>

                        {/* Status */}
                        <td className="py-3.5 px-4 text-center whitespace-nowrap">
                          <StatusBadge status={order.status} size="sm" />
                          {order.balancePaid && (
                            <div className="text-[9px] text-emerald-700 font-bold mt-0.5">
                              ✓ 75% Balance Paid
                            </div>
                          )}
                        </td>

                        {/* Actions */}
                        <td className="py-3.5 px-4 text-right whitespace-nowrap space-x-1.5">
                          {order.status === 'Pending Payment' && (
                            <button
                              onClick={() => navigate(`/checkout/${order.id}`)}
                              className="px-2.5 py-1 bg-[#0E7A4C] hover:bg-[#0b633d] text-white font-bold rounded text-[11px] transition shadow-xs"
                            >
                              Pay 25% Deposit
                            </button>
                          )}

                          {order.status === 'Completed' && !order.balancePaid && (
                            <button
                              onClick={() => handleOpenBalancePayment(order)}
                              className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded text-[11px] transition shadow-xs"
                            >
                              Pay 75% Balance
                            </button>
                          )}

                          {order.status === 'Completed' && (
                            <button
                              onClick={() => handleOpenRating(order)}
                              className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 font-bold rounded text-[11px] transition"
                            >
                              {order.clientRating ? `★ ${order.clientRating}` : 'Rate Specialist'}
                            </button>
                          )}

                          <button
                            onClick={() => setSelectedOrder(order)}
                            className="px-2.5 py-1 bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 font-semibold rounded text-[11px] transition shadow-xs"
                          >
                            <Eye className="w-3.5 h-3.5 text-[#0E7A4C] inline mr-1" />
                            <span>Details</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal: 75% Balance Payment to Equity Paybill 247247 */}
        {payingBalanceOrder && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
              <div className="bg-[#0E7A4C] text-white px-6 py-4 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-base">Pay 75% Delivery Balance</h3>
                  <p className="text-[11px] text-emerald-100">
                    Order {payingBalanceOrder.id} · Solution Completed
                  </p>
                </div>
                <button
                  onClick={() => setPayingBalanceOrder(null)}
                  className="p-1 rounded text-white/80 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSubmitBalancePayment} className="p-6 space-y-4 text-xs">
                {/* Paybill Instructions */}
                <div className="bg-emerald-50 border border-emerald-200 p-3.5 rounded-xl text-[#0E7A4C] space-y-2">
                  <div className="font-bold text-xs uppercase tracking-wider text-emerald-900">
                    Lipa na M-Pesa Balance Payment:
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center text-slate-800">
                    <div className="bg-white p-2 rounded-lg border border-emerald-100">
                      <span className="text-[10px] text-slate-500 block">Paybill</span>
                      <span className="font-mono font-bold text-xs">{settings.paybill}</span>
                    </div>
                    <div className="bg-white p-2 rounded-lg border border-emerald-100">
                      <span className="text-[10px] text-slate-500 block">Account</span>
                      <span className="font-mono font-bold text-xs">{settings.account}</span>
                    </div>
                    <div className="bg-white p-2 rounded-lg border border-emerald-100">
                      <span className="text-[10px] text-slate-500 block">75% Balance</span>
                      <span className="font-mono font-bold text-xs text-[#0E7A4C]">
                        KES {payingBalanceOrder.balanceAmount.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>

                {balanceErrorMessage && (
                  <div className="bg-red-50 border border-red-200 text-red-700 p-2.5 rounded-lg">
                    {balanceErrorMessage}
                  </div>
                )}

                {/* Screenshot Upload or Auto-Fill */}
                <div className="space-y-2">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">
                      Upload Balance Payment Screenshot <span className="text-red-500">*</span>
                    </label>
                  </div>

                  {!balanceReceiptPreview ? (
                    <div
                      onClick={() => balanceFileInputRef.current?.click()}
                      className="border-2 border-dashed border-slate-300 hover:border-[#0E7A4C] rounded-xl p-6 text-center cursor-pointer transition bg-slate-50"
                    >
                      <input
                        ref={balanceFileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          setBalanceReceiptName(file.name);
                          setBalanceErrorMessage('');
                          try {
                            const compressed = await compressReceiptImage(file);
                            setBalanceReceiptPreview(compressed);
                          } catch (err) {
                            setBalanceErrorMessage(
                              err instanceof Error ? err.message : 'Unable to process screenshot.'
                            );
                          }
                        }}
                        className="hidden"
                      />
                      <UploadCloud className="w-8 h-8 text-slate-400 mx-auto mb-1" />
                      <p className="text-xs font-semibold text-slate-700">
                        Click to select M-Pesa transaction screenshot
                      </p>
                      <span className="text-[10px] text-slate-500">PNG, JPG or WEBP</span>
                    </div>
                  ) : (
                    <div className="border border-slate-200 rounded-xl p-3 bg-slate-50 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <img
                          src={balanceReceiptPreview}
                          alt="Receipt"
                          className="w-12 h-12 object-contain bg-white rounded border border-slate-200"
                        />
                        <div>
                          <div className="font-bold text-slate-900 truncate max-w-[200px]">
                            {balanceReceiptName || 'balance_payment.png'}
                          </div>
                          <span className="text-[10px] text-emerald-600 font-medium">✓ Proof attached</span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setBalanceReceiptPreview('');
                          setBalanceReceiptName('');
                        }}
                        className="text-red-600 hover:underline font-semibold"
                      >
                        Remove
                      </button>
                    </div>
                  )}
                </div>

                <div>
                  <label htmlFor="balance-mpesa-ref" className="font-semibold text-slate-700 block mb-1">
                    M-Pesa Transaction Reference Code
                  </label>
                  <input
                    id="balance-mpesa-ref"
                    type="text"
                    value={balanceMpesaRef}
                    onChange={(e) => setBalanceMpesaRef(e.target.value.toUpperCase())}
                    placeholder="e.g. QK984218NP"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono uppercase focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setPayingBalanceOrder(null)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingBalance || !balanceReceiptPreview}
                    className="px-5 py-2 bg-[#0E7A4C] hover:bg-[#0b633d] disabled:bg-slate-300 text-white rounded-lg font-bold shadow-sm"
                  >
                    {isSubmittingBalance ? 'Confirming...' : 'Confirm Balance Paid (KES ' + payingBalanceOrder.balanceAmount.toLocaleString() + ')'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal: Rate Specialist */}
        {ratingOrder && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
              <div className="bg-[#0E7A4C] text-white px-6 py-4 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-base">Rate Specialist</h3>
                  <p className="text-[11px] text-emerald-100">
                    {ratingOrder.workerDisplayName || 'Assigned Writer'} · {ratingOrder.id}
                  </p>
                </div>
                <button
                  onClick={() => setRatingOrder(null)}
                  className="p-1 rounded text-white/80 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSubmitRating} className="p-6 space-y-4 text-xs">
                <div>
                  <label className="font-bold text-slate-800 block mb-2 text-center">
                    How satisfied are you with the delivery quality?
                  </label>
                  <div className="flex items-center justify-center gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setRatingStars(star)}
                        className="p-1.5 focus:outline-none transition hover:scale-110"
                      >
                        <Star
                          className={`w-7 h-7 ${
                            star <= ratingStars
                              ? 'text-amber-500 fill-amber-500'
                              : 'text-slate-300'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                  <div className="text-center font-bold text-slate-700 mt-1">
                    {ratingStars} of 5 Stars
                  </div>
                </div>

                <div>
                  <label htmlFor="rating-feedback-input" className="font-semibold text-slate-700 block mb-1">
                    Client Feedback / Review Note
                  </label>
                  <textarea
                    id="rating-feedback-input"
                    rows={3}
                    value={ratingFeedback}
                    onChange={(e) => setRatingFeedback(e.target.value)}
                    placeholder="Fast delivery, great citations, followed instructions accurately..."
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setRatingOrder(null)}
                    className="px-4 py-2 bg-slate-100 text-slate-700 rounded-lg font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-[#0E7A4C] hover:bg-[#0b633d] text-white rounded-lg font-bold shadow-sm"
                  >
                    Submit Review
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal: Edit Delivery Time */}
        {editingDeliveryOrder && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
              <div className="bg-[#0E7A4C] text-white px-5 py-4 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm">Adjust Deadline: {editingDeliveryOrder.id}</h3>
                  <p className="text-[11px] text-emerald-100">Extend or expedite delivery schedule</p>
                </div>
                <button
                  onClick={() => setEditingDeliveryOrder(null)}
                  className="p-1 rounded text-white/80 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-6 space-y-4 text-xs">
                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                  <span className="text-slate-500 block">Current Delivery Time:</span>
                  <span className="text-xl font-black font-mono text-slate-900">
                    {editingDeliveryOrder.deliveryHours} Hours
                  </span>
                  <div className="text-[11px] text-slate-500 mt-1">
                    Deadline: {new Date(editingDeliveryOrder.deadline).toLocaleString('en-KE')}
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="font-semibold text-slate-700 block">
                    Adjust Turnaround (+6H / -6H):
                  </span>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => {
                        editDeliveryTime(editingDeliveryOrder.id, 6);
                        setEditingDeliveryOrder((prev) =>
                          prev ? { ...prev, deliveryHours: prev.deliveryHours + 6 } : null
                        );
                      }}
                      className="p-3 bg-emerald-50 hover:bg-emerald-100 text-[#0E7A4C] font-bold rounded-xl border border-emerald-200 transition flex items-center justify-center gap-1.5"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Extend +6 Hours</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        editDeliveryTime(editingDeliveryOrder.id, -6);
                        setEditingDeliveryOrder((prev) =>
                          prev ? { ...prev, deliveryHours: Math.max(3, prev.deliveryHours - 6) } : null
                        );
                      }}
                      className="p-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl border border-slate-200 transition flex items-center justify-center gap-1.5"
                    >
                      <Minus className="w-4 h-4" />
                      <span>Expedite -6 Hours</span>
                    </button>
                  </div>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={() => setEditingDeliveryOrder(null)}
                    className="px-4 py-2 bg-slate-800 text-white font-bold rounded-lg text-xs"
                  >
                    Done
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Modal: Order Details */}
        {selectedOrder && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden border border-slate-200">
              <div className="bg-[#0E7A4C] text-white px-6 py-4 flex items-center justify-between">
                <div>
                  <div className="text-xs text-emerald-200 font-mono font-bold">
                    Order: {selectedOrder.id} ({selectedOrder.category})
                  </div>
                  <h3 className="text-base font-bold text-white mt-0.5 line-clamp-1">
                    {selectedOrder.topic}
                  </h3>
                </div>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="p-1 rounded-lg text-white/80 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-6 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
                {/* Status bar */}
                <div className="flex items-center justify-between bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                  <div>
                    <span className="text-slate-500 block">Status:</span>
                    <div className="mt-1">
                      <StatusBadge status={selectedOrder.status} size="md" />
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-slate-500 block">25% Escrow Paid:</span>
                    <span className="text-lg font-black text-[#0E7A4C] font-mono">
                      KES {selectedOrder.depositAmount.toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Assigned specialist & Chat shortcut */}
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 flex items-center justify-between">
                  <div>
                    <span className="text-slate-400 block">Assigned Specialist:</span>
                    <span className="font-bold text-slate-800 text-sm">
                      {selectedOrder.workerDisplayName || 'Matching specialist...'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        const target = selectedOrder;
                        setSelectedOrder(null);
                        setChatOrder(target);
                      }}
                      className="px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 font-bold rounded-lg flex items-center gap-1.5 shadow-xs"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-[#0E7A4C]" />
                      <span>Chat with Specialist</span>
                    </button>
                  </div>
                </div>

                {/* Pricing Breakdown (NO WORKER PAY / ADMIN PROFIT SHOWN) */}
                <div className="grid grid-cols-3 gap-2 bg-emerald-50/60 p-3 rounded-xl border border-emerald-100 text-center">
                  <div>
                    <span className="text-[10px] text-slate-500 block">Total Price</span>
                    <span className="font-mono font-bold text-slate-900">KES {selectedOrder.totalAmount.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">25% Deposit Paid</span>
                    <span className="font-mono font-bold text-[#0E7A4C]">KES {selectedOrder.depositAmount.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">75% Delivery Balance</span>
                    <span className="font-mono font-bold text-amber-700">KES {selectedOrder.balanceAmount.toLocaleString()}</span>
                  </div>
                </div>

                {/* Instructions */}
                <div>
                  <span className="font-bold text-slate-800 block mb-1">Your Instructions:</span>
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-slate-700 whitespace-pre-wrap">
                    {selectedOrder.instructions}
                  </div>
                </div>

                {/* Solution Download if Completed */}
                {(selectedOrder.status === 'Completed' || selectedOrder.status === 'Paid to Writer') && (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-emerald-950 flex items-center gap-1.5">
                        <FileCheck2 className="w-5 h-5 text-emerald-600" />
                        <span>Completed Delivery Solution</span>
                      </span>
                      <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded">
                        Passed Quality Review
                      </span>
                    </div>
                    {selectedOrder.submissionNotes && (
                      <p className="italic text-slate-700 bg-white p-2 rounded border border-emerald-100">
                        "{selectedOrder.submissionNotes}"
                      </p>
                    )}
                    <div className="pt-1 flex items-center justify-between">
                      <span className="font-mono text-slate-800 font-semibold">
                        {selectedOrder.solutionDocumentName || 'Completed_Delivery_File'}
                      </span>
                      {selectedOrder.solutionDocumentUrl ? (
                        <a
                          href={selectedOrder.solutionDocumentUrl}
                          download={selectedOrder.solutionDocumentName || 'delivery_solution'}
                          className="px-3.5 py-1.5 bg-[#0E7A4C] hover:bg-[#0b633d] text-white font-bold rounded-lg flex items-center gap-1.5 shadow-sm"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Download Delivery</span>
                        </a>
                      ) : (
                        <span className="text-[11px] text-emerald-700 font-semibold">
                          Submitted by Specialist (check task chat for attachments)
                        </span>
                      )}
                    </div>
                  </div>
                )}
              </div>

              <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex justify-end">
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg font-semibold text-xs"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Screenshot Viewer Modal */}
        {viewScreenshotOrder && (
          <ReceiptViewerModal
            isOpen={!!viewScreenshotOrder}
            onClose={() => setViewScreenshotOrder(null)}
            screenshotUrl={viewScreenshotOrder.screenshotUrl}
            orderId={viewScreenshotOrder.id}
            amount={viewScreenshotOrder.depositAmount}
            paymentRef={viewScreenshotOrder.paymentReference}
          />
        )}

        {/* Task Chat Modal */}
        {chatOrder && (
          <TaskChatModal
            isOpen={!!chatOrder}
            onClose={() => setChatOrder(null)}
            order={chatOrder}
          />
        )}
      </div>
    </div>
  );
};
