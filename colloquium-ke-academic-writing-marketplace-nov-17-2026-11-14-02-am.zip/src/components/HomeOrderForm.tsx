import React, { useState, useMemo, useRef } from 'react';
import { useOrders } from '../context/OrderContext';
import {
  AcademicLevel,
  CitationStyle,
  ServiceType,
  JobCategory,
  TaskFile,
} from '../types';
import { calculateServicePrice } from '../utils/pricingCalculator';
import { fileToSafeTaskFile } from '../utils/imageCompress';
import { ColloquiumLogoIcon } from './ColloquiumLogoIcon';
import {
  Calculator,
  Shield,
  ArrowRight,
  UploadCloud,
  FileText,
  Clock,
  Presentation,
  CheckCheck,
  Headphones,
  Image,
  Video,
  PenTool,
  Globe,
  Trash2,
  Lock,
} from 'lucide-react';

interface HomeOrderFormProps {
  navigate: (path: string) => void;
}

export const HomeOrderForm: React.FC<HomeOrderFormProps> = ({ navigate }) => {
  const { createOrder, currentUser, userRole, setPendingOrderDraft } = useOrders();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // If logged in as worker, prevent creating order (Requirement 3B: "Worker CANNOT create orders")
  if (userRole === 'worker') {
    return (
      <div className="min-h-screen bg-slate-50 py-16 px-4 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-2xl p-8 border border-slate-200 shadow-md text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center mx-auto">
            <Lock className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-black text-slate-900">Worker Portal Active</h2>
          <p className="text-xs text-slate-600 leading-relaxed">
            Specialists accounts cannot place orders directly. Please switch to your specialist workspace to claim available tasks, or sign out to order as a client.
          </p>
          <div className="pt-2 flex flex-col gap-2">
            <button
              onClick={() => navigate('/worker/dashboard')}
              className="w-full py-2.5 bg-[#0E7A4C] hover:bg-[#0b633d] text-white text-xs font-bold rounded-xl shadow-sm transition"
            >
              Go to Specialist Workspace
            </button>
            <button
              onClick={() => navigate('/')}
              className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition"
            >
              Return Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 1. Service Selection
  const [serviceType, setServiceType] = useState<ServiceType>('Academic');
  const [topic, setTopic] = useState('');
  const [instructions, setInstructions] = useState('');

  // 2. Specific Service Parameters
  // Academic & Proofreading
  const [pages, setPages] = useState<number>(3);
  const [academicLevel, setAcademicLevel] = useState<AcademicLevel>('Undergraduate');
  const [citationStyle, setCitationStyle] = useState<CitationStyle>('APA 7th');
  const [deliveryHours, setDeliveryHours] = useState<number>(48);

  // PowerPoint
  const [slides, setSlides] = useState<number>(10);
  const [pptTier, setPptTier] = useState<'Basic' | 'Premium'>('Basic');

  // Transcription
  const [audioMinutes, setAudioMinutes] = useState<number>(15);
  const [transcriptionTier, setTranscriptionTier] = useState<'Clear' | 'Difficult'>('Clear');

  // Photo Editing
  const [imagesCount, setImagesCount] = useState<number>(3);
  const [photoTier, setPhotoTier] = useState<'Basic' | 'Advanced'>('Basic');

  // Video Editing
  const [videoMinutes, setVideoMinutes] = useState<number>(3);
  const [videoTier, setVideoTier] = useState<'Basic' | 'Advanced'>('Basic');

  // Logo Making
  const [logoTier, setLogoTier] = useState<'Basic' | 'Premium'>('Basic');

  // Web Design
  const [webPages, setWebPages] = useState<number>(3);
  const [webTier, setWebTier] = useState<'Basic' | 'Premium'>('Basic');

  // File Uploads
  const [attachedFiles, setAttachedFiles] = useState<TaskFile[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Error feedback
  const [errorMessage, setErrorMessage] = useState('');

  // Live Price Calculation using pricingCalculator
  const pricing = useMemo(() => {
    let tierToUse: any = 'Basic';
    let qtyVal = pages;

    if (serviceType === 'PowerPoint') {
      tierToUse = pptTier;
      qtyVal = slides;
    } else if (serviceType === 'Transcription') {
      tierToUse = transcriptionTier;
      qtyVal = audioMinutes;
    } else if (serviceType === 'Photo Editing') {
      tierToUse = photoTier;
      qtyVal = imagesCount;
    } else if (serviceType === 'Video Editing') {
      tierToUse = videoTier;
      qtyVal = videoMinutes;
    } else if (serviceType === 'Logo Making') {
      tierToUse = logoTier;
      qtyVal = logoTier === 'Premium' ? 4 : 2;
    } else if (serviceType === 'Web Design') {
      tierToUse = webTier;
      qtyVal = webPages;
    }

    return calculateServicePrice({
      serviceType,
      academicLevel,
      deliveryHours,
      pages: serviceType === 'Web Design' ? webPages : pages,
      slides,
      audioMinutes,
      imagesCount,
      videoMinutes,
      tier: tierToUse,
    });
  }, [
    serviceType,
    academicLevel,
    deliveryHours,
    pages,
    slides,
    pptTier,
    audioMinutes,
    transcriptionTier,
    imagesCount,
    photoTier,
    videoMinutes,
    videoTier,
    logoTier,
    webPages,
    webTier,
  ]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    setErrorMessage('');
    const filesArr = Array.from(e.target.files);
    try {
      const processed = await Promise.all(
        filesArr.map((f) => fileToSafeTaskFile(f, 'client'))
      );
      setAttachedFiles((prev) => [...prev, ...processed].slice(0, 10));
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Unable to attach file.');
    }
  };

  const removeFile = (index: number) => {
    setAttachedFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!topic.trim()) {
      setErrorMessage('Please enter the project / task title or research topic.');
      return;
    }

    let categoryName: JobCategory = 'Academic Writing';
    let qtyUnit = 'pages';
    let qtyValue = pages;

    if (serviceType === 'Academic') {
      categoryName = 'Academic Writing';
      qtyUnit = 'pages';
      qtyValue = pages;
    } else if (serviceType === 'Proofreading') {
      categoryName = 'Proofreading';
      qtyUnit = 'pages';
      qtyValue = pages;
    } else if (serviceType === 'PowerPoint') {
      categoryName = 'PowerPoint Presentation';
      qtyUnit = 'slides';
      qtyValue = slides;
    } else if (serviceType === 'Transcription') {
      categoryName = 'Transcription';
      qtyUnit = 'minutes';
      qtyValue = audioMinutes;
    } else if (serviceType === 'Photo Editing') {
      categoryName = 'Photo Editing';
      qtyUnit = 'images';
      qtyValue = imagesCount;
    } else if (serviceType === 'Video Editing') {
      categoryName = 'Video Editing';
      qtyUnit = 'minutes';
      qtyValue = videoMinutes;
    } else if (serviceType === 'Logo Making') {
      categoryName = 'Logo Making';
      qtyUnit = 'concepts';
      qtyValue = logoTier === 'Premium' ? 4 : 2;
    } else if (serviceType === 'Web Design') {
      categoryName = 'Web Design';
      qtyUnit = 'pages';
      qtyValue = webPages;
    }

    const deadlineDate = new Date(Date.now() + deliveryHours * 3600 * 1000).toISOString();
    const draftPayload = {
      topic: topic.trim(),
      category: categoryName,
      serviceType,
      serviceTier:
        serviceType === 'PowerPoint'
          ? pptTier
          : serviceType === 'Transcription'
          ? transcriptionTier
          : serviceType === 'Photo Editing'
          ? photoTier
          : serviceType === 'Video Editing'
          ? videoTier
          : serviceType === 'Logo Making'
          ? logoTier
          : serviceType === 'Web Design'
          ? webTier
          : academicLevel,
      quantityValue: qtyValue,
      quantityUnit: qtyUnit,
      pages: serviceType === 'Academic' || serviceType === 'Proofreading' ? pages : 1,
      deliveryHours,
      deadline: deadlineDate,
      academicLevel: serviceType === 'Academic' || serviceType === 'Proofreading' ? academicLevel : undefined,
      citationStyle: serviceType === 'Academic' ? citationStyle : undefined,
      instructions: instructions.trim() || 'Please follow attached guidelines and standard professional standards.',
      totalAmount: pricing.totalPrice,
      depositAmount: pricing.depositAmount,
      balanceAmount: pricing.balanceAmount,
      workerPayAmount: pricing.workerPay,
      adminProfitAmount: pricing.adminProfit,
      files: attachedFiles,
    };

    if (!currentUser || (userRole !== 'client' && userRole !== 'admin')) {
      setPendingOrderDraft(draftPayload);
      navigate('/client/register');
      return;
    }

    setIsSubmitting(true);
    try {
      const created = await createOrder(draftPayload);
      navigate(`/checkout/${created.id}`);
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Unable to save order. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-16">
      {/* Hero Header */}
      <section className="bg-gradient-to-b from-[#0E7A4C] via-[#0b633d] to-[#08432a] text-white pt-10 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 px-3.5 py-1.5 rounded-full text-xs font-medium text-emerald-200">
            <Shield className="w-3.5 h-3.5 text-emerald-300" />
            <span>Vetted Academic, Digital &amp; Creative Specialists</span>
          </div>

          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
            Order Academic, Digital &amp; Creative Services
          </h1>
          <p className="text-sm sm:text-base text-emerald-100 max-w-2xl leading-relaxed">
            "From essays and research to PowerPoint, logos, websites, video and photo editing - order any task, pay securely, get it done by verified experts."
          </p>
        </div>
      </section>

      {/* Main Order Form Section */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
        <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
          {/* Service Selector Tabs */}
          <div className="bg-slate-100/80 p-2 sm:p-3 border-b border-slate-200">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block px-2 mb-1.5">
              Select Service Category:
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-bold">
              {[
                { type: 'Academic' as ServiceType, label: 'Academic & Essays', icon: FileText },
                { type: 'Proofreading' as ServiceType, label: 'Proofreading', icon: CheckCheck },
                { type: 'PowerPoint' as ServiceType, label: 'PowerPoint Slides', icon: Presentation },
                { type: 'Transcription' as ServiceType, label: 'Transcription', icon: Headphones },
                { type: 'Photo Editing' as ServiceType, label: 'Photo Editing', icon: Image },
                { type: 'Video Editing' as ServiceType, label: 'Video Editing', icon: Video },
                { type: 'Logo Making' as ServiceType, label: 'Logo Making', icon: PenTool },
                { type: 'Web Design' as ServiceType, label: 'Web Design', icon: Globe },
              ].map((item) => {
                const Icon = item.icon;
                const isSelected = serviceType === item.type;
                return (
                  <button
                    key={item.type}
                    type="button"
                    onClick={() => setServiceType(item.type)}
                    className={`p-2.5 rounded-xl border flex items-center gap-2 transition text-left ${
                      isSelected
                        ? 'bg-[#0E7A4C] text-white border-[#0E7A4C] shadow-sm'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-white' : 'text-[#0E7A4C]'}`} />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-6">
            {errorMessage && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-xs flex items-center gap-2">
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Topic Input */}
            <div>
              <label htmlFor="order-topic-input" className="block text-xs font-bold text-slate-800 mb-1.5">
                Task / Project Title or Research Question <span className="text-red-500">*</span>
              </label>
              <input
                id="order-topic-input"
                type="text"
                required
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder={
                  serviceType === 'Academic'
                    ? 'e.g. Econometric Analysis of Agricultural Output in Rift Valley'
                    : serviceType === 'PowerPoint'
                    ? 'e.g. Pitch Deck for Agri-Tech Mobile App Seed Funding'
                    : serviceType === 'Web Design'
                    ? 'e.g. Responsive 4-Page Business Website for Legal Consultancy'
                    : serviceType === 'Logo Making'
                    ? 'e.g. Minimalist Tech Logo for Fintech Payment Gateway'
                    : 'Describe your project or task...'
                }
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
              />
            </div>

            {/* DYNAMIC CALCULATOR PARAMETERS ACCORDING TO PROMPT SECTION 4 */}

            {/* 1. Academic Writing (Essays, Assignments, Research) */}
            {serviceType === 'Academic' && (
              <div className="space-y-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[#0E7A4C]" />
                  <span>Academic Pricing Options (1 Page = 275 words)</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  {/* Academic Level */}
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Academic Level <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={academicLevel}
                      onChange={(e) => setAcademicLevel(e.target.value as AcademicLevel)}
                      className="w-full p-2.5 rounded-lg border border-slate-300 bg-white font-semibold text-xs focus:ring-2 focus:ring-[#0E7A4C]"
                    >
                      <option value="High School">High School (400 KES/pg)</option>
                      <option value="Diploma">Diploma (550 KES/pg)</option>
                      <option value="Undergraduate">Undergraduate (700 KES/pg)</option>
                      <option value="Master's">Masters (1,000 KES/pg)</option>
                      <option value="PhD">PhD (1,500 KES/pg)</option>
                    </select>
                  </div>

                  {/* Pages Count */}
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Number of Pages ({pages * 275} words)
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min={1}
                        max={100}
                        value={pages}
                        onChange={(e) => setPages(Math.max(1, Number(e.target.value) || 1))}
                        className="w-full p-2.5 rounded-lg border border-slate-300 font-mono font-bold text-xs"
                      />
                      <span className="text-xs text-slate-500 shrink-0">pgs</span>
                    </div>
                  </div>

                  {/* Urgency */}
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Deadline / Urgency
                    </label>
                    <select
                      value={deliveryHours}
                      onChange={(e) => setDeliveryHours(Number(e.target.value))}
                      className="w-full p-2.5 rounded-lg border border-slate-300 bg-white font-semibold text-xs focus:ring-2 focus:ring-[#0E7A4C]"
                    >
                      <option value={48}>48+ Hours (Normal)</option>
                      <option value={24}>24 Hours (+30% rush)</option>
                      <option value={12}>12 Hours (+50% rush)</option>
                      <option value={6}>6 Hours (+100% rush)</option>
                    </select>
                  </div>
                </div>

                {/* Citation Style */}
                <div className="w-full sm:w-1/3 text-xs">
                  <label className="block font-bold text-slate-700 mb-1">
                    Citation &amp; Referencing Style
                  </label>
                  <select
                    value={citationStyle}
                    onChange={(e) => setCitationStyle(e.target.value as CitationStyle)}
                    className="w-full p-2.5 rounded-lg border border-slate-300 bg-white font-semibold text-xs"
                  >
                    <option value="APA 7th">APA 7th Edition</option>
                    <option value="MLA 9th">MLA 9th Edition</option>
                    <option value="Harvard">Harvard Referencing</option>
                    <option value="Chicago">Chicago / Turabian</option>
                    <option value="IEEE">IEEE Format</option>
                  </select>
                </div>
              </div>
            )}

            {/* 2. Proofreading */}
            {serviceType === 'Proofreading' && (
              <div className="space-y-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider flex items-center gap-2">
                  <CheckCheck className="w-4 h-4 text-[#0E7A4C]" />
                  <span>Proofreading &amp; Turnitin Options</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Academic Complexity</label>
                    <select
                      value={academicLevel}
                      onChange={(e) => setAcademicLevel(e.target.value as AcademicLevel)}
                      className="w-full p-2.5 rounded-lg border border-slate-300 bg-white font-semibold text-xs"
                    >
                      <option value="High School">High School / Diploma (200 KES/pg)</option>
                      <option value="Undergraduate">Undergraduate (300 KES/pg)</option>
                      <option value="Master's">Masters / PhD (500 KES/pg)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Number of Pages</label>
                    <input
                      type="number"
                      min={1}
                      max={200}
                      value={pages}
                      onChange={(e) => setPages(Math.max(1, Number(e.target.value) || 1))}
                      className="w-full p-2.5 rounded-lg border border-slate-300 font-mono font-bold text-xs"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Urgency</label>
                    <select
                      value={deliveryHours}
                      onChange={(e) => setDeliveryHours(Number(e.target.value))}
                      className="w-full p-2.5 rounded-lg border border-slate-300 bg-white font-semibold text-xs"
                    >
                      <option value={48}>48+ Hours (Normal)</option>
                      <option value={24}>24 Hours (+30%)</option>
                      <option value={12}>12 Hours (+50%)</option>
                      <option value={6}>6 Hours (+100%)</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* 3. PowerPoint Presentations */}
            {serviceType === 'PowerPoint' && (
              <div className="space-y-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider flex items-center gap-2">
                  <Presentation className="w-4 h-4 text-[#0E7A4C]" />
                  <span>PowerPoint Presentation Options (Min 5 slides)</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Design Tier</label>
                    <select
                      value={pptTier}
                      onChange={(e) => setPptTier(e.target.value as 'Basic' | 'Premium')}
                      className="w-full p-2.5 rounded-lg border border-slate-300 bg-white font-semibold text-xs"
                    >
                      <option value="Basic">Basic Presentation (250 KES/slide)</option>
                      <option value="Premium">Premium + Infographics &amp; Notes (400 KES/slide)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Number of Slides (Minimum 5)
                    </label>
                    <input
                      type="number"
                      min={5}
                      max={100}
                      value={slides}
                      onChange={(e) => setSlides(Math.max(5, Number(e.target.value) || 5))}
                      className="w-full p-2.5 rounded-lg border border-slate-300 font-mono font-bold text-xs"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 4. Transcription */}
            {serviceType === 'Transcription' && (
              <div className="space-y-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider flex items-center gap-2">
                  <Headphones className="w-4 h-4 text-[#0E7A4C]" />
                  <span>Audio &amp; Video Transcription (Min KES 200)</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Audio Clarity</label>
                    <select
                      value={transcriptionTier}
                      onChange={(e) => setTranscriptionTier(e.target.value as 'Clear' | 'Difficult')}
                      className="w-full p-2.5 rounded-lg border border-slate-300 bg-white font-semibold text-xs"
                    >
                      <option value="Clear">Clear Audio (40 KES / audio minute)</option>
                      <option value="Difficult">Difficult Audio / Accents / Multiple Speakers (70 KES / min)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Audio Length in Minutes
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={600}
                      value={audioMinutes}
                      onChange={(e) => setAudioMinutes(Math.max(1, Number(e.target.value) || 1))}
                      className="w-full p-2.5 rounded-lg border border-slate-300 font-mono font-bold text-xs"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 5. Photo Editing */}
            {serviceType === 'Photo Editing' && (
              <div className="space-y-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider flex items-center gap-2">
                  <Image className="w-4 h-4 text-[#0E7A4C]" />
                  <span>Photo Editing &amp; Retouching Options</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Editing Complexity</label>
                    <select
                      value={photoTier}
                      onChange={(e) => setPhotoTier(e.target.value as 'Basic' | 'Advanced')}
                      className="w-full p-2.5 rounded-lg border border-slate-300 bg-white font-semibold text-xs"
                    >
                      <option value="Basic">Basic Retouch / Background Clean (300 KES/image)</option>
                      <option value="Advanced">Advanced Skin, High-End Fashion &amp; Compositing (700 KES/image)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Number of Photos / Images</label>
                    <input
                      type="number"
                      min={1}
                      max={50}
                      value={imagesCount}
                      onChange={(e) => setImagesCount(Math.max(1, Number(e.target.value) || 1))}
                      className="w-full p-2.5 rounded-lg border border-slate-300 font-mono font-bold text-xs"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 6. Video Editing */}
            {serviceType === 'Video Editing' && (
              <div className="space-y-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider flex items-center gap-2">
                  <Video className="w-4 h-4 text-[#0E7A4C]" />
                  <span>Video Editing Options (Min KES 1,500)</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Production Tier</label>
                    <select
                      value={videoTier}
                      onChange={(e) => setVideoTier(e.target.value as 'Basic' | 'Advanced')}
                      className="w-full p-2.5 rounded-lg border border-slate-300 bg-white font-semibold text-xs"
                    >
                      <option value="Basic">Basic Cuts, Audio Sync &amp; Titles (1,000 KES/minute)</option>
                      <option value="Advanced">Advanced Motion Graphics, Subtitles &amp; Color Grade (2,000 KES/min)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Final Video Length (Minutes)</label>
                    <input
                      type="number"
                      min={1}
                      max={60}
                      value={videoMinutes}
                      onChange={(e) => setVideoMinutes(Math.max(1, Number(e.target.value) || 1))}
                      className="w-full p-2.5 rounded-lg border border-slate-300 font-mono font-bold text-xs"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 7. Logo Making */}
            {serviceType === 'Logo Making' && (
              <div className="space-y-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider flex items-center gap-2">
                  <PenTool className="w-4 h-4 text-[#0E7A4C]" />
                  <span>Logo &amp; Brand Identity Package</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div
                    onClick={() => setLogoTier('Basic')}
                    className={`p-4 rounded-xl border-2 cursor-pointer transition ${
                      logoTier === 'Basic'
                        ? 'border-[#0E7A4C] bg-emerald-50/50'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 text-sm">Basic Logo Package</span>
                      <span className="font-mono font-black text-[#0E7A4C]">KES 3,000</span>
                    </div>
                    <p className="text-slate-600 mt-1">2 initial concepts, high-res PNG &amp; JPG deliverables.</p>
                  </div>

                  <div
                    onClick={() => setLogoTier('Premium')}
                    className={`p-4 rounded-xl border-2 cursor-pointer transition ${
                      logoTier === 'Premium'
                        ? 'border-[#0E7A4C] bg-emerald-50/50'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 text-sm">Premium Brand Package</span>
                      <span className="font-mono font-black text-[#0E7A4C]">KES 6,000</span>
                    </div>
                    <p className="text-slate-600 mt-1">4 concepts + vector SVG/AI files + color palette + revisions.</p>
                  </div>
                </div>
              </div>
            )}

            {/* 8. Web Design */}
            {serviceType === 'Web Design' && (
              <div className="space-y-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider flex items-center gap-2">
                  <Globe className="w-4 h-4 text-[#0E7A4C]" />
                  <span>Responsive Web Design (Min 1 page)</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Development Tier</label>
                    <select
                      value={webTier}
                      onChange={(e) => setWebTier(e.target.value as 'Basic' | 'Premium')}
                      className="w-full p-2.5 rounded-lg border border-slate-300 bg-white font-semibold text-xs"
                    >
                      <option value="Basic">Basic Responsive Landing/Page (5,000 KES/page)</option>
                      <option value="Premium">Premium Interactive with Animations &amp; CMS (12,000 KES/page)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Number of Website Pages</label>
                    <input
                      type="number"
                      min={1}
                      max={20}
                      value={webPages}
                      onChange={(e) => setWebPages(Math.max(1, Number(e.target.value) || 1))}
                      className="w-full p-2.5 rounded-lg border border-slate-300 font-mono font-bold text-xs"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Instructions */}
            <div>
              <label htmlFor="order-instructions-textarea" className="block text-xs font-bold text-slate-800 mb-1">
                Project Instructions &amp; Mandatory Guidelines
              </label>
              <textarea
                id="order-instructions-textarea"
                rows={3}
                value={instructions}
                onChange={(e) => setInstructions(e.target.value)}
                placeholder="Include formatting requirements, focus topics, dataset details, brand colors, or reference notes..."
                className="w-full p-3 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-[#0E7A4C]"
              />
            </div>

            {/* File Upload Section (Requirement 3A: "Client can upload files") */}
            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1">
                Attach Reference Documents, Rubrics or Samples (Optional)
              </label>
              <div className="border border-dashed border-slate-300 rounded-xl p-4 bg-slate-50 text-center">
                <input
                  type="file"
                  multiple
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2 bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-lg transition inline-flex items-center gap-2 shadow-xs"
                >
                  <UploadCloud className="w-4 h-4 text-[#0E7A4C]" />
                  <span>Choose Files from Device</span>
                </button>
                <p className="text-[11px] text-slate-400 mt-1">
                  Upload PDFs, Word docs, datasets (Excel/CSV), or image references.
                </p>

                {attachedFiles.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-2 justify-center">
                    {attachedFiles.map((f, i) => (
                      <span
                        key={i}
                        className="bg-emerald-50 text-[#0E7A4C] border border-emerald-200 px-2.5 py-1 rounded-lg text-xs flex items-center gap-1.5"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>{f.name}</span>
                        <button
                          type="button"
                          onClick={() => removeFile(i)}
                          className="hover:text-red-500 ml-1"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* EXACT PROMPT SECTION 4 BREAKDOWN:
                Client Checkout shows:
                Total Price = [Calculated]
                Pay Now to Start (25% Escrow) = [Total x 0.25]
                Balance After Delivery = [Total x 0.75]
            */}
            <div className="pt-2 border-t border-slate-200">
              <div className="bg-emerald-50/80 p-5 rounded-2xl border border-emerald-200 flex flex-col md:flex-row md:items-center justify-between gap-5 shadow-xs">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs font-extrabold text-[#0E7A4C] uppercase tracking-wider">
                    <Calculator className="w-4 h-4 text-[#0E7A4C]" />
                    <span>Price Calculator Breakdown</span>
                  </div>

                  <p className="text-xs text-slate-600 font-medium pt-0.5">
                    {pricing.breakdownSummary}
                  </p>

                  <div className="flex flex-wrap items-baseline gap-4 pt-2">
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-semibold block">
                        Estimated Total Price
                      </span>
                      <span className="text-xl sm:text-2xl font-black font-mono text-slate-900 tabular-nums">
                        KES {pricing.totalPrice.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full sm:w-auto px-6 py-3.5 bg-[#0E7A4C] hover:bg-[#0b633d] disabled:opacity-60 text-white text-xs font-bold rounded-xl transition shadow-md hover:shadow-lg flex items-center justify-center gap-2"
                  >
                    <span>
                      {isSubmitting
                        ? 'Saving Order...'
                        : currentUser
                        ? 'Proceed to Checkout'
                        : 'Sign Up / Sign In to Place Order'}
                    </span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
