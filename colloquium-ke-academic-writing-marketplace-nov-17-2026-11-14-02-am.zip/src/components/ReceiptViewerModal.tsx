import React from 'react';
import { X, ExternalLink, Download, CheckCircle, ShieldCheck } from 'lucide-react';

interface ReceiptViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  screenshotUrl?: string;
  orderId: string;
  amount: number;
  paymentRef?: string;
}

export const ReceiptViewerModal: React.FC<ReceiptViewerModalProps> = ({
  isOpen,
  onClose,
  screenshotUrl,
  orderId,
  amount,
  paymentRef,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
        {/* Modal Header */}
        <div className="bg-[#0E7A4C] text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-200" />
            <div>
              <h3 className="text-sm font-bold">Payment Screenshot Proof</h3>
              <p className="text-[11px] text-emerald-100">Order: {orderId} · KES {amount.toLocaleString()}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4">
          {paymentRef && (
            <div className="flex items-center justify-between text-xs bg-slate-50 px-3 py-2 rounded-lg border border-slate-200">
              <span className="text-slate-500">M-Pesa / Reference Code:</span>
              <span className="font-mono font-bold text-slate-800">{paymentRef}</span>
            </div>
          )}

          <div className="rounded-xl border border-slate-200 bg-slate-100 p-2 overflow-hidden flex items-center justify-center min-h-[300px] max-h-[500px]">
            {screenshotUrl ? (
              <img
                src={screenshotUrl}
                alt={`Payment receipt for ${orderId}`}
                className="max-h-[460px] w-auto object-contain rounded-lg shadow-sm"
              />
            ) : (
              <div className="text-center text-slate-400 py-12">
                <p className="text-xs">No screenshot image available</p>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 px-5 py-3 border-t border-slate-200 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">Verified by Colloquium Escrow</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold rounded-lg transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
