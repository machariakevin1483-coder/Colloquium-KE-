import React from 'react';
import { OrderStatus } from '../types';

interface StatusBadgeProps {
  status: OrderStatus;
  size?: 'sm' | 'md' | 'lg';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'md' }) => {
  // Status colors as explicitly required by prompt:
  // Pending red, Paid yellow, Confirmed blue, In Progress purple, Completed green
  const getStyle = (s: OrderStatus) => {
    switch (s) {
      case 'Pending Payment':
        return 'bg-red-50 text-red-700 border-red-200';
      case 'Paid':
        return 'bg-amber-50 text-amber-800 border-amber-300';
      case 'Confirmed':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'In Progress':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'Completed':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Paid to Writer':
        return 'bg-teal-50 text-teal-800 border-teal-300';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  const getDotColor = (s: OrderStatus) => {
    switch (s) {
      case 'Pending Payment':
        return 'bg-red-500';
      case 'Paid':
        return 'bg-amber-500';
      case 'Confirmed':
        return 'bg-blue-500';
      case 'In Progress':
        return 'bg-purple-500';
      case 'Completed':
        return 'bg-emerald-500';
      case 'Paid to Writer':
        return 'bg-teal-600';
      default:
        return 'bg-slate-400';
    }
  };

  const sizeClasses = {
    sm: 'text-[11px] px-2 py-0.5',
    md: 'text-xs px-2.5 py-1',
    lg: 'text-sm px-3 py-1.5 font-semibold',
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-medium rounded-md border whitespace-nowrap ${getStyle(
        status
      )} ${sizeClasses[size]}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${getDotColor(status)} shrink-0`} />
      {status}
    </span>
  );
};
