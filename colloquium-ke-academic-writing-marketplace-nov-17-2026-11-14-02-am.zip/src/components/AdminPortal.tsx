import React, { useState, useEffect } from 'react';
import { useOrders } from '../context/OrderContext';
import { Order, User } from '../types';
import { ADMIN_EMAIL } from '../firebase';
import { StatusBadge } from './StatusBadge';
import { ReceiptViewerModal } from './ReceiptViewerModal';
import { TaskChatModal } from './TaskChatModal';
import {
  CreditCard,
  Settings,
  ListOrdered,
  Search,
  CheckCircle,
  Save,
  RotateCcw,
  Check,
  Users,
  Key,
  AlertCircle,
  X,
  Hourglass,
  MessageSquare,
  Flag,
  Ban,
  AlertTriangle,
  ShieldAlert,
} from 'lucide-react';

interface AdminPortalProps {
  navigate: (path: string) => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({ navigate }) => {
  const {
    orders,
    users,
    settings,
    authLoading,
    sendPasswordReset,
    confirmPaymentByAdmin,
    markInProgress,
    markCompleted,
    payWriter,
    approveWorker,
    updateSettings,
    userRole,
    reports,
    warnUserByAdmin,
    suspendUserByAdmin,
    unbanUserByAdmin,
    deleteOrderChat,
  } = useOrders();

  const [activeTab, setActiveTab] = useState<'tasks' | 'approvals' | 'reports' | 'users' | 'payments' | 'settings'>('tasks');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [viewScreenshotOrder, setViewScreenshotOrder] = useState<Order | null>(null);
  const [selectedUserModal, setSelectedUserModal] = useState<User | null>(null);
  const [chatOrder, setChatOrder] = useState<Order | null>(null);

  // Settings form state
  const [paybill, setPaybill] = useState(settings.paybill);
  const [account, setAccount] = useState(settings.account);
  const [businessName, setBusinessName] = useState(settings.businessName);
  const [pricePerPage, setPricePerPage] = useState(settings.pricePerPage);
  const [depositPercentage, setDepositPercentage] = useState(settings.depositPercentage);
  const [writerPercentage, setWriterPercentage] = useState(settings.writerPercentage);
  const [appApkLink, setAppApkLink] = useState(settings.appApkLink || '');
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [settingsSavedMessage, setSettingsSavedMessage] = useState(false);
  const [settingsError, setSettingsError] = useState('');
  const [resetPasswordNotice, setResetPasswordNotice] = useState('');

  // Sync local form state when Cloud Firestore settings load/update
  useEffect(() => {
    setPaybill(settings.paybill);
    setAccount(settings.account);
    setBusinessName(settings.businessName);
    setPricePerPage(settings.pricePerPage);
    setDepositPercentage(settings.depositPercentage);
    setWriterPercentage(settings.writerPercentage);
    setAppApkLink(settings.appApkLink || '');
  }, [
    settings.paybill,
    settings.account,
    settings.businessName,
    settings.pricePerPage,
    settings.depositPercentage,
    settings.writerPercentage,
    settings.appApkLink,
  ]);

  useEffect(() => {
    if (!authLoading && userRole !== 'admin') {
      const timer = setTimeout(() => {
        navigate('/');
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, [authLoading, userRole, navigate]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="text-center space-y-2">
          <div className="w-8 h-8 border-4 border-[#0E7A4C] border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs font-semibold text-slate-600">Verifying Administrator session...</p>
        </div>
      </div>
    );
  }

  if (userRole !== 'admin') {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl p-8 border border-red-200 shadow-xl text-center space-y-4">
          <div className="w-14 h-14 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center mx-auto border border-red-100">
            <AlertCircle className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-black text-slate-900">Access Denied</h2>
          <p className="text-xs text-slate-600 leading-relaxed">
            The Administrator Hub is strictly restricted. You must be authenticated with Master Admin credentials to view this portal.
          </p>
          <div className="text-[11px] text-slate-400 font-mono">
            Redirecting to homepage...
          </div>
          <button
            onClick={() => navigate('/')}
            className="w-full py-2.5 bg-[#0E7A4C] hover:bg-[#0b633d] text-white text-xs font-bold rounded-xl transition shadow-sm"
          >
            Return to Homepage
          </button>
        </div>
      </div>
    );
  }

  // Filtered Tasks
  const filteredOrders = orders.filter((o) => {
    const matchesSearch =
      o.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.topic.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (o.clientFullName && o.clientFullName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (o.paymentReference && o.paymentReference.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesStatus = statusFilter === 'All' || o.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Filtered Users
  const filteredUsers = users.filter((u) => {
    return (
      u.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.phone.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.role.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  // Pending worker applications
  const pendingWorkers = users.filter(
    (u) => u.role === 'worker' && (u.approvalStatus === 'pending' || u.isApproved === false)
  );

  // Financial Analytics
  const activeTasks = orders.filter((o) => o.status !== 'Completed' && o.status !== 'Paid to Writer').length;

  const totalGrossRevenue = orders.reduce((sum, o) => sum + o.totalAmount, 0);
  const totalWorkerPayouts = orders.reduce((sum, o) => sum + (o.workerPayAmount || Math.floor(o.totalAmount * 0.65)), 0);
  const totalAdminProfit = orders.reduce((sum, o) => sum + (o.adminProfitAmount || Math.floor(o.totalAmount * 0.35)), 0);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingSettings(true);
    setSettingsError('');
    try {
      await updateSettings({
        paybill: paybill.trim(),
        account: account.trim(),
        businessName: businessName.trim(),
        pricePerPage: Number(pricePerPage) || 800,
        depositPercentage: Number(depositPercentage) || 25,
        writerPercentage: Number(writerPercentage) || 65,
        adminPercentage: 100 - (Number(writerPercentage) || 65),
        appApkLink: appApkLink.trim(),
      });
      setSettingsSavedMessage(true);
      setTimeout(() => setSettingsSavedMessage(false), 3000);
    } catch (err) {
      setSettingsError(err instanceof Error ? err.message : 'Unable to save settings to Firestore.');
    } finally {
      setIsSavingSettings(false);
    }
  };

  const handleResetDefaults = async () => {
    setPaybill('247247');
    setAccount('7770187709');
    setBusinessName('Colloquium KE');
    setPricePerPage(800);
    setDepositPercentage(25);
    setWriterPercentage(65);
    setAppApkLink('');
    setIsSavingSettings(true);
    setSettingsError('');
    try {
      await updateSettings({
        paybill: '247247',
        account: '7770187709',
        businessName: 'Colloquium KE',
        pricePerPage: 800,
        depositPercentage: 25,
        writerPercentage: 65,
        adminPercentage: 35,
        appApkLink: '',
      });
      setSettingsSavedMessage(true);
      setTimeout(() => setSettingsSavedMessage(false), 3000);
    } catch (err) {
      setSettingsError(err instanceof Error ? err.message : 'Unable to restore default settings.');
    } finally {
      setIsSavingSettings(false);
    }
  };

  const handleSendAdminPasswordReset = async () => {
    setResetPasswordNotice('');
    const res = await sendPasswordReset(ADMIN_EMAIL);
    setResetPasswordNotice(res.message);
  };

  const getHoursRemaining = (deadlineStr: string) => {
    const diffMs = new Date(deadlineStr).getTime() - Date.now();
    const diffHours = Math.round(diffMs / (3600 * 1000));
    if (diffHours < 0) return `${Math.abs(diffHours)}h overdue`;
    return `${diffHours}h left`;
  };

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Admin Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-red-600 bg-red-50 border border-red-200 px-2 py-0.5 rounded-full uppercase tracking-wider">
                Restricted Admin Hub
              </span>
              <span>·</span>
              <span className="text-xs text-slate-500">Colloquium KE Governance</span>
            </div>
            <h1 className="text-2xl font-black text-slate-900 mt-0.5">
              Colloquium KE Administrator Hub
            </h1>
            <p className="text-xs text-slate-600 mt-1">
              Active Paybill: <strong className="font-mono text-[#0E7A4C]">{settings.paybill}</strong> · Account: <strong className="font-mono text-slate-900">{settings.account}</strong> · Commission Split: <strong className="text-slate-900">Worker 65% / Admin 35%</strong>
            </p>
          </div>

          {/* Admin Tabs */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setActiveTab('tasks')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'tasks'
                  ? 'bg-[#0E7A4C] text-white shadow-xs'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <ListOrdered className="w-4 h-4" />
              <span>All Orders ({orders.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('approvals')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'approvals'
                  ? 'bg-[#0E7A4C] text-white shadow-xs'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <Hourglass className="w-4 h-4 text-amber-500" />
              <span>Worker Approvals ({pendingWorkers.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('reports')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'reports'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <Flag className={`w-4 h-4 ${reports.length > 0 ? 'text-red-500' : 'text-slate-400'}`} />
              <span>Reported Chats ({reports.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('users')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'users'
                  ? 'bg-[#0E7A4C] text-white shadow-xs'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Users ({users.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('payments')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'payments'
                  ? 'bg-[#0E7A4C] text-white shadow-xs'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              <span>Escrow &amp; Payouts</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'settings'
                  ? 'bg-[#0E7A4C] text-white shadow-xs'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>Settings</span>
            </button>
          </div>
        </div>

        {/* Financial Overview (100% Gross, 65% Worker, 35% Admin Profit) */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Total Gross Orders (100%)
            </span>
            <div className="text-2xl font-black font-mono text-slate-900 mt-1">
              KES {totalGrossRevenue.toLocaleString()}
            </div>
            <span className="text-[11px] text-slate-400 mt-0.5 block">{orders.length} total client requests</span>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Worker Pay Share (65%)
            </span>
            <div className="text-2xl font-black font-mono text-emerald-700 mt-1">
              KES {totalWorkerPayouts.toLocaleString()}
            </div>
            <span className="text-[11px] text-slate-400 mt-0.5 block">Allocated to specialists</span>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Admin Platform Profit (35%)
            </span>
            <div className="text-2xl font-black font-mono text-[#0E7A4C] mt-1">
              KES {totalAdminProfit.toLocaleString()}
            </div>
            <span className="text-[11px] text-emerald-700 mt-0.5 block font-semibold">Retained profit margin</span>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Active Workspaces
            </span>
            <div className="text-2xl font-black font-mono text-purple-600 mt-1">
              {activeTasks}
            </div>
            <span className="text-[11px] text-slate-400 mt-0.5 block">{pendingWorkers.length} pending worker approvals</span>
          </div>
        </div>

        {/* Search Bar for data lists */}
        {activeTab !== 'settings' && activeTab !== 'approvals' && (
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by ID, name, email, topic, or ref..."
                className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
              />
            </div>

            {activeTab === 'tasks' && (
              <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto text-xs pb-1 sm:pb-0">
                {['All', 'Pending Payment', 'Paid', 'Confirmed', 'In Progress', 'Completed', 'Paid to Writer'].map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setStatusFilter(tab)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
                      statusFilter === tab
                        ? 'bg-[#0E7A4C] text-white'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 1: ALL TASKS (Shows Total Price, Worker Pay 65%, Admin Profit 35%) */}
        {activeTab === 'tasks' && (
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase">
                  <tr>
                    <th className="py-3 px-4">Task ID</th>
                    <th className="py-3 px-4">Service &amp; Topic</th>
                    <th className="py-3 px-4">Client</th>
                    <th className="py-3 px-4">Specialist</th>
                    <th className="py-3 px-4 text-right">Total (100%)</th>
                    <th className="py-3 px-4 text-right">Worker (65%)</th>
                    <th className="py-3 px-4 text-right">Admin Profit (35%)</th>
                    <th className="py-3 px-4 text-center">Status</th>
                    <th className="py-3 px-4 text-right">Admin Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredOrders.map((order) => {
                    const workerPay = order.workerPayAmount || Math.floor(order.totalAmount * 0.65);
                    const adminProfit = order.adminProfitAmount || (order.totalAmount - workerPay);

                    return (
                      <tr key={order.id} className="hover:bg-slate-50/80">
                        <td className="py-3 px-4 font-mono font-bold text-slate-900">
                          {order.id}
                        </td>
                        <td className="py-3 px-4 max-w-xs">
                          <span className="text-[10px] font-semibold text-[#0E7A4C] bg-emerald-50 px-1.5 py-0.2 rounded">
                            {order.category}
                          </span>
                          <div className="font-semibold text-slate-900 line-clamp-1 mt-0.5">
                            {order.topic}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            {order.quantityValue} {order.quantityUnit || 'units'} · 25% Deposit: KES {order.depositAmount.toLocaleString()}
                          </div>
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <div className="font-semibold text-slate-800">{order.clientFullName || order.clientDisplayName}</div>
                          <div className="text-[10px] text-slate-500 font-mono">{order.clientPhone}</div>
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <div className="font-semibold text-slate-800">
                            {order.workerDisplayName || <span className="text-slate-400 italic font-normal">Unassigned</span>}
                          </div>
                          <button
                            onClick={() => setChatOrder(order)}
                            className="text-[10px] text-[#0E7A4C] font-semibold hover:underline flex items-center gap-1 mt-0.5"
                          >
                            <MessageSquare className="w-3 h-3" />
                            <span>Open Chat / Logs</span>
                          </button>
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 whitespace-nowrap">
                          KES {order.totalAmount.toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700 whitespace-nowrap">
                          KES {workerPay.toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-[#0E7A4C] whitespace-nowrap">
                          KES {adminProfit.toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-center whitespace-nowrap">
                          <StatusBadge status={order.status} size="sm" />
                        </td>
                        <td className="py-3 px-4 text-right whitespace-nowrap space-x-1">
                          {order.status === 'Paid' && (
                            <button
                              onClick={() => confirmPaymentByAdmin(order.id)}
                              className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded text-[11px] shadow-xs"
                            >
                              Confirm Deposit
                            </button>
                          )}
                          {order.status === 'Confirmed' && (
                            <button
                              onClick={() => markInProgress(order.id)}
                              className="px-2.5 py-1 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded text-[11px] shadow-xs"
                            >
                              Assign &amp; In Progress
                            </button>
                          )}
                          {order.status === 'In Progress' && (
                            <button
                              onClick={() => markCompleted(order.id)}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded text-[11px] shadow-xs"
                            >
                              Mark Completed
                            </button>
                          )}
                          {order.status === 'Completed' && (
                            <button
                              onClick={() => payWriter(order.id)}
                              className="px-2.5 py-1 bg-[#0E7A4C] hover:bg-[#0b633d] text-white font-bold rounded text-[11px] shadow-xs"
                              title={`Release KES ${workerPay.toLocaleString()} to worker, keep KES ${adminProfit.toLocaleString()} profit`}
                            >
                              Release 65% Payout
                            </button>
                          )}
                          {order.screenshotUrl && (
                            <button
                              onClick={() => setViewScreenshotOrder(order)}
                              className="p-1 text-slate-500 hover:text-[#0E7A4C] rounded"
                              title="View Deposit Screenshot"
                            >
                              <CreditCard className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 2: WORKER APPROVALS GATE (Prompt Requirement 3B: "Worker must apply with skills and samples, wait for Admin approval") */}
        {activeTab === 'approvals' && (
          <div className="space-y-4">
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3 text-xs text-amber-900">
              <Hourglass className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block text-sm">Specialist Onboarding Verification Gate</span>
                Specialists who register must have their credentials and portfolio samples audited before they can claim jobs or receive payouts.
              </div>
            </div>

            {pendingWorkers.length === 0 ? (
              <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
                <CheckCircle className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
                <h3 className="font-bold text-base text-slate-900">No Pending Specialist Applications</h3>
                <p className="text-xs text-slate-500 mt-1">All registered workers are currently approved and active.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {pendingWorkers.map((worker) => (
                  <div key={worker.id} className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold text-base text-slate-900">{worker.fullName}</h3>
                          <span className="text-[10px] font-mono bg-slate-100 text-slate-700 px-1.5 py-0.2 rounded">
                            {worker.id}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          {worker.email} · {worker.phone} · ID: {worker.idNumber || 'Pending'}
                        </p>
                      </div>
                      <span className="bg-amber-50 text-amber-800 border border-amber-200 font-bold px-2.5 py-1 rounded-full text-[10px]">
                        Pending Review
                      </span>
                    </div>

                    <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-2 text-xs">
                      <div>
                        <span className="font-semibold text-slate-700 block">M-Pesa Payout Number:</span>
                        <span className="font-mono text-emerald-700 font-bold">{worker.mpesaPhoneNumber || worker.phone}</span>
                      </div>
                      {worker.skills && (
                        <div>
                          <span className="font-semibold text-slate-700 block mb-1">Declared Competencies:</span>
                          <div className="flex flex-wrap gap-1">
                            {worker.skills.map((s) => (
                              <span key={s} className="bg-emerald-50 text-[#0E7A4C] border border-emerald-200 px-2 py-0.5 rounded text-[10px]">
                                {s}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      {worker.portfolioDescription && (
                        <div>
                          <span className="font-semibold text-slate-700 block">Experience / Sample Overview:</span>
                          <p className="text-slate-600 italic bg-white p-2 rounded border border-slate-200 mt-0.5">
                            "{worker.portfolioDescription}"
                          </p>
                        </div>
                      )}
                      {worker.sampleWorkName && (
                        <div className="flex items-center justify-between pt-1">
                          <span className="text-slate-600 font-mono text-[11px]">
                            Sample: {worker.sampleWorkName}
                          </span>
                          <span className="text-[10px] text-blue-600 font-semibold cursor-pointer hover:underline">
                            View Document Sample
                          </span>
                        </div>
                      )}
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-end gap-2">
                      <button
                        onClick={() => approveWorker(worker.id, false)}
                        className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded-lg text-xs font-bold transition"
                      >
                        Decline Application
                      </button>
                      <button
                        onClick={() => approveWorker(worker.id, true)}
                        className="px-4 py-1.5 bg-[#0E7A4C] hover:bg-[#0b633d] text-white rounded-lg text-xs font-bold transition shadow-sm flex items-center gap-1.5"
                      >
                        <Check className="w-4 h-4" />
                        <span>Approve Specialist (65% Pay Access)</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB: REPORTED CHATS & CONTACT SHARING SHIELD (Rule 4: Admin Control) */}
        {activeTab === 'reports' && (
          <div className="space-y-4">
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3 text-xs text-red-900">
              <ShieldAlert className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block text-sm">Escrow Communication Security &amp; Contact Shield</span>
                All conversations are protected. Direct phone calls, emails, social media, and off-platform payment attempts are automatically blocked. You can inspect reported chats, issue official warnings, or suspend users who reach 3 violations.
              </div>
            </div>

            {reports.length === 0 ? (
              <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
                <CheckCircle className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
                <h3 className="font-bold text-base text-slate-900">No Reported Chats</h3>
                <p className="text-xs text-slate-500 mt-1">Zero safety reports pending. All task communications are currently compliant.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {reports.map((report) => {
                  const targetOrder = orders.find((o) => o.id === report.orderId);
                  const reportedUser = users.find((u) => u.id === report.reportedUserId);
                  const violationCount = reportedUser?.contactViolationCount || 0;

                  return (
                    <div
                      key={report.id}
                      className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-3"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-xs text-red-600 bg-red-50 border border-red-200 px-2 py-0.5 rounded">
                              {report.id}
                            </span>
                            <span className="font-bold text-slate-900 text-sm">{report.reason}</span>
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                                report.status === 'Suspended'
                                  ? 'bg-red-100 text-red-800'
                                  : report.status === 'Warned'
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-slate-100 text-slate-700'
                              }`}
                            >
                              {report.status}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 mt-1">
                            Task: <strong className="text-slate-800 font-mono">{report.orderId}</strong> ({report.orderTopic}) · Reported {new Date(report.reportedAt).toLocaleString('en-KE')}
                          </p>
                        </div>

                        {/* Reported User Status & Badge */}
                        <div className="text-right">
                          <span className="text-[11px] text-slate-500 block">
                            Offender: <strong className="text-slate-800">{report.reportedUserName}</strong> ({report.reportedUserRole})
                          </span>
                          <span className={`text-[11px] font-bold ${violationCount >= 3 ? 'text-red-600' : 'text-amber-600'}`}>
                            Violations: {violationCount} / 3 {violationCount >= 3 ? '(SUSPENSION THRESHOLD REACHED)' : ''}
                          </span>
                        </div>
                      </div>

                      {/* Details */}
                      {report.details && (
                        <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs">
                          <span className="font-bold text-slate-700 block mb-0.5">Details &amp; Audit Log:</span>
                          <p className="text-slate-600 leading-relaxed font-mono text-[11px]">{report.details}</p>
                        </div>
                      )}

                      {/* Admin Actions: Open Chat, Warn, Block/Suspend, Dismiss */}
                      <div className="pt-2 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100">
                        <div className="flex items-center gap-2">
                          {targetOrder && (
                            <button
                              type="button"
                              onClick={() => setChatOrder(targetOrder)}
                              className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-[#0E7A4C] border border-emerald-200 rounded-lg text-xs font-bold transition flex items-center gap-1.5"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                              <span>Inspect Chat Log</span>
                            </button>
                          )}
                          {targetOrder && (
                            <button
                              type="button"
                              onClick={() => deleteOrderChat(targetOrder.id)}
                              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition"
                            >
                              Purge Chat
                            </button>
                          )}
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => warnUserByAdmin(report.reportedUserId, report.id)}
                            className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-lg text-xs font-bold transition flex items-center gap-1"
                          >
                            <AlertTriangle className="w-3.5 h-3.5" />
                            <span>Issue Warning (+1 Violation)</span>
                          </button>

                          {reportedUser?.isSuspended ? (
                            <button
                              type="button"
                              onClick={() => unbanUserByAdmin(report.reportedUserId)}
                              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-bold transition"
                            >
                              Unsuspend User
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() =>
                                suspendUserByAdmin(
                                  report.reportedUserId,
                                  'Suspended by Admin due to contact sharing violation',
                                  report.id
                                )
                              }
                              className="px-3.5 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-bold transition shadow-xs flex items-center gap-1.5"
                            >
                              <Ban className="w-3.5 h-3.5" />
                              <span>Suspend Account</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: ALL USERS */}
        {activeTab === 'users' && (
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase">
                  <tr>
                    <th className="py-3 px-4">Name &amp; Status</th>
                    <th className="py-3 px-4">Role</th>
                    <th className="py-3 px-4">Email</th>
                    <th className="py-3 px-4">Phone Number</th>
                    <th className="py-3 px-4">M-Pesa Payout</th>
                    <th className="py-3 px-4 text-center">Tasks</th>
                    <th className="py-3 px-4">Joined</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredUsers.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-50/80">
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5 font-bold text-slate-900">
                          <span>{u.fullName}</span>
                          {u.role === 'worker' && u.isApproved && (
                            <span className="text-emerald-600 font-extrabold text-sm" title="Approved Specialist">
                              ✓
                            </span>
                          )}
                          {u.isSuspended && (
                            <span className="bg-red-100 text-red-700 text-[9px] font-extrabold px-1.5 py-0.2 rounded border border-red-300">
                              SUSPENDED
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-slate-400 flex items-center gap-2">
                          <span>Alias: {u.displayName}</span>
                          {(u.contactViolationCount || 0) > 0 && (
                            <span className="text-red-600 font-bold">
                              • {u.contactViolationCount} contact warnings
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            u.role === 'worker'
                              ? 'bg-amber-50 text-amber-800 border border-amber-200'
                              : 'bg-emerald-50 text-[#0E7A4C] border border-emerald-200'
                          }`}
                        >
                          {u.role}
                        </span>
                      </td>

                      <td className="py-3 px-4 font-mono text-slate-700 whitespace-nowrap">
                        {u.email}
                      </td>

                      <td className="py-3 px-4 font-mono text-slate-700 whitespace-nowrap">
                        {u.phone}
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap">
                        {u.mpesaPhoneNumber ? (
                          <div className="font-mono text-slate-800">
                            {u.mpesaPhoneNumber}
                            <span className="text-[10px] text-slate-400 block">{u.mpesaFullName}</span>
                          </div>
                        ) : (
                          <span className="text-slate-400 italic text-[11px]">—</span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-center font-bold text-slate-800">
                        {u.totalTasksCompleted || 0}
                      </td>

                      <td className="py-3 px-4 text-slate-500 whitespace-nowrap">
                        {u.joinedAt}
                      </td>

                      <td className="py-3 px-4 text-right whitespace-nowrap space-x-1">
                        {u.role === 'worker' && !u.isApproved && (
                          <button
                            onClick={() => approveWorker(u.id, true)}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded text-[11px] shadow-xs"
                          >
                            Approve (✓)
                          </button>
                        )}
                        {u.isSuspended ? (
                          <button
                            onClick={() => unbanUserByAdmin(u.id)}
                            className="px-2.5 py-1 bg-slate-200 hover:bg-slate-300 text-slate-800 font-semibold rounded text-[11px]"
                            title="Unsuspend account"
                          >
                            Unsuspend
                          </button>
                        ) : (
                          <button
                            onClick={() => suspendUserByAdmin(u.id, 'Admin manual suspension')}
                            className="px-2 py-1 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 font-semibold rounded text-[11px]"
                            title="Suspend user account"
                          >
                            Suspend
                          </button>
                        )}
                        <button
                          onClick={() => setSelectedUserModal(u)}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded text-[11px]"
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 4: PAYMENTS & ESCROW RECONCILIATION */}
        {activeTab === 'payments' && (
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-200 bg-slate-50 flex justify-between items-center">
              <div>
                <h3 className="font-bold text-sm text-slate-900">Equity Paybill 247247 Reconciliation</h3>
                <p className="text-xs text-slate-500">25% deposit escrow receipts and 75% balance completions</p>
              </div>
              <span className="text-xs bg-emerald-50 text-[#0E7A4C] border border-emerald-200 font-bold px-3 py-1 rounded-lg">
                Account: {settings.account}
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase">
                  <tr>
                    <th className="py-3 px-4">Task ID</th>
                    <th className="py-3 px-4">Client</th>
                    <th className="py-3 px-4 text-right">Total Price</th>
                    <th className="py-3 px-4 text-right">25% Deposit</th>
                    <th className="py-3 px-4 text-right">75% Balance</th>
                    <th className="py-3 px-4 text-center">Deposit Proof</th>
                    <th className="py-3 px-4 text-center">Balance Proof</th>
                    <th className="py-3 px-4 text-center">Status</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {orders.map((o) => (
                    <tr key={o.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">{o.id}</td>
                      <td className="py-3 px-4 font-semibold text-slate-800">{o.clientFullName || o.clientDisplayName}</td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                        KES {o.totalAmount.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-[#0E7A4C]">
                        KES {o.depositAmount.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-amber-700">
                        KES {o.balanceAmount.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-center whitespace-nowrap">
                        {o.screenshotUrl ? (
                          <button
                            onClick={() => setViewScreenshotOrder(o)}
                            className="px-2 py-0.5 bg-emerald-50 text-[#0E7A4C] border border-emerald-200 font-semibold rounded text-[11px]"
                          >
                            Deposit Proof
                          </button>
                        ) : (
                          <span className="text-slate-400 italic">None</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center whitespace-nowrap">
                        {o.balancePaid ? (
                          <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 text-[10px]">
                            ✓ Paid
                          </span>
                        ) : (
                          <span className="text-slate-400 italic text-[10px]">Pending</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <StatusBadge status={o.status} size="sm" />
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        {o.status === 'Paid' && (
                          <button
                            onClick={() => confirmPaymentByAdmin(o.id)}
                            className="px-2.5 py-1 bg-blue-600 text-white font-bold rounded text-[11px]"
                          >
                            Confirm Deposit
                          </button>
                        )}
                        {o.status === 'Completed' && (
                          <button
                            onClick={() => payWriter(o.id)}
                            className="px-2.5 py-1 bg-[#0E7A4C] text-white font-bold rounded text-[11px]"
                          >
                            Release 65% Payout
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 5: SETTINGS */}
        {activeTab === 'settings' && (
          <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-sm max-w-2xl mx-auto space-y-6">
            <div className="border-b border-slate-200 pb-4">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Settings className="w-5 h-5 text-[#0E7A4C]" />
                <span>Colloquium KE Marketplace Configuration</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Configure Paybill credentials, commission revenue model, and Android APK download links.
              </p>
            </div>

            {settingsSavedMessage && (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-3 rounded-lg text-xs font-semibold flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Settings saved to Cloud Firestore! Changes are synced across all devices.</span>
              </div>
            )}

            {settingsError && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-600" />
                <span>{settingsError}</span>
              </div>
            )}

            <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="settings-paybill-input" className="block font-bold text-slate-800 mb-1">
                    Equity Paybill Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="settings-paybill-input"
                    type="text"
                    required
                    value={paybill}
                    onChange={(e) => setPaybill(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono font-bold text-sm focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                  <span className="text-[10px] text-slate-400">Default: 247247</span>
                </div>

                <div>
                  <label htmlFor="settings-account-input" className="block font-bold text-slate-800 mb-1">
                    Equity Account Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="settings-account-input"
                    type="text"
                    required
                    value={account}
                    onChange={(e) => setAccount(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono font-bold text-sm focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                  <span className="text-[10px] text-slate-400">Default: 7770187709</span>
                </div>
              </div>

              <div>
                <label htmlFor="settings-businessname-input" className="block font-bold text-slate-800 mb-1">
                  Business Name (Merchant Label)
                </label>
                <input
                  id="settings-businessname-input"
                  type="text"
                  required
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label htmlFor="settings-deposit-percent-input" className="block font-bold text-slate-800 mb-1">
                    Escrow Deposit %
                  </label>
                  <input
                    id="settings-deposit-percent-input"
                    type="number"
                    min={10}
                    max={100}
                    value={depositPercentage}
                    onChange={(e) => setDepositPercentage(Number(e.target.value) || 25)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono font-bold text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                  <span className="text-[10px] text-slate-400">Default: 25%</span>
                </div>

                <div>
                  <label htmlFor="settings-worker-percent-input" className="block font-bold text-slate-800 mb-1">
                    Worker Payout %
                  </label>
                  <input
                    id="settings-worker-percent-input"
                    type="number"
                    min={10}
                    max={90}
                    value={writerPercentage}
                    onChange={(e) => setWriterPercentage(Number(e.target.value) || 65)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono font-bold text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                  <span className="text-[10px] text-slate-400">Target: 65%</span>
                </div>

                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    Admin Platform Profit %
                  </label>
                  <input
                    type="number"
                    disabled
                    value={100 - (Number(writerPercentage) || 65)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-slate-100 font-mono font-bold text-xs text-[#0E7A4C]"
                  />
                  <span className="text-[10px] text-slate-400">Target: 35%</span>
                </div>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="font-bold text-slate-800 block">
                      Master Administrator Account
                    </span>
                    <span className="font-mono text-xs text-[#0E7A4C] font-semibold">
                      {ADMIN_EMAIL}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={handleSendAdminPasswordReset}
                    className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-lg font-bold text-[11px] flex items-center gap-1.5"
                  >
                    <Key className="w-3.5 h-3.5 text-[#0E7A4C]" />
                    <span>Send Password Reset Email</span>
                  </button>
                </div>
                <p className="text-[10px] text-slate-500">
                  Admin privileges are enforced server-side by Firebase Authentication &amp; Firestore Security Rules for this verified account only.
                </p>
                {resetPasswordNotice && (
                  <p className="text-[11px] text-emerald-700 font-semibold">{resetPasswordNotice}</p>
                )}
              </div>

              <div>
                <label htmlFor="settings-app-apk-link" className="block font-bold text-slate-800 mb-1">
                  App APK Link (Android Package Direct Download)
                </label>
                <div className="relative">
                  <input
                    id="settings-app-apk-link"
                    type="url"
                    value={appApkLink}
                    onChange={(e) => setAppApkLink(e.target.value)}
                    placeholder="https://example.com/downloads/colloquium_ke.apk"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                </div>
                <span className="text-[10px] text-slate-500 block mt-0.5">
                  Download button uses this link if provided, else triggers the browser PWA install prompt.
                </span>
              </div>

              <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  disabled={isSavingSettings}
                  onClick={handleResetDefaults}
                  className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg transition flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restore Defaults</span>
                </button>

                <button
                  type="submit"
                  disabled={isSavingSettings}
                  className="px-6 py-2.5 bg-[#0E7A4C] hover:bg-[#0b633d] disabled:bg-slate-300 text-white font-bold rounded-lg transition flex items-center gap-2 shadow-sm"
                >
                  <Save className="w-4 h-4" />
                  <span>{isSavingSettings ? 'Saving...' : 'Save Platform Settings'}</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Modal: User Profile Inspection */}
        {selectedUserModal && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200 text-xs">
              <div className="bg-[#0E7A4C] text-white px-6 py-4 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-base">{selectedUserModal.fullName}</h3>
                  <p className="text-[11px] text-emerald-100 capitalize">Role: {selectedUserModal.role} · ID: {selectedUserModal.id}</p>
                </div>
                <button
                  onClick={() => setSelectedUserModal(null)}
                  className="p-1 rounded text-white/80 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <div>
                    <span className="text-slate-400 block">Email:</span>
                    <span className="font-mono font-semibold text-slate-900">{selectedUserModal.email}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Phone:</span>
                    <span className="font-mono font-semibold text-slate-900">{selectedUserModal.phone}</span>
                  </div>
                  {selectedUserModal.role === 'worker' && (
                    <div>
                      <span className="text-slate-400 block">M-Pesa Payout Phone:</span>
                      <span className="font-mono font-semibold text-emerald-700">{selectedUserModal.mpesaPhoneNumber || selectedUserModal.phone}</span>
                    </div>
                  )}
                </div>

                {selectedUserModal.role === 'worker' && selectedUserModal.skills && (
                  <div>
                    <span className="font-bold text-slate-800 block mb-1">Selected Skills &amp; Categories:</span>
                    <div className="flex flex-wrap gap-1">
                      {selectedUserModal.skills.map((s) => (
                        <span key={s} className="bg-emerald-50 text-[#0E7A4C] border border-emerald-200 px-2 py-0.5 rounded text-[11px]">
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {selectedUserModal.role === 'worker' && (
                  <div className="pt-2 flex items-center justify-between border-t border-slate-100">
                    <span className="text-slate-600">Approval Status:</span>
                    {selectedUserModal.isApproved ? (
                      <span className="text-emerald-700 font-bold bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200">
                        ✓ Approved Specialist
                      </span>
                    ) : (
                      <button
                        onClick={() => {
                          approveWorker(selectedUserModal.id, true);
                          setSelectedUserModal({ ...selectedUserModal, isApproved: true, approvalStatus: 'approved' });
                        }}
                        className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded shadow-xs"
                      >
                        Approve Specialist (✓)
                      </button>
                    )}
                  </div>
                )}
              </div>

              <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex justify-end">
                <button
                  onClick={() => setSelectedUserModal(null)}
                  className="px-4 py-1.5 bg-slate-800 text-white font-semibold rounded-lg"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Screenshot Viewer Modal */}
        {viewScreenshotOrder && (
          <ReceiptViewerModal
            isOpen={!!viewScreenshotOrder}
            onClose={() => setViewScreenshotOrder(null)}
            screenshotUrl={viewScreenshotOrder.screenshotUrl}
            orderId={viewScreenshotOrder.id}
            amount={viewScreenshotOrder.depositAmount}
            paymentRef={viewScreenshotOrder.paymentReference}
          />
        )}

        {/* Task Chat Modal for Admin Oversight */}
        {chatOrder && (
          <TaskChatModal
            isOpen={!!chatOrder}
            onClose={() => setChatOrder(null)}
            order={chatOrder}
          />
        )}
      </div>
    </div>
  );
};
