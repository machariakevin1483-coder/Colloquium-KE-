import React, { useState } from 'react';
import { useOrders } from '../context/OrderContext';
import {
  GraduationCap,
  AlertCircle,
  ArrowRight,
  User,
  Phone,
  Mail,
  Lock,
  Building,
  Loader2,
} from 'lucide-react';

interface ClientRegisterProps {
  navigate: (path: string) => void;
}

export const ClientRegister: React.FC<ClientRegisterProps> = ({ navigate }) => {
  const {
    registerClient,
    loginWithGoogle,
    pendingOrderDraft,
    setPendingOrderDraft,
    createOrder,
  } = useOrders();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [institution, setInstitution] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const finishRegistration = async (userObj: any) => {
    if (pendingOrderDraft && userObj) {
      const draft = pendingOrderDraft;
      setPendingOrderDraft(null);
      const created = await createOrder(draft, userObj);
      navigate(`/checkout/${created.id}`);
      return;
    }
    navigate('/client/dashboard');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!fullName.trim()) {
      setErrorMessage('Full Name is required.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }
    if (!phone.trim() || phone.trim().length < 5) {
      setErrorMessage('Please enter a valid phone number.');
      return;
    }
    if (password.length < 6) {
      setErrorMessage('Password must be at least 6 characters.');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }
    if (!agreeTerms) {
      setErrorMessage('You must agree to the Terms and Conditions.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await registerClient({
        fullName: fullName.trim(),
        displayName: '',
        email: email.trim().toLowerCase(),
        phone: phone.trim(),
        password,
        institution: institution.trim() || 'Kenyan University',
      });

      if (!res.success) {
        setErrorMessage(res.message || 'Registration failed. Please try again.');
        setIsSubmitting(false);
        return;
      }

      await finishRegistration(res.user);
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Unable to register account.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleSignUp = async () => {
    setErrorMessage('');
    setIsSubmitting(true);
    try {
      const res = await loginWithGoogle('client');
      if (!res.success) {
        setErrorMessage(res.message || 'Google sign-up failed.');
        setIsSubmitting(false);
        return;
      }
      if (res.role === 'admin') {
        navigate('/admin');
        return;
      }
      if (res.role === 'worker') {
        navigate('/worker/dashboard');
        return;
      }
      await finishRegistration(res.user);
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Google sign-up failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-xl mx-auto space-y-6">
        {/* Header Title */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-[#0E7A4C] text-white shadow-md mb-1">
            <GraduationCap className="w-6 h-6" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            Create Client Account
          </h1>
          <p className="text-xs text-slate-600 max-w-sm mx-auto">
            Hire verified scholars for research, assignments, and presentations with secure payment protection.
          </p>
        </div>

        {/* Card Form */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-md">
          {pendingOrderDraft && (
            <div className="mb-4 bg-emerald-50 border border-emerald-200 text-emerald-900 px-4 py-2.5 rounded-lg text-xs">
              Create your client account to complete your order (<strong className="font-semibold">{pendingOrderDraft.topic}</strong>) and proceed to checkout.
            </div>
          )}

          {errorMessage && (
            <div className="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-2.5 rounded-lg text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          <button
            type="button"
            onClick={handleGoogleSignUp}
            disabled={isSubmitting}
            className="w-full mb-4 py-2.5 px-4 bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 font-bold text-xs rounded-xl transition flex items-center justify-center gap-2 shadow-2xs"
          >
            {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
            <span>Continue with Google as Client</span>
          </button>

          <div className="relative flex items-center mb-4">
            <div className="flex-grow border-t border-slate-200" />
            <span className="shrink mx-3 text-[11px] text-slate-400 font-semibold uppercase">
              or register with email
            </span>
            <div className="flex-grow border-t border-slate-200" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            {/* Full Name * */}
            <div>
              <label htmlFor="client-fullname-input" className="block font-semibold text-slate-800 mb-1">
                Full Name <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="client-fullname-input"
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Faith Wanjiku Mwangi"
                  className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                />
              </div>
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                Workers will only see your first name (e.g. "Faith W.") for complete privacy.
              </span>
            </div>

            {/* Email * */}
            <div>
              <label htmlFor="client-email-input" className="block font-semibold text-slate-800 mb-1">
                Email Address <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="client-email-input"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@university.ac.ke or gmail.com"
                  className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                />
              </div>
            </div>

            {/* Phone * */}
            <div>
              <label htmlFor="client-phone-input" className="block font-semibold text-slate-800 mb-1">
                Phone Number (M-Pesa / WhatsApp) <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="client-phone-input"
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g. 0712345678"
                  className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                />
              </div>
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                Hidden from workers. Used only for urgent admin SMS/WhatsApp completion alerts.
              </span>
            </div>

            {/* Password & Confirm * */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label htmlFor="client-password-input" className="block font-semibold text-slate-800 mb-1">
                  Password <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id="client-password-input"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                </div>
              </div>
              <div>
                <label htmlFor="client-confirm-password-input" className="block font-semibold text-slate-800 mb-1">
                  Confirm Password <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id="client-confirm-password-input"
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter password"
                    className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                </div>
              </div>
            </div>

            {/* Institution (Optional) */}
            <div>
              <label htmlFor="client-institution-input" className="block font-semibold text-slate-800 mb-1">
                College / University / Institution
              </label>
              <div className="relative">
                <Building className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="client-institution-input"
                  type="text"
                  value={institution}
                  onChange={(e) => setInstitution(e.target.value)}
                  placeholder="e.g. University of Nairobi, Kenyatta University, Strathmore"
                  className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                />
              </div>
            </div>

            {/* Checkbox Terms * */}
            <div className="pt-2">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  required
                  checked={agreeTerms}
                  onChange={(e) => setAgreeTerms(e.target.checked)}
                  className="mt-0.5 rounded text-[#0E7A4C] focus:ring-[#0E7A4C]"
                />
                <span className="text-[11px] text-slate-600">
                  I agree to Colloquium KE <strong className="text-slate-900">Terms of Service</strong> and privacy policy for client orders.
                </span>
              </label>
            </div>

            {/* Submit */}
            <div className="pt-3">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 bg-[#0E7A4C] hover:bg-[#0b633d] text-white font-bold text-xs rounded-xl transition shadow-md flex items-center justify-center gap-2"
              >
                <span>{isSubmitting ? 'Creating Profile...' : 'Complete Registration'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>

          <div className="mt-5 pt-4 border-t border-slate-100 text-center text-[11px] text-slate-500">
            Already have an account?{' '}
            <button
              onClick={() => navigate('/login')}
              className="text-[#0E7A4C] font-bold hover:underline"
            >
              Sign In
            </button>
            {' · '}
            <button
              onClick={() => navigate('/worker/register')}
              className="text-slate-600 font-semibold hover:underline"
            >
              Register as Worker
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
