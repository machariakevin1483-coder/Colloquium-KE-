import React, { useState } from 'react';
import { useOrders } from '../context/OrderContext';
import { ALL_JOB_CATEGORIES, JobCategory } from '../types';
import {
  Briefcase,
  AlertCircle,
  ArrowRight,
  CreditCard,
  FileBadge,
  Sparkles,
} from 'lucide-react';

interface WorkerRegisterProps {
  navigate: (path: string) => void;
}

export const WorkerRegister: React.FC<WorkerRegisterProps> = ({ navigate }) => {
  const { registerWorker } = useOrders();

  // Worker Form State
  const [fullName, setFullName] = useState('');
  const [idNumber, setIdNumber] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // M-Pesa & Payment Details
  const [mpesaFullName, setMpesaFullName] = useState('');
  const [mpesaPhoneNumber, setMpesaPhoneNumber] = useState('');
  const [bankName, setBankName] = useState('');
  const [bankAccountNumber, setBankAccountNumber] = useState('');
  const [paypalEmail, setPaypalEmail] = useState('');

  // Skills & Education
  const [selectedSkills, setSelectedSkills] = useState<JobCategory[]>([
    'Research',
    'Essays',
    'Assignments',
  ]);
  const [highestEducation, setHighestEducation] = useState('Bachelor\'s Degree');

  // About & Terms
  const [about, setAbout] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(false);

  const [errorMessage, setErrorMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const toggleSkill = (skill: JobCategory) => {
    setSelectedSkills((prev) =>
      prev.includes(skill) ? prev.filter((s) => s !== skill) : [...prev, skill]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!fullName.trim()) {
      setErrorMessage('Full Name is required.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }
    if (!phone.trim() || phone.trim().length < 5) {
      setErrorMessage('Please enter a valid phone number.');
      return;
    }
    if (password.length < 6) {
      setErrorMessage('Password must be at least 6 characters.');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }
    if (!mpesaFullName.trim()) {
      setErrorMessage('M-Pesa Full Name as per ID is required for payout verification.');
      return;
    }
    if (!mpesaPhoneNumber.trim() || mpesaPhoneNumber.trim().length < 5) {
      setErrorMessage('Please enter a valid M-Pesa Phone Number for payout.');
      return;
    }
    if (selectedSkills.length === 0) {
      setErrorMessage('Please select at least one skill / category.');
      return;
    }
    if (!agreeTerms) {
      setErrorMessage('You must agree to the Terms and Conditions.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await registerWorker({
        fullName: fullName.trim(),
        displayName: '',
        email: email.trim().toLowerCase(),
        phone: phone.trim(),
        password,
        idNumber: idNumber.trim() || undefined,
        mpesaFullName: mpesaFullName.trim(),
        mpesaPhoneNumber: mpesaPhoneNumber.trim(),
        bankName: bankName.trim(),
        bankAccountNumber: bankAccountNumber.trim(),
        paypalEmail: paypalEmail.trim(),
        skills: selectedSkills,
        highestEducation,
        about: about.trim(),
      });

      if (!res.success) {
        setErrorMessage(res.message || 'Unable to submit worker application.');
        setIsSubmitting(false);
        return;
      }

      navigate('/worker/dashboard');
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Unable to register worker account.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header Title */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-amber-600 text-white shadow-md mb-1">
            <Briefcase className="w-6 h-6" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            Worker &amp; Writer Registration
          </h1>
          <p className="text-xs text-slate-600 max-w-md mx-auto">
            Join Colloquium KE's vetted scholar network. Submit tasks, maintain privacy, and receive automated M-Pesa payouts.
          </p>
        </div>

        {/* Card Form */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-md">
          {errorMessage && (
            <div className="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-2.5 rounded-lg text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5 text-xs">
            {/* Section 1: Personal & Legal ID */}
            <div className="space-y-3">
              <h3 className="font-bold text-sm text-slate-900 border-b border-slate-100 pb-1.5 flex items-center gap-1.5 text-[#0E7A4C]">
                <FileBadge className="w-4 h-4" />
                <span>1. Personal &amp; Legal Identity</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="worker-fullname-input" className="block font-semibold text-slate-800 mb-1">
                    Full Legal Name (as per ID) <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="worker-fullname-input"
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Kelvin Macharia Ndungu"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    Clients will only see "Kelvin M." for your privacy.
                  </span>
                </div>

                <div>
                  <label htmlFor="worker-id-passport-input" className="block font-semibold text-slate-800 mb-1">
                    ID Number / Passport Number (Optional)
                  </label>
                  <input
                    id="worker-id-passport-input"
                    type="text"
                    value={idNumber}
                    onChange={(e) => setIdNumber(e.target.value)}
                    placeholder="e.g. 32984102"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="worker-email-input" className="block font-semibold text-slate-800 mb-1">
                    Email Address <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="worker-email-input"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="worker@gmail.com"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                </div>
                <div>
                  <label htmlFor="worker-phone-input" className="block font-semibold text-slate-800 mb-1">
                    Mobile Phone Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="worker-phone-input"
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="0720112233"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="worker-password-input" className="block font-semibold text-slate-800 mb-1">
                    Password <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="worker-password-input"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                </div>
                <div>
                  <label htmlFor="worker-confirm-password-input" className="block font-semibold text-slate-800 mb-1">
                    Confirm Password <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="worker-confirm-password-input"
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter password"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                </div>
              </div>
            </div>

            {/* Section 2: M-Pesa Details (Mandatory for Payout) */}
            <div className="space-y-3 pt-2">
              <h3 className="font-bold text-sm text-slate-900 border-b border-slate-100 pb-1.5 flex items-center gap-1.5 text-[#0E7A4C]">
                <CreditCard className="w-4 h-4" />
                <span>2. M-Pesa Payout Credentials</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="worker-mpesa-fullname-input" className="block font-semibold text-slate-800 mb-1">
                    M-Pesa Full Names as per ID <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="worker-mpesa-fullname-input"
                    type="text"
                    required
                    value={mpesaFullName}
                    onChange={(e) => setMpesaFullName(e.target.value)}
                    placeholder="Exact name registered on SIM"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                </div>

                <div>
                  <label htmlFor="worker-mpesa-payout-phone-input" className="block font-semibold text-slate-800 mb-1">
                    M-Pesa Phone Number for Payout <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="worker-mpesa-payout-phone-input"
                    type="tel"
                    required
                    value={mpesaPhoneNumber}
                    onChange={(e) => setMpesaPhoneNumber(e.target.value)}
                    placeholder="07XXXXXXXX"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                </div>
              </div>

              {/* Optional Alternative Payouts */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <span className="font-semibold text-slate-700 block">
                  Alternative Payout Channels (Optional):
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <input
                    type="text"
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    placeholder="Bank Name (e.g. Equity)"
                    className="px-2.5 py-1.5 rounded border border-slate-300 text-xs bg-white"
                  />
                  <input
                    type="text"
                    value={bankAccountNumber}
                    onChange={(e) => setBankAccountNumber(e.target.value)}
                    placeholder="Bank Account Number"
                    className="px-2.5 py-1.5 rounded border border-slate-300 text-xs bg-white font-mono"
                  />
                  <input
                    type="email"
                    value={paypalEmail}
                    onChange={(e) => setPaypalEmail(e.target.value)}
                    placeholder="PayPal Email"
                    className="px-2.5 py-1.5 rounded border border-slate-300 text-xs bg-white"
                  />
                </div>
              </div>
            </div>

            {/* Section 3: Skills & Education */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
                <h3 className="font-bold text-sm text-slate-900 flex items-center gap-1.5 text-[#0E7A4C]">
                  <Sparkles className="w-4 h-4" />
                  <span>3. Skills &amp; Task Categories <span className="text-red-500">*</span></span>
                </h3>
                <span className="text-[11px] text-slate-500">
                  {selectedSkills.length} selected
                </span>
              </div>

              {/* 19 Categories Checkboxes */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto p-2 bg-slate-50 rounded-xl border border-slate-200">
                {ALL_JOB_CATEGORIES.map((cat) => {
                  const isChecked = selectedSkills.includes(cat);
                  return (
                    <label
                      key={cat}
                      className={`flex items-center gap-2 p-1.5 rounded-lg border text-[11px] cursor-pointer transition select-none ${
                        isChecked
                          ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-semibold'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => toggleSkill(cat)}
                        className="rounded text-[#0E7A4C] focus:ring-[#0E7A4C]"
                      />
                      <span className="truncate">{cat}</span>
                    </label>
                  );
                })}
              </div>

              <div>
                <label htmlFor="highest-education-select" className="block font-semibold text-slate-800 mb-1">
                  Highest Level of Education <span className="text-red-500">*</span>
                </label>
                <select
                  id="highest-education-select"
                  value={highestEducation}
                  onChange={(e) => setHighestEducation(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                >
                  <option value="Certificate">Certificate / Vocational</option>
                  <option value="Diploma">Diploma</option>
                  <option value="Bachelor's Degree">Bachelor's Degree</option>
                  <option value="Master's Degree">Master's Degree</option>
                  <option value="Doctorate / PhD">Doctorate / PhD</option>
                </select>
              </div>

              <div>
                <label htmlFor="worker-about-textarea" className="block font-semibold text-slate-800 mb-1">
                  About You &amp; Academic Experience
                </label>
                <textarea
                  id="worker-about-textarea"
                  rows={2}
                  value={about}
                  onChange={(e) => setAbout(e.target.value)}
                  placeholder="Outline your research expertise, referencing styles, and turnaround discipline..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                />
              </div>
            </div>

            {/* Checkbox Terms * */}
            <div className="pt-2">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  required
                  checked={agreeTerms}
                  onChange={(e) => setAgreeTerms(e.target.checked)}
                  className="mt-0.5 rounded text-[#0E7A4C] focus:ring-[#0E7A4C]"
                />
                <span className="text-[11px] text-slate-600">
                  I confirm that all provided academic qualifications and M-Pesa registration details are genuine. I understand that Admin audits all completed submissions before releasing payout.
                </span>
              </label>
            </div>

            {/* Submit */}
            <div className="pt-3">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 bg-[#0E7A4C] hover:bg-[#0b633d] text-white font-bold text-xs rounded-xl transition shadow-md flex items-center justify-center gap-2"
              >
                <span>{isSubmitting ? 'Submitting Application...' : 'Submit Worker Application'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>

          <div className="mt-5 pt-4 border-t border-slate-100 text-center text-[11px] text-slate-500">
            Already registered?{' '}
            <button
              onClick={() => navigate('/login')}
              className="text-[#0E7A4C] font-bold hover:underline"
            >
              Sign In
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
