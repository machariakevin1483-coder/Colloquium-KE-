import React, { useState, useEffect } from 'react';
import { useOrders } from '../context/OrderContext';
import { ColloquiumLogoIcon } from './ColloquiumLogoIcon';
import {
  GraduationCap,
  Briefcase,
  ShieldCheck,
  Menu,
  X,
  PlusCircle,
  LogIn,
  LogOut,
  Download,
  Layers,
} from 'lucide-react';

interface NavbarProps {
  currentPath: string;
  navigate: (path: string) => void;
  deferredPrompt?: any;
  triggerPwaInstall?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPath,
  navigate,
  deferredPrompt,
  triggerPwaInstall,
}) => {
  const { settings, orders, userRole, currentUser, logout } = useOrders();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showMobileInstallPopup, setShowMobileInstallPopup] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);

  const availableJobsCount = orders.filter((o) => o.status === 'Confirmed').length;
  const pendingDepositsCount = orders.filter((o) => o.status === 'Paid').length;

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const standalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as any).standalone === true;
    setIsStandalone(standalone);
    if (standalone) return;

    const dismissed = sessionStorage.getItem('colloquium_install_popup_dismissed');
    if (dismissed === 'true') return;

    const isMobileDevice =
      window.innerWidth < 768 ||
      /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

    if (isMobileDevice) {
      const timer = setTimeout(() => {
        setShowMobileInstallPopup(true);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleDismissPopup = () => {
    setShowMobileInstallPopup(false);
    sessionStorage.setItem('colloquium_install_popup_dismissed', 'true');
  };

  const handleInstallNow = () => {
    setShowMobileInstallPopup(false);
    sessionStorage.setItem('colloquium_install_popup_dismissed', 'true');

    if (settings.appApkLink && settings.appApkLink.trim()) {
      window.location.href = settings.appApkLink.trim();
      return;
    }

    if (triggerPwaInstall) {
      triggerPwaInstall();
      return;
    }

    if (deferredPrompt && typeof deferredPrompt.prompt === 'function') {
      deferredPrompt.prompt();
      return;
    }

    navigate('/download');
  };

  const handleDownloadButtonClick = () => {
    if (settings.appApkLink && settings.appApkLink.trim()) {
      window.location.href = settings.appApkLink.trim();
      return;
    }

    if (deferredPrompt && typeof deferredPrompt.prompt === 'function') {
      deferredPrompt.prompt();
      return;
    }

    if (triggerPwaInstall) {
      triggerPwaInstall();
      return;
    }

    navigate('/download');
  };

  // Requirement 3: USER ROLES - VERY IMPORTANT - DO NOT MIX THEM!
  // Client CANNOT see worker pay or apply for tasks.
  // Worker CANNOT create orders.
  interface NavItem {
    path: string;
    label: string;
    icon: any;
    active: boolean;
    badge?: number;
  }

  const navLinks: NavItem[] = [
    {
      path: '/',
      label: 'Home',
      icon: Layers,
      active: currentPath === '/',
    },
  ];

  if (userRole === 'client' || !userRole) {
    navLinks.push({
      path: '/order',
      label: 'Order Service',
      icon: PlusCircle,
      active: currentPath === '/order',
    });
  }

  if (userRole === 'client') {
    navLinks.push({
      path: '/client/dashboard',
      label: 'My Client Tasks',
      icon: GraduationCap,
      active:
        currentPath === '/client/dashboard' ||
        currentPath.startsWith('/checkout') ||
        currentPath === '/client/register',
    });
  }

  if (userRole === 'worker') {
    navLinks.push({
      path: '/worker/dashboard',
      label: 'Specialist Workspace',
      icon: Briefcase,
      badge: availableJobsCount > 0 ? availableJobsCount : undefined,
      active: currentPath === '/worker/dashboard' || currentPath === '/worker/register',
    });
  }

  if (userRole === 'admin') {
    navLinks.push({
      path: '/admin',
      label: 'Admin Hub',
      icon: ShieldCheck,
      badge: pendingDepositsCount > 0 ? pendingDepositsCount : undefined,
      active: currentPath === '/admin' || currentPath === '/admin/login',
    });
  }

  const handleNav = (path: string) => {
    navigate(path);
    setMobileMenuOpen(false);
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-[#0E7A4C] text-white shadow-md">
        {/* Main Navigation Bar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Requirement 1: Brand Wordmark with Subtitle "Academic, Digital & Creative Services" */}
            <button
              onClick={() => handleNav('/')}
              className="flex items-center gap-2.5 text-left focus:outline-none group text-white"
            >
              <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center border border-white/20 group-hover:bg-white/20 transition-colors shadow-inner">
                <ColloquiumLogoIcon className="w-6 h-6 text-emerald-200 group-hover:text-white transition-colors" strokeWidth={2.2} />
              </div>
              <div>
                <div className="font-extrabold text-lg sm:text-xl tracking-tight leading-tight flex items-center gap-1.5 text-white">
                  Colloquium <span className="text-emerald-300 font-bold">KE</span>
                </div>
                <div className="text-[10px] sm:text-xs text-emerald-100 font-medium tracking-wide">
                  Academic, Digital &amp; Creative Services
                </div>
              </div>
            </button>

            {/* Desktop Navigation Links */}
            <nav className="hidden md:flex items-center gap-1 lg:gap-2">
              {navLinks.map((link) => {
                const Icon = link.icon;
                return (
                  <button
                    key={link.path}
                    onClick={() => handleNav(link.path)}
                    className={`relative flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
                      link.active
                        ? 'bg-white text-[#0E7A4C] shadow-sm font-bold'
                        : 'text-emerald-100 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 ${link.active ? 'text-[#0E7A4C]' : 'text-emerald-200'}`} />
                    <span>{link.label}</span>
                    {link.badge !== undefined && (
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${
                          link.active ? 'bg-[#0E7A4C] text-white' : 'bg-amber-400 text-slate-900'
                        }`}
                      >
                        {link.badge}
                      </span>
                    )}
                  </button>
                );
              })}

              {!isStandalone && (
                <button
                  onClick={handleDownloadButtonClick}
                  className={`relative flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
                    currentPath === '/download'
                      ? 'bg-white text-[#0E7A4C] shadow-sm font-bold'
                      : 'bg-emerald-800/60 hover:bg-emerald-700/80 text-emerald-100 hover:text-white border border-emerald-600/40'
                  }`}
                  title="Install Colloquium KE App"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-300" />
                  <span>Install App</span>
                </button>
              )}
            </nav>

            {/* Right Section: Auth / Account Action */}
            <div className="hidden sm:flex items-center gap-2.5">
              {currentUser ? (
                <div className="flex items-center gap-2">
                  <div className="text-right text-xs">
                    <span className="text-emerald-200 block text-[10px] uppercase font-bold">
                      {currentUser.role}
                    </span>
                    <span className="font-semibold text-white truncate max-w-[120px] block">
                      {currentUser.displayName}
                    </span>
                  </div>
                  <button
                    onClick={handleLogout}
                    className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-emerald-100 transition"
                    title="Sign Out"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleNav('/login')}
                    className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition flex items-center gap-1"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span>Sign In</span>
                  </button>

                  <button
                    onClick={() => handleNav('/order')}
                    className="bg-white text-[#0E7A4C] hover:bg-emerald-50 px-3.5 py-1.5 rounded-lg text-xs font-bold transition shadow-xs flex items-center gap-1.5"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>Calculate &amp; Order</span>
                  </button>
                </div>
              )}
            </div>

            {/* Mobile menu trigger */}
            <div className="flex md:hidden items-center gap-2">
              {!isStandalone && (
                <button
                  onClick={handleDownloadButtonClick}
                  className="bg-emerald-800/80 text-emerald-100 border border-emerald-600/40 px-2 py-1 rounded-md text-xs font-semibold flex items-center gap-1"
                >
                  <Download className="w-3 h-3" />
                  <span>App</span>
                </button>
              )}
              {(userRole === 'client' || !userRole) && (
                <button
                  onClick={() => handleNav('/order')}
                  className="bg-white text-[#0E7A4C] px-2.5 py-1 rounded-md text-xs font-bold shadow-xs"
                >
                  Order
                </button>
              )}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-1.5 rounded-lg text-emerald-100 hover:text-white hover:bg-white/10"
                aria-label="Toggle navigation menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-[#08432a] border-t border-emerald-800/60 px-4 pt-3 pb-4 space-y-1 shadow-lg">
            <div className="pb-2 mb-2 border-b border-emerald-800/40 text-xs text-emerald-200">
              <span className="font-semibold text-emerald-100">Colloquium KE</span>
              <span className="text-[11px] text-emerald-300 block">Academic, Digital &amp; Creative Services</span>
            </div>

            {navLinks.map((link) => {
              const Icon = link.icon;
              return (
                <button
                  key={link.path}
                  onClick={() => handleNav(link.path)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-semibold transition ${
                    link.active
                      ? 'bg-white text-[#0E7A4C] font-bold shadow-sm'
                      : 'text-emerald-100 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Icon className="w-4 h-4" />
                    <span>{link.label}</span>
                  </div>
                  {link.badge !== undefined && (
                    <span className="bg-amber-400 text-slate-900 text-[10px] font-bold px-1.5 py-0.2 rounded-full">
                      {link.badge}
                    </span>
                  )}
                </button>
              );
            })}

            {!isStandalone && (
              <button
                onClick={() => handleNav('/download')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-semibold transition ${
                  currentPath === '/download'
                    ? 'bg-white text-[#0E7A4C] font-bold shadow-sm'
                    : 'text-emerald-100 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Download className="w-4 h-4 text-emerald-300" />
                  <span>Install App</span>
                </div>
                <span className="text-[10px] bg-emerald-700/60 text-emerald-200 px-1.5 py-0.5 rounded">
                  PWA
                </span>
              </button>
            )}

            <div className="pt-2 border-t border-emerald-800/40 flex items-center justify-between">
              {currentUser ? (
                <div className="flex items-center justify-between w-full text-xs">
                  <span className="text-emerald-200">Logged in as {currentUser.displayName} ({currentUser.role})</span>
                  <button onClick={handleLogout} className="text-white font-bold underline">
                    Sign Out
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => handleNav('/login')}
                  className="w-full py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg text-xs font-bold text-center"
                >
                  Sign In (Client or Worker)
                </button>
              )}
            </div>
          </div>
        )}
      </header>

      {/* 3-Second Mobile Install Prompt */}
      {showMobileInstallPopup && (
        <div className="fixed inset-x-0 bottom-0 z-50 p-4 sm:p-6 bg-black/50 backdrop-blur-xs flex items-end justify-center animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 p-5 max-w-md w-full space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-[#0E7A4C] text-white flex items-center justify-center shrink-0 shadow-md">
                  <ColloquiumLogoIcon className="w-7 h-7 text-white" strokeWidth={2.2} />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base text-slate-900 leading-tight">
                    Install Colloquium KE App
                  </h3>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Install Colloquium KE App for faster orders
                  </p>
                </div>
              </div>
              <button
                onClick={handleDismissPopup}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg transition"
                aria-label="Dismiss popup"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <button
                onClick={handleDismissPopup}
                className="w-full py-2.5 px-3 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-bold transition text-center"
              >
                Continue on Web
              </button>
              <button
                onClick={handleInstallNow}
                className="w-full py-2.5 px-3 rounded-xl bg-[#0E7A4C] hover:bg-[#0b633d] text-white text-xs font-bold transition shadow-md flex items-center justify-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Install Now</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
