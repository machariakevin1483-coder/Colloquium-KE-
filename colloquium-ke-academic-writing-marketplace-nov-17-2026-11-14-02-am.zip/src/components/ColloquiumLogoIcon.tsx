import React from 'react';

interface ColloquiumLogoIconProps {
  className?: string;
  size?: number;
  strokeWidth?: number;
}

export const ColloquiumLogoIcon: React.FC<ColloquiumLogoIconProps> = ({
  className = 'w-6 h-6',
  size,
  strokeWidth = 2,
}) => {
  return (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      width={size}
      height={size}
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-label="Colloquium KE - Book and hand writing with pen"
    >
      {/* Sketched Book - Book Cover Spine and Pages */}
      {/* Book base & bottom cover */}
      <path
        d="M 8 50 L 8 53 C 16 50, 24 49.5, 32 52.5 C 40 49.5, 48 50, 56 53 L 56 50"
        strokeWidth={strokeWidth}
        strokeOpacity="0.8"
      />
      
      {/* Central Book Spine */}
      <path
        d="M 32 23.5 L 32 52"
        strokeWidth={strokeWidth}
      />

      {/* Left Page Outer & Top Edge */}
      <path
        d="M 32 23.5 C 23 20.5, 15 21.5, 8 24.5 L 8 50 C 15 47, 23 46, 32 49"
        strokeWidth={strokeWidth}
      />

      {/* Left Page Sketched Ruled Lines */}
      <path
        d="M 13 29 C 18 27.5, 23 27.5, 27 28.5"
        strokeWidth={Math.max(1, strokeWidth - 0.5)}
        strokeDasharray="0.5 0"
        strokeOpacity="0.75"
      />
      <path
        d="M 13 34.5 C 18 33, 23 33, 27 34"
        strokeWidth={Math.max(1, strokeWidth - 0.5)}
        strokeOpacity="0.75"
      />
      <path
        d="M 13 40 C 18 38.5, 23 38.5, 27 39.5"
        strokeWidth={Math.max(1, strokeWidth - 0.5)}
        strokeOpacity="0.75"
      />
      <path
        d="M 13 45.5 C 18 44, 21 44, 25 44.8"
        strokeWidth={Math.max(1, strokeWidth - 0.5)}
        strokeOpacity="0.6"
      />

      {/* Right Page Outer & Top Edge */}
      <path
        d="M 32 49 C 41 46, 49 47, 56 50 L 56 24.5 C 49 21.5, 41 20.5, 32 23.5"
        strokeWidth={strokeWidth}
      />

      {/* Right Page Sketched Ruled Lines (background) */}
      <path
        d="M 36 29 C 40 28, 44 28, 47 28.8"
        strokeWidth={Math.max(1, strokeWidth - 0.5)}
        strokeOpacity="0.75"
      />
      <path
        d="M 36 34.5 C 39 33.8, 42 33.8, 44 34.2"
        strokeWidth={Math.max(1, strokeWidth - 0.5)}
        strokeOpacity="0.75"
      />

      {/* Hand holding pen writing on book */}
      {/* Fresh ink writing stroke on right page */}
      <path
        d="M 36 43 C 38 42, 40 43.5, 43 42.5"
        strokeWidth={strokeWidth}
        strokeLinecap="round"
      />

      {/* Hand & Pen Assembly */}
      {/* Pen Nib touching paper at (42.5, 42) */}
      <path
        d="M 42.5 42 L 44.5 38.5 L 47 40 L 42.5 42 Z"
        fill="currentColor"
        fillOpacity="0.3"
        strokeWidth={strokeWidth}
      />

      {/* Pen Nib metallic detail */}
      <path
        d="M 43.5 40.5 L 42.5 42"
        strokeWidth={Math.max(1, strokeWidth - 0.5)}
      />

      {/* Pen Barrel extending upwards through the hand */}
      <path
        d="M 45 37 L 54.5 22.5"
        strokeWidth={strokeWidth}
      />
      <path
        d="M 47.5 38.5 L 56.5 24"
        strokeWidth={strokeWidth}
      />

      {/* Pen Top Cap & Clip */}
      <path
        d="M 54.5 22.5 L 56.5 24 L 58.5 21 L 56.5 19.5 Z"
        fill="currentColor"
        fillOpacity="0.2"
        strokeWidth={strokeWidth}
      />

      {/* Hand fingers gripping the pen */}
      {/* Index finger curved over the pen barrel */}
      <path
        d="M 43 33 C 41 29, 44 26, 49 27 C 52 27.5, 54 29, 53.5 32"
        strokeWidth={strokeWidth}
        fill="currentColor"
        fillOpacity="0.15"
      />

      {/* Thumb pressing pen against fingers */}
      <path
        d="M 43 35 C 44 37, 47 38, 49 36"
        strokeWidth={strokeWidth}
      />

      {/* Middle & Ring knuckle folds / hand contour */}
      <path
        d="M 49 27 C 52 24, 56 25, 58 28 C 59.5 30.5, 57 34, 52 36"
        strokeWidth={strokeWidth}
        fill="currentColor"
        fillOpacity="0.1"
      />

      {/* Wrist line leading outwards */}
      <path
        d="M 58 28 C 60 30, 61.5 33, 61 36"
        strokeWidth={strokeWidth}
      />

      {/* Light sketch accent marks around the pen nib indicating active writing / drafting */}
      <path
        d="M 40 40 L 38.5 38.5"
        strokeWidth={Math.max(1, strokeWidth - 0.75)}
        strokeOpacity="0.6"
      />
      <path
        d="M 44.5 44.5 L 46 45.5"
        strokeWidth={Math.max(1, strokeWidth - 0.75)}
        strokeOpacity="0.6"
      />
    </svg>
  );
};
