import React from 'react';
import { ColloquiumLogoIcon } from './ColloquiumLogoIcon';
import {
  Briefcase,
  GraduationCap,
  CheckCircle2,
  ArrowRight,
  Calculator,
  LogIn,
  FileText,
  Presentation,
  CheckCheck,
  Headphones,
  Image,
  Video,
  PenTool,
  Globe,
} from 'lucide-react';

interface OnboardingLandingProps {
  navigate: (path: string) => void;
}

export const OnboardingLanding: React.FC<OnboardingLandingProps> = ({ navigate }) => {
  const handleSelectRole = (role: 'client' | 'worker') => {
    if (role === 'client') {
      navigate('/client/register');
    } else {
      navigate('/worker/register');
    }
  };

  const servicesList = [
    {
      title: 'Academic & Essays',
      rate: 'From 400 KES/page',
      desc: 'Essays, assignments, dissertations, research, APA/Harvard citations',
      icon: FileText,
    },
    {
      title: 'Proofreading & Editing',
      rate: 'From 200 KES/page',
      desc: 'Grammar polish, flow, formatting & Turnitin similarity checks',
      icon: CheckCheck,
    },
    {
      title: 'PowerPoint Presentations',
      rate: 'From 250 KES/slide',
      desc: 'Thesis defense, corporate pitch decks & seminar slides',
      icon: Presentation,
    },
    {
      title: 'Transcription',
      rate: 'From 40 KES/audio min',
      desc: 'Interviews, focus groups, lectures & podcast transcripts',
      icon: Headphones,
    },
    {
      title: 'Photo Editing',
      rate: 'From 300 KES/image',
      desc: 'Headshot retouching, background removal & color correction',
      icon: Image,
    },
    {
      title: 'Video Editing',
      rate: 'From 1,000 KES/min',
      desc: 'Reels, YouTube cuts, captions, color grading & audio polish',
      icon: Video,
    },
    {
      title: 'Logo & Brand Identity',
      rate: 'From 3,000 KES',
      desc: 'Vector concepts, branding kits, typography & social icons',
      icon: PenTool,
    },
    {
      title: 'Web Design',
      rate: 'From 5,000 KES/page',
      desc: 'Modern responsive websites, landing pages & portfolio sites',
      icon: Globe,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between">
      {/* Top Hero Section */}
      <div className="bg-gradient-to-b from-[#0E7A4C] via-[#0b633d] to-[#08432a] text-white pt-12 pb-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto text-center space-y-4">
          <div className="flex justify-center my-2">
            <div className="w-16 h-16 rounded-2xl bg-white/10 border-2 border-white/20 flex items-center justify-center shadow-xl">
              <ColloquiumLogoIcon className="w-10 h-10 text-emerald-200" strokeWidth={2.2} />
            </div>
          </div>

          {/* Requirement 1: APP NAME & SUBTITLE */}
          <div>
            <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-white max-w-3xl mx-auto leading-tight">
              Colloquium <span className="text-emerald-300">KE</span>
            </h1>
            <p className="text-lg sm:text-xl font-bold text-emerald-200 tracking-wide mt-1">
              Academic, Digital &amp; Creative Services
            </p>
          </div>

          {/* Requirement 1: EXACT HOMEPAGE DESCRIPTION */}
          <p className="text-sm sm:text-base text-emerald-100 max-w-2xl mx-auto leading-relaxed">
            "From essays and research to PowerPoint, logos, websites, video and photo editing - order any task, pay securely, get it done by verified experts."
          </p>

          <div className="pt-2 flex flex-wrap items-center justify-center gap-4 text-xs text-emerald-200">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-300" /> Vetted Specialists
            </span>
            <span>·</span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-300" /> Transparent Pricing
            </span>
            <span>·</span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-300" /> Direct Specialist Chat
            </span>
          </div>
        </div>
      </div>

      {/* Main 2 Big Cards Onboarding (Requirement 3: First screen / shows 2 big cards) */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 -mt-14 pb-12 w-full space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Card 1: Client Card */}
          <div
            onClick={() => handleSelectRole('client')}
            className="group cursor-pointer bg-white rounded-2xl p-8 border-2 border-slate-200 hover:border-[#0E7A4C] shadow-lg hover:shadow-2xl transition-all duration-300 flex flex-col justify-between transform hover:-translate-y-1"
          >
            <div className="space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-[#0E7A4C] group-hover:bg-[#0E7A4C] group-hover:text-white transition-colors flex items-center justify-center shadow-md">
                <GraduationCap className="w-8 h-8" />
              </div>

              <div>
                <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider block">
                  For University Students &amp; Businesses
                </span>
                <h2 className="text-2xl font-black text-slate-900 mt-1 group-hover:text-[#0E7A4C] transition-colors">
                  I want to HIRE — I'm a Client
                </h2>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Browse services, calculate transparent prices, upload guidelines, and collaborate directly with your assigned specialist.
                </p>
              </div>

              <ul className="space-y-2 text-xs text-slate-700 pt-2 border-t border-slate-100">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#0E7A4C] shrink-0" />
                  <span>Real-time price calculator for every service</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#0E7A4C] shrink-0" />
                  <span>100% Original Turnitin-verified deliverables</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#0E7A4C] shrink-0" />
                  <span>Verified quality deliverables before final sign-off</span>
                </li>
              </ul>
            </div>

            <div className="pt-6">
              <button
                type="button"
                className="w-full py-3.5 px-5 bg-[#0E7A4C] hover:bg-[#0b633d] text-white font-extrabold text-sm rounded-xl shadow-md flex items-center justify-center gap-2 transition"
              >
                <span>Continue as Client</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>

          {/* Card 2: Worker Card */}
          <div
            onClick={() => handleSelectRole('worker')}
            className="group cursor-pointer bg-white rounded-2xl p-8 border-2 border-slate-200 hover:border-[#0E7A4C] shadow-lg hover:shadow-2xl transition-all duration-300 flex flex-col justify-between transform hover:-translate-y-1"
          >
            <div className="space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-700 group-hover:bg-[#0E7A4C] group-hover:text-white transition-colors flex items-center justify-center shadow-md">
                <Briefcase className="w-8 h-8" />
              </div>

              <div>
                <span className="text-xs font-bold text-amber-700 uppercase tracking-wider block">
                  For Verified Academic &amp; Creative Specialists
                </span>
                <h2 className="text-2xl font-black text-slate-900 mt-1 group-hover:text-[#0E7A4C] transition-colors">
                  I want to WORK — I'm a Worker
                </h2>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Apply with your skills and portfolio samples, get vetted by Admin, and claim confirmed jobs. Earn guaranteed payouts per completed task disbursed via M-Pesa.
                </p>
              </div>

              <ul className="space-y-2 text-xs text-slate-700 pt-2 border-t border-slate-100">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#0E7A4C] shrink-0" />
                  <span>Guaranteed Specialist M-Pesa Payouts</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#0E7A4C] shrink-0" />
                  <span>Direct client chat &amp; file exchange</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#0E7A4C] shrink-0" />
                  <span>Instant M-Pesa B2C wallet withdrawals</span>
                </li>
              </ul>
            </div>

            <div className="pt-6">
              <button
                type="button"
                className="w-full py-3.5 px-5 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-sm rounded-xl shadow-md flex items-center justify-center gap-2 transition"
              >
                <span>Apply as Specialist</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>

        {/* Services & Pricing Calculator Grid */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div>
              <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                <Calculator className="w-5 h-5 text-[#0E7A4C]" />
                <span>Explore Services &amp; Transparent Rates</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Every service uses our dynamic price calculator. No hidden fees or fixed surprises.
              </p>
            </div>

            <button
              onClick={() => navigate('/order')}
              className="px-4 py-2 bg-[#0E7A4C] hover:bg-[#0b633d] text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 self-start sm:self-auto shadow-sm"
            >
              <Calculator className="w-3.5 h-3.5" />
              <span>Launch Full Calculator</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            {servicesList.map((svc) => {
              const Icon = svc.icon;
              return (
                <div
                  key={svc.title}
                  onClick={() => navigate('/order')}
                  className="p-4 rounded-xl border border-slate-200 hover:border-[#0E7A4C] hover:shadow-md transition-all cursor-pointer bg-slate-50/50 space-y-2 group"
                >
                  <div className="w-9 h-9 rounded-lg bg-emerald-100/70 text-[#0E7A4C] flex items-center justify-center group-hover:bg-[#0E7A4C] group-hover:text-white transition-colors">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 group-hover:text-[#0E7A4C] transition-colors">
                      {svc.title}
                    </h4>
                    <span className="text-[11px] font-extrabold text-[#0E7A4C] block mt-0.5">
                      {svc.rate}
                    </span>
                    <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
                      {svc.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom Quick Actions: Sign In / Direct Order */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3 text-slate-600 text-center sm:text-left">
            <LogIn className="w-5 h-5 text-[#0E7A4C] shrink-0 hidden sm:block" />
            <div>
              <span className="font-bold text-slate-900 block">Already have an account?</span>
              <span className="text-[11px] text-slate-500">
                Sign in to view your active tasks, specialist workspace, or order records.
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => navigate('/login')}
              className="flex-1 sm:flex-initial px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-lg transition"
            >
              Sign In (Client or Worker)
            </button>
            <button
              onClick={() => navigate('/order')}
              className="flex-1 sm:flex-initial px-4 py-2 bg-[#0E7A4C] hover:bg-[#0b633d] text-white font-bold rounded-lg transition shadow-xs"
            >
              Order Service
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
