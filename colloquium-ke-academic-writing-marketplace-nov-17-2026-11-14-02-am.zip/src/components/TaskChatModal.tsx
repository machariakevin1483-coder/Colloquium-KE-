import React, { useState, useRef, useEffect } from 'react';
import { Order, ChatMessage } from '../types';
import { useOrders } from '../context/OrderContext';
import { censorChatHistory } from '../utils/contactFilter';
import { fileToSafeTaskFile } from '../utils/imageCompress';
import {
  MessageSquare,
  Send,
  X,
  Paperclip,
  Flag,
  Ban,
  Trash2,
  AlertTriangle,
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  FileText,
  Lock,
  Download,
} from 'lucide-react';

interface TaskChatModalProps {
  order: Order;
  isOpen: boolean;
  onClose: () => void;
}

export const TaskChatModal: React.FC<TaskChatModalProps> = ({ order, isOpen, onClose }) => {
  const {
    sendOrderMessage,
    subscribeOrderMessages,
    getOrderById,
    reportChat,
    blockChatConversation,
    unblockChatConversation,
    deleteOrderChat,
    userRole,
  } = useOrders();

  const liveOrder = getOrderById(order.id) || order;

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [inputText, setInputText] = useState('');
  const [attachmentName, setAttachmentName] = useState('');
  const [attachmentUrl, setAttachmentUrl] = useState('');
  const [warningMessage, setWarningMessage] = useState('');
  const [successNotice, setSuccessNotice] = useState('');
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportReason, setReportReason] = useState('Attempted Contact Sharing');
  const [reportDetails, setReportDetails] = useState('');
  const [isSubmittingAction, setIsSubmittingAction] = useState(false);
  const [confirmDeleteModal, setConfirmDeleteModal] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isClient = userRole === 'client';
  const isAdmin = userRole === 'admin';

  const partnerName = isClient
    ? liveOrder.workerDisplayName || 'Assigned Specialist'
    : liveOrder.clientDisplayName || 'Client';

  const isBooked =
    ['Confirmed', 'In Progress', 'Completed', 'Paid to Writer'].includes(liveOrder.status) ||
    isAdmin;

  useEffect(() => {
    if (!isOpen || !isBooked) return;
    setLoadingMessages(true);
    const unsubscribe = subscribeOrderMessages(liveOrder.id, (msgs) => {
      setMessages(msgs);
      setLoadingMessages(false);
    });
    return () => unsubscribe();
  }, [isOpen, isBooked, liveOrder.id]);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [isOpen, messages.length]);

  if (!isOpen) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    setWarningMessage('');
    setSuccessNotice('');

    if ((!inputText.trim() && !attachmentName) || isSending) return;

    setIsSending(true);
    try {
      const res = await sendOrderMessage(
        liveOrder.id,
        inputText.trim(),
        attachmentName || undefined,
        attachmentUrl || undefined
      );
      if (!res.success) {
        setWarningMessage(res.message || 'Message blocked by platform security.');
        return;
      }

      setInputText('');
      setAttachmentName('');
      setAttachmentUrl('');
    } catch (err) {
      setWarningMessage(err instanceof Error ? err.message : 'Unable to send message.');
    } finally {
      setIsSending(false);
    }
  };

  const handleFileAttachment = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setWarningMessage('');
    try {
      const safe = await fileToSafeTaskFile(file, isClient ? 'client' : isAdmin ? 'admin' : 'worker');
      setAttachmentName(safe.name);
      setAttachmentUrl(safe.url);
    } catch (err) {
      setWarningMessage(
        err instanceof Error ? err.message : 'Unable to attach file (max 350KB).'
      );
    }
  };

  const handleReportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmittingAction(true);
    try {
      const res = await reportChat(liveOrder.id, reportReason, reportDetails.trim());
      setShowReportModal(false);
      setReportDetails('');
      setSuccessNotice(res.message);
      setTimeout(() => setSuccessNotice(''), 4000);
    } catch (err) {
      setWarningMessage(err instanceof Error ? err.message : 'Unable to submit report.');
    } finally {
      setIsSubmittingAction(false);
    }
  };

  const handleToggleBlock = async () => {
    setIsSubmittingAction(true);
    try {
      if (liveOrder.isChatBlocked) {
        await unblockChatConversation(liveOrder.id);
        setSuccessNotice('Conversation unblocked.');
      } else {
        await blockChatConversation(liveOrder.id, 'Blocked by participant');
        setSuccessNotice('Conversation blocked. No new messages can be exchanged.');
      }
      setTimeout(() => setSuccessNotice(''), 4000);
    } catch (err) {
      setWarningMessage(err instanceof Error ? err.message : 'Unable to update block status.');
    } finally {
      setIsSubmittingAction(false);
    }
  };

  const handleDeleteChatConfirm = async () => {
    setIsSubmittingAction(true);
    try {
      await deleteOrderChat(liveOrder.id);
      setConfirmDeleteModal(false);
      setSuccessNotice('Chat history cleared by Administrator.');
      setTimeout(() => setSuccessNotice(''), 4000);
    } catch (err) {
      setWarningMessage(err instanceof Error ? err.message : 'Unable to clear chat history.');
    } finally {
      setIsSubmittingAction(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      {/* Container with anti-copy and user-select protection */}
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full flex flex-col h-[600px] max-h-[92vh] overflow-hidden border border-slate-200 select-none">
        
        {/* Header */}
        <div className="bg-[#0E7A4C] text-white px-4 py-3 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center font-bold shrink-0">
              <MessageSquare className="w-5 h-5 text-emerald-100" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-white truncate">Task Chat: {liveOrder.id}</h3>
                <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full font-semibold shrink-0">
                  {liveOrder.status}
                </span>
                {liveOrder.isChatBlocked && (
                  <span className="text-[10px] bg-red-500 text-white px-2 py-0.5 rounded-full font-bold shrink-0">
                    BLOCKED
                  </span>
                )}
              </div>
              <p className="text-xs text-emerald-100 truncate">
                With {partnerName} · {liveOrder.category}
              </p>
            </div>
          </div>

          {/* Action buttons at top of chat: Report, Block, Delete (Admin), Close */}
          <div className="flex items-center gap-1.5 shrink-0">
            {/* Report Button */}
            {!isAdmin && (
              <button
                type="button"
                onClick={() => setShowReportModal(true)}
                className="px-2.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-[11px] font-semibold flex items-center gap-1 transition"
                title="Report user or safety concern"
              >
                <Flag className="w-3.5 h-3.5 text-amber-300" />
                <span className="hidden sm:inline">Report</span>
              </button>
            )}

            {/* Block Button */}
            {!isAdmin && (
              <button
                type="button"
                disabled={isSubmittingAction}
                onClick={handleToggleBlock}
                className={`px-2.5 py-1.5 rounded-lg text-[11px] font-semibold flex items-center gap-1 transition ${
                  liveOrder.isChatBlocked
                    ? 'bg-amber-500 hover:bg-amber-600 text-white'
                    : 'bg-white/10 hover:bg-white/20 text-white'
                }`}
                title={liveOrder.isChatBlocked ? 'Unblock conversation' : 'Block conversation'}
              >
                <Ban className="w-3.5 h-3.5 text-red-300" />
                <span className="hidden sm:inline">{liveOrder.isChatBlocked ? 'Unblock' : 'Block'}</span>
              </button>
            )}

            {/* Admin Delete Chat Option */}
            {isAdmin && (
              <button
                type="button"
                onClick={() => setConfirmDeleteModal(true)}
                className="px-2.5 py-1.5 rounded-lg bg-red-600/80 hover:bg-red-600 text-white text-[11px] font-semibold flex items-center gap-1 transition"
                title="Delete/Purge Chat History"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Delete Chat</span>
              </button>
            )}

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition ml-1"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Small Notice at the top of every chat (Prompt Rule 3):
            "Do not share your phone number or email. Keep all payments inside Colloquium KE." */}
        <div className="bg-amber-50 border-b border-amber-200 px-3.5 py-2 text-[11px] text-amber-900 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0" />
            <span className="font-medium">
              <strong>Notice:</strong> Do not share your phone number or email. Keep all payments inside Colloquium KE.
            </span>
          </div>
          <span className="text-[10px] uppercase font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded border border-amber-200 hidden sm:inline">
            Safe Escrow
          </span>
        </div>

        {/* Dynamic Warning Notification if blocked attempt occurs */}
        {warningMessage && (
          <div className="bg-red-50 border-b-2 border-red-300 p-3 text-xs text-red-800 flex items-start gap-2.5 shrink-0 animate-in fade-in duration-200">
            <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <span className="font-bold block text-red-900">Message Blocked by Contact Shield</span>
              <p className="mt-0.5 leading-relaxed">{warningMessage}</p>
            </div>
            <button
              onClick={() => setWarningMessage('')}
              className="text-red-400 hover:text-red-700 p-0.5"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Dynamic Success Notification */}
        {successNotice && (
          <div className="bg-emerald-50 border-b border-emerald-200 p-2.5 text-xs text-emerald-900 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successNotice}</span>
            </div>
            <button
              onClick={() => setSuccessNotice('')}
              className="text-emerald-500 hover:text-emerald-800"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Rule 1: Chat only opens after a job is booked / accepted */}
        {!isBooked ? (
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center bg-slate-50 text-xs space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-200 text-slate-500 flex items-center justify-center">
              <Lock className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-sm text-slate-900">Chat Locked Prior to Booking</h4>
            <p className="text-slate-500 max-w-sm leading-relaxed">
              For security, direct specialist messaging opens only after an order is booked and verified by Admin.
            </p>
            <div className="pt-2">
              <span className="px-3 py-1 bg-amber-50 text-amber-800 border border-amber-200 rounded-full font-semibold text-[11px]">
                Status: {liveOrder.status}
              </span>
            </div>
          </div>
        ) : (
          /* Messages Stream with censored text display for past history */
          <div
            className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50/70 text-xs"
            onContextMenu={(e) => e.preventDefault()}
          >
            {loadingMessages ? (
              <div className="text-center py-12 text-slate-400">
                Loading messages...
              </div>
            ) : messages.length === 0 ? (
              <div className="text-center py-12 text-slate-400 space-y-2">
                <MessageSquare className="w-8 h-8 mx-auto text-slate-300" />
                <p className="font-semibold text-slate-600">No messages yet on this task</p>
                <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                  Task discussion is strictly protected. Clarify guidelines, request drafts, or share deliverables.
                </p>
              </div>
            ) : (
              messages.map((msg) => {
                const isMe = msg.senderRole === userRole;
                const safeText = censorChatHistory(msg.text);

                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                  >
                    <div className="flex items-center gap-1.5 mb-1 px-1 text-[10px] text-slate-400">
                      <span className="font-bold text-slate-700">{msg.senderName}</span>
                      <span className="capitalize">({msg.senderRole})</span>
                      <span>·</span>
                      <span>{msg.timestamp}</span>
                    </div>

                    <div
                      className={`max-w-[85%] rounded-2xl px-4 py-2.5 shadow-xs select-none ${
                        isMe
                          ? 'bg-[#0E7A4C] text-white rounded-tr-xs'
                          : msg.senderRole === 'admin'
                          ? 'bg-amber-100 text-amber-950 border border-amber-300 rounded-tl-xs'
                          : 'bg-white text-slate-800 border border-slate-200 rounded-tl-xs'
                      }`}
                    >
                      {safeText && <p className="leading-relaxed whitespace-pre-wrap">{safeText}</p>}
                      {msg.attachmentName && (
                        <div
                          className={`mt-2 flex items-center justify-between gap-2 p-1.5 rounded-lg text-[11px] font-semibold ${
                            isMe ? 'bg-white/20 text-white' : 'bg-slate-100 text-[#0E7A4C]'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 min-w-0">
                            <FileText className="w-3.5 h-3.5 shrink-0" />
                            <span className="truncate">{msg.attachmentName}</span>
                          </div>
                          {msg.attachmentUrl && (
                            <a
                              href={msg.attachmentUrl}
                              download={msg.attachmentName}
                              className="shrink-0 p-1 rounded hover:bg-black/10"
                              title="Download attachment"
                            >
                              <Download className="w-3.5 h-3.5" />
                            </a>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>
        )}

        {/* Input Form (Disabled if chat is blocked or unbooked) */}
        {isBooked && (
          <form onSubmit={handleSend} className="p-3 bg-white border-t border-slate-200 space-y-2">
            {attachmentName && (
              <div className="flex items-center justify-between bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-1.5 text-xs text-[#0E7A4C]">
                <span className="truncate">Attached: {attachmentName}</span>
                <button
                  type="button"
                  onClick={() => {
                    setAttachmentName('');
                    setAttachmentUrl('');
                  }}
                  className="text-slate-400 hover:text-red-500 ml-2"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {liveOrder.isChatBlocked ? (
              <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-center text-xs text-red-800 flex items-center justify-center gap-2">
                <Ban className="w-4 h-4 text-red-600" />
                <span>This chat has been blocked. No messages can be sent.</span>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileAttachment}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="p-2.5 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-600 transition shrink-0"
                  title="Attach task document or sample (max 350KB)"
                >
                  <Paperclip className="w-4 h-4" />
                </button>

                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => {
                    setInputText(e.target.value);
                    if (warningMessage) setWarningMessage('');
                  }}
                  placeholder={`Write message to ${partnerName}... (No phone numbers or emails)`}
                  className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                />

                <button
                  type="submit"
                  disabled={isSending || (!inputText.trim() && !attachmentName)}
                  className={`p-2.5 rounded-xl font-bold transition flex items-center justify-center shrink-0 ${
                    !isSending && (inputText.trim() || attachmentName)
                      ? 'bg-[#0E7A4C] hover:bg-[#0b633d] text-white shadow-sm'
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  }`}
                  title="Send message"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            )}

            <div className="text-[10px] text-slate-400 text-center flex items-center justify-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-600" />
              <span>Contact Shield Enabled · External links &amp; contact sharing auto-filtered</span>
            </div>
          </form>
        )}

        {/* Modal: Report User / Chat */}
        {showReportModal && (
          <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 border border-slate-200 shadow-2xl">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                  <Flag className="w-4 h-4 text-amber-600" />
                  <span>Report Conversation</span>
                </div>
                <button
                  onClick={() => setShowReportModal(false)}
                  className="text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleReportSubmit} className="space-y-3 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Select Safety Concern
                  </label>
                  <select
                    value={reportReason}
                    onChange={(e) => setReportReason(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 font-semibold"
                  >
                    <option value="Attempted Contact Sharing">Attempted Contact Sharing (Phone, Email, WhatsApp)</option>
                    <option value="Off-Platform Payment Request">Off-Platform Payment Request (Bypassing Escrow)</option>
                    <option value="Unprofessional or Abusive Conduct">Unprofessional or Abusive Conduct</option>
                    <option value="Submitting Fraudulent or Empty Work">Submitting Fraudulent or Empty Work</option>
                    <option value="Other Policy Violation">Other Policy Violation</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Details / Message Context (Optional)
                  </label>
                  <textarea
                    rows={3}
                    value={reportDetails}
                    onChange={(e) => setReportDetails(e.target.value)}
                    placeholder="Provide any additional notes for the Administrator..."
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowReportModal(false)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingAction}
                    className="px-4 py-2 bg-red-600 hover:bg-red-700 disabled:bg-red-300 text-white font-bold rounded-xl shadow-xs"
                  >
                    {isSubmittingAction ? 'Submitting...' : 'Submit Report'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal: Admin Confirm Delete Chat */}
        {confirmDeleteModal && (
          <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-sm w-full p-6 space-y-4 border border-red-200 shadow-2xl text-center">
              <div className="w-12 h-12 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center mx-auto">
                <Trash2 className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-base text-slate-900">Delete Chat History?</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                This will permanently clear all messages exchanged on task <strong>{liveOrder.id}</strong>. This action is recorded in the admin log.
              </p>
              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setConfirmDeleteModal(false)}
                  className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isSubmittingAction}
                  onClick={handleDeleteChatConfirm}
                  className="flex-1 py-2 bg-red-600 hover:bg-red-700 disabled:bg-red-300 text-white text-xs font-bold rounded-xl shadow-xs"
                >
                  {isSubmittingAction ? 'Deleting...' : 'Confirm Delete'}
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
