import React, { useState, useRef } from 'react';
import { useOrders } from '../context/OrderContext';
import { Order } from '../types';
import { StatusBadge } from './StatusBadge';
import { TaskChatModal } from './TaskChatModal';
import { fileToSafeTaskFile } from '../utils/imageCompress';
import {
  Wallet,
  ArrowUpRight,
  Briefcase,
  CheckCircle,
  Clock,
  FileText,
  AlertCircle,
  Send,
  X,
  Smartphone,
  History,
  Layers,
  User,
  Info,
  MessageSquare,
  Hourglass,
  UploadCloud,
} from 'lucide-react';

interface WriterDashboardProps {
  navigate: (path: string) => void;
}

export const WriterDashboard: React.FC<WriterDashboardProps> = ({ navigate }) => {
  const {
    orders,
    wallet,
    withdrawals,
    currentUser,
    claimJobByWorker,
    submitWorkerSolution,
    withdrawEarnings,
  } = useOrders();

  const [activeTab, setActiveTab] = useState<'available' | 'my-jobs' | 'history'>('available');
  const [actionError, setActionError] = useState('');
  const [actionNotice, setActionNotice] = useState('');
  const [claimingOrderId, setClaimingOrderId] = useState<string | null>(null);

  // Withdrawal modal state
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState<number>(wallet.availableBalance || 1000);
  const [mpesaNumber, setMpesaNumber] = useState(
    currentUser?.mpesaPhoneNumber || currentUser?.phone || ''
  );
  const [isWithdrawing, setIsWithdrawing] = useState(false);
  const [withdrawResult, setWithdrawResult] = useState<{
    success: boolean;
    message: string;
    ref?: string;
  } | null>(null);

  // Submit Work modal state
  const [submittingOrder, setSubmittingOrder] = useState<Order | null>(null);
  const [solutionDocName, setSolutionDocName] = useState('Completed_Task_Solution.docx');
  const [solutionDocUrl, setSolutionDocUrl] = useState<string>('');
  const [solutionNotes, setSolutionNotes] = useState('');
  const [similarityIndex, setSimilarityIndex] = useState('0%');
  const [isSubmittingSolution, setIsSubmittingSolution] = useState(false);
  const [solutionUploadError, setSolutionUploadError] = useState('');
  const solutionFileInputRef = useRef<HTMLInputElement>(null);

  // Chat modal state
  const [chatOrder, setChatOrder] = useState<Order | null>(null);

  // Current worker identity & approval status
  const currentWorkerId = currentUser?.id || '';
  const isApprovedWorker = Boolean(
    currentUser &&
      currentUser.isApproved === true &&
      !currentUser.isSuspended &&
      !currentUser.isBlockedByAdmin
  );
  const isPendingApproval = Boolean(
    currentUser &&
      (currentUser.approvalStatus === 'pending' || currentUser.isApproved === false)
  );

  const currentWorkerDisplayName = currentUser?.displayName
    ? `${currentUser.displayName} (★ ${currentUser.rating || 4.9})`
    : 'Vetted Specialist';

  // Available Jobs = Status is 'Confirmed' (25% deposit verified by Admin, ready to take)
  const availableJobs = orders.filter((o) => o.status === 'Confirmed');

  // My Jobs = Strictly orders assigned to this authenticated worker
  const myJobs = currentWorkerId
    ? orders.filter((o) => o.assignedWorkerId === currentWorkerId)
    : [];

  const handleClaim = async (orderId: string) => {
    setActionError('');
    setActionNotice('');
    if (!currentWorkerId || !isApprovedWorker) {
      setActionError(
        'Your account is currently pending admin approval or restricted. You cannot claim tasks yet.'
      );
      return;
    }
    setClaimingOrderId(orderId);
    try {
      const ok = await claimJobByWorker(orderId, currentWorkerId, currentWorkerDisplayName);
      if (ok) {
        setActionNotice(`Task ${orderId} claimed successfully. You can now message the client and upload deliverables.`);
        setActiveTab('my-jobs');
      } else {
        setActionError('This task is no longer available to claim.');
      }
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Unable to claim task right now.');
    } finally {
      setClaimingOrderId(null);
    }
  };

  const handleOpenSubmitModal = (order: Order) => {
    setSubmittingOrder(order);
    setSolutionDocName(`${order.id}_${order.category.replace(/\s+/g, '_')}_Completed.docx`);
    setSolutionDocUrl('');
    setSolutionUploadError('');
    setSolutionNotes(
      'All work completed according to instructions and specifications. Quality verified.'
    );
  };

  const handleSolutionFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setSolutionUploadError('');
    try {
      const safeFile = await fileToSafeTaskFile(file, 'worker');
      setSolutionDocName(safeFile.name);
      setSolutionDocUrl(safeFile.url);
    } catch (err) {
      setSolutionUploadError(
        err instanceof Error ? err.message : 'Unable to attach file. Please use a file under 350KB or share via task chat.'
      );
    }
  };

  const handleSubmitSolution = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!submittingOrder) return;

    setIsSubmittingSolution(true);
    setSolutionUploadError('');
    try {
      const ok = await submitWorkerSolution(
        submittingOrder.id,
        `${solutionNotes} (Quality Check: ${similarityIndex})`,
        solutionDocName,
        solutionDocUrl || undefined
      );
      if (ok) {
        setActionNotice(`Delivery for ${submittingOrder.id} submitted to client for review.`);
        setSubmittingOrder(null);
      } else {
        setSolutionUploadError('Unable to submit delivery. Ensure the task is In Progress.');
      }
    } catch (err) {
      setSolutionUploadError(err instanceof Error ? err.message : 'Failed to submit delivery.');
    } finally {
      setIsSubmittingSolution(false);
    }
  };

  const handleWithdrawSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mpesaNumber.trim()) {
      setWithdrawResult({ success: false, message: 'Please enter a valid M-Pesa phone number.' });
      return;
    }
    setIsWithdrawing(true);
    setWithdrawResult(null);
    try {
      const res = await withdrawEarnings(withdrawAmount, mpesaNumber);
      setWithdrawResult(res);
      if (res.success) {
        setTimeout(() => {
          setShowWithdrawModal(false);
          setWithdrawResult(null);
        }, 2000);
      }
    } catch (err) {
      setWithdrawResult({
        success: false,
        message: err instanceof Error ? err.message : 'Withdrawal failed.',
      });
    } finally {
      setIsWithdrawing(false);
    }
  };

  // Helper for delivery countdown
  const getDeliveryCountdown = (deadlineStr: string) => {
    const diffMs = new Date(deadlineStr).getTime() - Date.now();
    const diffHours = Math.round(diffMs / (3600 * 1000));
    if (diffHours < 0) return `${Math.abs(diffHours)}h overdue`;
    return `${diffHours}h remaining`;
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl p-8 border border-slate-200 shadow-lg text-center space-y-4">
          <h2 className="text-xl font-black text-slate-900">Sign In Required</h2>
          <p className="text-xs text-slate-600">
            Please sign in with your specialist account to view available jobs and manage deliveries.
          </p>
          <button
            onClick={() => navigate('/login')}
            className="w-full py-2.5 bg-[#0E7A4C] hover:bg-[#0b633d] text-white text-xs font-bold rounded-xl transition"
          >
            Go to Sign In
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header Profile with Verification Status */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-[#0E7A4C] uppercase tracking-wider">
                Specialist Workspace
              </span>
              <span>·</span>
              <span className="text-xs text-slate-500">
                {currentUser.displayName}
              </span>
              {isApprovedWorker ? (
                <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded-full text-[10px] font-bold">
                  ✓ Approved Specialist
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-800 border border-amber-200 px-2 py-0.5 rounded-full text-[10px] font-bold">
                  <Hourglass className="w-3 h-3" />
                  <span>Pending Approval</span>
                </span>
              )}
            </div>
            <h1 className="text-2xl font-black text-slate-900 mt-0.5">
              Specialist Hub &amp; Available Tasks
            </h1>
            <p className="text-xs text-slate-600 mt-1">
              Active Specialist: <strong className="text-slate-800">{currentWorkerDisplayName}</strong> · Payouts disbursed directly to M-Pesa upon task completion.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setWithdrawAmount(wallet.availableBalance > 0 ? wallet.availableBalance : 500);
                setMpesaNumber(currentUser?.mpesaPhoneNumber || currentUser?.phone || '');
                setShowWithdrawModal(true);
              }}
              disabled={wallet.availableBalance <= 0}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-sm ${
                wallet.availableBalance > 0
                  ? 'bg-[#0E7A4C] hover:bg-[#0b633d] text-white shadow-emerald-900/10'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              <ArrowUpRight className="w-4 h-4" />
              <span>Withdraw to M-Pesa</span>
            </button>
          </div>
        </div>

        {/* Inline Action Feedback */}
        {actionError && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-3.5 text-xs text-red-800 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{actionError}</span>
            </div>
            <button onClick={() => setActionError('')} className="text-red-500 hover:text-red-700">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {actionNotice && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 text-xs text-emerald-900 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{actionNotice}</span>
            </div>
            <button onClick={() => setActionNotice('')} className="text-emerald-600 hover:text-emerald-800">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* WORKER APPROVAL NOTICE IF PENDING */}
        {isPendingApproval && (
          <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-5 text-amber-900 flex items-start gap-3 shadow-xs">
            <Hourglass className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h3 className="font-bold text-sm text-amber-950">
                Application Under Review - Admin Verification in Progress
              </h3>
              <p className="text-xs text-amber-800">
                Welcome to Colloquium KE! Your specialist application and credentials are currently being reviewed by our Admin team. Once approved, you will be able to claim available jobs immediately.
              </p>
              <span className="text-[11px] font-semibold text-amber-700 block">
                Status: Awaiting Admin Approval
              </span>
            </div>
          </div>
        )}

        {/* WORKER PAYMENT GUARANTEE (Commission split strictly hidden from workers) */}
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 text-xs text-emerald-900 flex items-start gap-2.5">
          <Info className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold">Colloquium KE Payment Guarantee:</span> All confirmed tasks on this board are verified and funded by Admin. Your specialist payout is guaranteed and released directly to your M-Pesa upon completion.
          </div>
        </div>

        {/* Wallet Card showing Total Earned, Pending, Withdraw button */}
        <div className="bg-gradient-to-br from-[#0E7A4C] to-[#08432a] text-white rounded-2xl p-6 sm:p-8 shadow-xl border border-emerald-700/40">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-emerald-200 text-xs font-semibold uppercase tracking-wider">
                <Wallet className="w-4 h-4" />
                <span>Specialist Wallet</span>
              </div>
              <div className="text-3xl sm:text-4xl font-black font-mono tracking-tight text-white">
                KES {wallet.availableBalance.toLocaleString()}
              </div>
              <div className="text-xs text-emerald-100">
                Available balance for immediate M-Pesa B2C disbursement
              </div>
            </div>

            {/* Wallet Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-2 md:pt-0 border-t md:border-t-0 border-emerald-800/60">
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3.5 border border-white/10">
                <span className="text-[11px] text-emerald-200 uppercase font-semibold block">
                  Total Earned
                </span>
                <span className="text-lg sm:text-xl font-bold font-mono text-white mt-0.5 block tabular-nums">
                  KES {wallet.totalEarned.toLocaleString()}
                </span>
                <span className="text-[10px] text-emerald-300">Lifetime specialist earnings</span>
              </div>

              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3.5 border border-white/10">
                <span className="text-[11px] text-emerald-200 uppercase font-semibold block">
                  Pending Payout
                </span>
                <span className="text-lg sm:text-xl font-bold font-mono text-amber-300 mt-0.5 block tabular-nums">
                  KES {wallet.pendingPayout.toLocaleString()}
                </span>
                <span className="text-[10px] text-emerald-300">In Progress tasks</span>
              </div>

              <div className="col-span-2 sm:col-span-1 bg-white/15 backdrop-blur-sm rounded-xl p-3.5 border border-white/20 flex flex-col justify-between">
                <div>
                  <span className="text-[11px] text-emerald-200 uppercase font-semibold block">
                    Payout Channel
                  </span>
                  <span className="text-xs font-bold text-white block mt-0.5">
                    Lipa na M-Pesa
                  </span>
                </div>
                <button
                  onClick={() => {
                    setWithdrawAmount(wallet.availableBalance > 0 ? wallet.availableBalance : 500);
                    setMpesaNumber(currentUser?.mpesaPhoneNumber || currentUser?.phone || '');
                    setShowWithdrawModal(true);
                  }}
                  className="mt-2 w-full py-1.5 bg-white text-[#0E7A4C] hover:bg-emerald-50 rounded-lg text-xs font-bold transition text-center shadow-xs"
                >
                  Withdraw
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
          <button
            onClick={() => setActiveTab('available')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition flex items-center gap-2 ${
              activeTab === 'available'
                ? 'bg-[#0E7A4C] text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <Briefcase className="w-3.5 h-3.5" />
            <span>Available Confirmed Jobs</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                activeTab === 'available' ? 'bg-white text-[#0E7A4C]' : 'bg-slate-100 text-slate-800'
              }`}
            >
              {availableJobs.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('my-jobs')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition flex items-center gap-2 ${
              activeTab === 'my-jobs'
                ? 'bg-[#0E7A4C] text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>My Active &amp; Completed Jobs</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                activeTab === 'my-jobs' ? 'bg-white text-[#0E7A4C]' : 'bg-slate-100 text-slate-800'
              }`}
            >
              {myJobs.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition flex items-center gap-2 ${
              activeTab === 'history'
                ? 'bg-[#0E7A4C] text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>M-Pesa Disbursals</span>
          </button>
        </div>

        {/* Tab 1: Available Jobs (Worker sees ONLY: "Your Pay: 65%") */}
        {activeTab === 'available' && (
          <div className="space-y-4">
            {availableJobs.length === 0 ? (
              <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
                <Briefcase className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <h3 className="font-bold text-base text-slate-900">No New Confirmed Tasks</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                  Tasks appear here once verified and confirmed by Admin. Check back shortly.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {availableJobs.map((job) => {
                  const workerPay = job.workerPayAmount || job.writerPayoutAmount || Math.floor(job.totalAmount * 0.65);

                  return (
                    <div
                      key={job.id}
                      className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm hover:border-[#0E7A4C] transition flex flex-col justify-between space-y-4"
                    >
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="font-mono font-bold text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                            {job.id}
                          </span>
                          <span className="text-[11px] font-semibold text-[#0E7A4C] bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                            {job.category}
                          </span>
                        </div>

                        <div>
                          <h3 className="font-bold text-base text-slate-900 leading-snug line-clamp-2">
                            {job.topic}
                          </h3>
                          {/* Worker sees ONLY client alias. HIDE client email, phone, full name. */}
                          <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                            <span className="font-semibold text-slate-700 flex items-center gap-1">
                              <User className="w-3.5 h-3.5 text-slate-400" />
                              <span>Client: {job.clientDisplayName}</span>
                            </span>
                            <span>·</span>
                            <span>{job.academicLevel || job.serviceTier || 'Standard'}</span>
                          </div>
                        </div>

                        {/* WORKER ONLY SEES VERIFIED STATUS (NO CLIENT ESCROW SPLIT OR TOTAL PRICE) */}
                        <div className="bg-emerald-50/80 border border-emerald-200 p-2.5 rounded-lg text-xs text-[#0E7A4C] font-semibold flex items-center justify-between">
                          <span>Task Payment Verified</span>
                          <span className="text-[11px] text-emerald-800">Confirmed by Admin</span>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-3 rounded-lg border border-slate-100">
                          <div>
                            <span className="text-slate-400 block">Task Scope:</span>
                            <span className="font-semibold text-slate-800">
                              {job.quantityValue} {job.quantityUnit || 'units'}
                            </span>
                          </div>
                          <div>
                            <span className="text-slate-400 block">Countdown:</span>
                            <div className="flex items-center gap-1 font-semibold text-slate-800">
                              <Clock className="w-3.5 h-3.5 text-amber-600" />
                              <span>{getDeliveryCountdown(job.deadline)}</span>
                            </div>
                          </div>
                        </div>

                        {job.instructions && (
                          <div className="text-xs text-slate-600 line-clamp-2 italic bg-slate-50/50 p-2 rounded">
                            "{job.instructions}"
                          </div>
                        )}
                      </div>

                      <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                        <div>
                          <span className="text-sm font-black font-mono text-[#0E7A4C]">
                            Your Pay: KES {workerPay.toLocaleString()}
                          </span>
                        </div>

                        <button
                          onClick={() => handleClaim(job.id)}
                          disabled={isPendingApproval || claimingOrderId === job.id}
                          className={`px-4 py-2 text-xs font-bold rounded-lg transition shadow-sm flex items-center gap-1.5 ${
                            isPendingApproval || claimingOrderId === job.id
                              ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                              : 'bg-[#0E7A4C] hover:bg-[#0b633d] text-white'
                          }`}
                        >
                          <CheckCircle className="w-4 h-4" />
                          <span>
                            {isPendingApproval
                              ? 'Approval Required'
                              : claimingOrderId === job.id
                              ? 'Claiming...'
                              : 'Accept & Claim Job'}
                          </span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: My Jobs */}
        {activeTab === 'my-jobs' && (
          <div className="space-y-4">
            {myJobs.length === 0 ? (
              <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
                <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <h3 className="font-bold text-base text-slate-900">No Claimed Tasks</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Go to "Available Confirmed Jobs" to claim assignments.
                </p>
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase">
                      <tr>
                        <th className="py-3 px-4">Task ID</th>
                        <th className="py-3 px-4">Service &amp; Topic</th>
                        <th className="py-3 px-4">Client</th>
                        <th className="py-3 px-4">Countdown</th>
                        <th className="py-3 px-4 text-right">Your Pay</th>
                        <th className="py-3 px-4 text-center">Status</th>
                        <th className="py-3 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {myJobs.map((job) => {
                        const workerPay = job.workerPayAmount || job.writerPayoutAmount || Math.floor(job.totalAmount * 0.65);

                        return (
                          <tr key={job.id} className="hover:bg-slate-50/80">
                            <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                              {job.id}
                            </td>
                            <td className="py-3.5 px-4 max-w-sm">
                              <span className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.2 rounded font-semibold">
                                {job.category}
                              </span>
                              <div className="font-semibold text-slate-900 line-clamp-1 mt-0.5">
                                {job.topic}
                              </div>
                              <div className="text-[11px] text-slate-500">
                                {job.quantityValue} {job.quantityUnit || 'units'}
                              </div>
                            </td>
                            {/* Client privacy: ONLY first name alias */}
                            <td className="py-3.5 px-4 whitespace-nowrap">
                              <div className="font-medium text-slate-700">{job.clientDisplayName}</div>
                              <button
                                onClick={() => setChatOrder(job)}
                                className="text-[10px] text-[#0E7A4C] font-semibold hover:underline flex items-center gap-1 mt-0.5"
                              >
                                <MessageSquare className="w-3 h-3" />
                                <span>Chat with Client</span>
                              </button>
                            </td>
                            <td className="py-3.5 px-4 whitespace-nowrap text-slate-700 font-mono">
                              {getDeliveryCountdown(job.deadline)}
                            </td>
                            <td className="py-3.5 px-4 text-right font-mono font-bold text-[#0E7A4C] whitespace-nowrap">
                              KES {workerPay.toLocaleString()}
                            </td>
                            <td className="py-3.5 px-4 text-center whitespace-nowrap">
                              <StatusBadge status={job.status} size="sm" />
                            </td>
                            <td className="py-3.5 px-4 text-right whitespace-nowrap space-x-1.5">
                              {job.status === 'In Progress' && (
                                <button
                                  onClick={() => handleOpenSubmitModal(job)}
                                  className="px-3 py-1.5 bg-[#0E7A4C] hover:bg-[#0b633d] text-white font-bold rounded-lg transition text-xs shadow-xs inline-flex items-center gap-1"
                                >
                                  <Send className="w-3.5 h-3.5" />
                                  <span>Upload Work</span>
                                </button>
                              )}
                              {job.status === 'Completed' && (
                                <span className="text-[11px] text-amber-700 font-semibold bg-amber-50 px-2.5 py-1 rounded border border-amber-200">
                                  Awaiting Client Review &amp; Release
                                </span>
                              )}
                              {job.status === 'Paid to Writer' && (
                                <span className="text-[11px] text-emerald-700 font-semibold bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200">
                                  ✓ Disbursed
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Withdrawal History */}
        {activeTab === 'history' && (
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-200 flex justify-between items-center">
              <h3 className="font-bold text-sm text-slate-900">M-Pesa Disbursal History</h3>
              <span className="text-xs text-slate-500">Automated M-Pesa B2C Disbursals</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase">
                  <tr>
                    <th className="py-3 px-4">Transaction Reference</th>
                    <th className="py-3 px-4">M-Pesa Phone</th>
                    <th className="py-3 px-4">Disbursal Time</th>
                    <th className="py-3 px-4 text-right">Amount (KES)</th>
                    <th className="py-3 px-4 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {withdrawals.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-slate-400">
                        No withdrawals yet. Completed earnings will appear here once disbursed.
                      </td>
                    </tr>
                  ) : (
                    withdrawals.map((w) => (
                      <tr key={w.id} className="hover:bg-slate-50">
                        <td className="py-3 px-4 font-mono font-bold text-slate-900">
                          {w.reference}
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-700">{w.mpesaNumber}</td>
                        <td className="py-3 px-4 text-slate-500">{w.date}</td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-[#0E7A4C]">
                          KES {w.amount.toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded text-[11px] font-semibold">
                            {w.status}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Withdrawal Modal */}
        {showWithdrawModal && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
              <div className="bg-[#0E7A4C] text-white px-6 py-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-emerald-200" />
                  <h3 className="font-bold text-base">Withdraw to M-Pesa</h3>
                </div>
                <button
                  onClick={() => setShowWithdrawModal(false)}
                  className="p-1 rounded-lg text-white/80 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleWithdrawSubmit} className="p-6 space-y-4 text-xs">
                {withdrawResult && (
                  <div
                    className={`p-3 rounded-lg border ${
                      withdrawResult.success
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                        : 'bg-red-50 border-red-200 text-red-700'
                    }`}
                  >
                    {withdrawResult.message}
                  </div>
                )}

                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 flex justify-between items-center">
                  <div>
                    <span className="text-slate-500 block">Available Balance:</span>
                    <span className="text-xl font-black font-mono text-[#0E7A4C]">
                      KES {wallet.availableBalance.toLocaleString()}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setWithdrawAmount(wallet.availableBalance)}
                    className="text-[11px] font-bold text-blue-600 hover:underline"
                  >
                    Withdraw All
                  </button>
                </div>

                <div>
                  <label htmlFor="writer-withdraw-amount-input" className="block font-semibold text-slate-700 mb-1">
                    Withdrawal Amount (KES)
                  </label>
                  <input
                    id="writer-withdraw-amount-input"
                    type="number"
                    min={100}
                    max={wallet.availableBalance}
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(Number(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono font-bold text-sm focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="writer-payout-mpesa-phone-input" className="block font-semibold text-slate-700 mb-1">
                    M-Pesa Registered Mobile Number
                  </label>
                  <input
                    id="writer-payout-mpesa-phone-input"
                    type="tel"
                    value={mpesaNumber}
                    onChange={(e) => setMpesaNumber(e.target.value)}
                    placeholder="07XXXXXXXX"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                    required
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Instant B2C transfer via Lipa na M-Pesa Gateway
                  </span>
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowWithdrawModal(false)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isWithdrawing || withdrawAmount <= 0 || withdrawAmount > wallet.availableBalance}
                    className="px-5 py-2 bg-[#0E7A4C] hover:bg-[#0b633d] disabled:bg-slate-300 text-white rounded-lg font-bold shadow-sm"
                  >
                    {isWithdrawing ? 'Processing...' : 'Confirm & Disburse'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Submit Completed Work Modal */}
        {submittingOrder && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
              <div className="bg-[#0E7A4C] text-white px-6 py-4 flex items-center justify-between">
                <div>
                  <div className="text-xs text-emerald-200 font-mono font-bold">
                    Submit Delivery: {submittingOrder.id}
                  </div>
                  <h3 className="font-bold text-base text-white line-clamp-1">
                    {submittingOrder.topic}
                  </h3>
                </div>
                <button
                  onClick={() => setSubmittingOrder(null)}
                  className="p-1 rounded-lg text-white/80 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSubmitSolution} className="p-6 space-y-4 text-xs">
                {solutionUploadError && (
                  <div className="bg-red-50 border border-red-200 text-red-700 p-2.5 rounded-lg">
                    {solutionUploadError}
                  </div>
                )}

                <div>
                  <label htmlFor="writer-solution-filename-input" className="block font-semibold text-slate-700 mb-1">
                    Completed Solution Filename <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="writer-solution-filename-input"
                    type="text"
                    value={solutionDocName}
                    onChange={(e) => setSolutionDocName(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Attach Deliverable File (Optional, max 350KB)
                  </label>
                  <div
                    onClick={() => solutionFileInputRef.current?.click()}
                    className="border-2 border-dashed border-slate-300 hover:border-[#0E7A4C] rounded-xl p-3 text-center cursor-pointer transition bg-slate-50 flex items-center justify-center gap-2"
                  >
                    <input
                      ref={solutionFileInputRef}
                      type="file"
                      onChange={handleSolutionFileChange}
                      className="hidden"
                    />
                    <UploadCloud className="w-4 h-4 text-[#0E7A4C]" />
                    <span className="font-semibold text-slate-700 truncate">
                      {solutionDocUrl ? `Attached: ${solutionDocName}` : 'Click to attach finished file'}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="writer-similarity-input" className="block font-semibold text-slate-700 mb-1">
                      Quality / Similarity Check
                    </label>
                    <input
                      id="writer-similarity-input"
                      type="text"
                      value={similarityIndex}
                      onChange={(e) => setSimilarityIndex(e.target.value)}
                      placeholder="e.g. 0% AI, 2% Plagiarism"
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                    />
                  </div>
                  <div>
                    <label htmlFor="writer-units-input" className="block font-semibold text-slate-700 mb-1">
                      Delivered Units
                    </label>
                    <input
                      id="writer-units-input"
                      type="text"
                      disabled
                      value={`${submittingOrder.quantityValue} ${submittingOrder.quantityUnit || 'units'}`}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-slate-100 text-xs text-slate-600 font-medium"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="writer-submission-summary-textarea" className="block font-semibold text-slate-700 mb-1">
                    Delivery Handover Notes &amp; Summary
                  </label>
                  <textarea
                    id="writer-submission-summary-textarea"
                    rows={4}
                    value={solutionNotes}
                    onChange={(e) => setSolutionNotes(e.target.value)}
                    placeholder="Provide overview of citations, designs, methodology, appendices included..."
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                    required
                  />
                </div>

                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-900 text-[11px]">
                  Submitting marks this task as <strong className="font-bold">Completed</strong>. Once the client reviews and confirms your delivery, Admin releases your payout (KES {(submittingOrder.workerPayAmount || Math.floor(submittingOrder.totalAmount * 0.65)).toLocaleString()}).
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setSubmittingOrder(null)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingSolution}
                    className="px-5 py-2 bg-[#0E7A4C] hover:bg-[#0b633d] disabled:bg-slate-300 text-white rounded-lg font-bold shadow-sm flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isSubmittingSolution ? 'Uploading...' : 'Upload Work'}</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Task Chat Modal */}
        {chatOrder && (
          <TaskChatModal
            isOpen={!!chatOrder}
            onClose={() => setChatOrder(null)}
            order={chatOrder}
          />
        )}
      </div>
    </div>
  );
};
