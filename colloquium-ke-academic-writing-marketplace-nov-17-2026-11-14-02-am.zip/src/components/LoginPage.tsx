import React, { useState } from 'react';
import { useOrders } from '../context/OrderContext';
import { ColloquiumLogoIcon } from './ColloquiumLogoIcon';
import {
  AlertCircle,
  ArrowRight,
  User,
  Lock,
  GraduationCap,
  Briefcase,
  Loader2,
  CheckCircle2,
  Mail,
} from 'lucide-react';

interface LoginPageProps {
  navigate: (path: string) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ navigate }) => {
  const {
    login,
    loginWithGoogle,
    sendPasswordReset,
    resendVerificationEmail,
    adminNeedsVerification,
    pendingOrderDraft,
    setPendingOrderDraft,
    createOrder,
  } = useOrders();

  const [selectedRole, setSelectedRole] = useState<'client' | 'worker'>('client');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [infoMessage, setInfoMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showResetMode, setShowResetMode] = useState(false);

  const routeAfterAuth = async (role: string | undefined, authedUser: any) => {
    if (role === 'admin') {
      navigate('/admin');
      return;
    }
    if (role === 'client') {
      if (pendingOrderDraft && authedUser) {
        const draft = pendingOrderDraft;
        setPendingOrderDraft(null);
        const created = await createOrder(draft, authedUser);
        navigate(`/checkout/${created.id}`);
        return;
      }
      navigate('/client/dashboard');
      return;
    }
    if (role === 'worker') {
      navigate('/worker/dashboard');
      return;
    }
    navigate('/');
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setInfoMessage('');
    setIsSubmitting(true);

    try {
      const res = await login(email, password, selectedRole);
      if (!res.success) {
        setErrorMessage(res.message || 'Invalid credentials or role mismatch.');
        setIsSubmitting(false);
        return;
      }
      await routeAfterAuth(res.role, res.user);
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Unable to sign in. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setErrorMessage('');
    setInfoMessage('');
    setIsSubmitting(true);

    try {
      const res = await loginWithGoogle(selectedRole);
      if (!res.success) {
        setErrorMessage(res.message || 'Google sign-in failed.');
        setIsSubmitting(false);
        return;
      }
      await routeAfterAuth(res.role, res.user);
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Google sign-in failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setInfoMessage('');
    if (!email.trim() || !email.includes('@')) {
      setErrorMessage('Enter your registered email address first.');
      return;
    }
    setIsSubmitting(true);
    const res = await sendPasswordReset(email);
    setIsSubmitting(false);
    if (res.success) {
      setInfoMessage(res.message);
      setShowResetMode(false);
    } else {
      setErrorMessage(res.message);
    }
  };

  const handleResendVerification = async () => {
    setErrorMessage('');
    setInfoMessage('');
    setIsSubmitting(true);
    const res = await resendVerificationEmail();
    setIsSubmitting(false);
    if (res.success) {
      setInfoMessage(res.message);
    } else {
      setErrorMessage(res.message);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8 flex items-center justify-center">
      <div className="max-w-md w-full space-y-6">
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-[#0E7A4C] text-white shadow-lg mb-2">
            <ColloquiumLogoIcon className="w-8 h-8 text-white" strokeWidth={2.2} />
          </div>
          <h1 className="text-2xl font-black text-slate-900">
            Sign In to Colloquium KE
          </h1>
          <p className="text-xs text-slate-600">
            Academic, Digital &amp; Creative Services Marketplace
          </p>
        </div>

        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-md space-y-5">
          {pendingOrderDraft && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 px-4 py-2.5 rounded-lg text-xs">
              Sign in as a Client to save your pending order (<strong className="font-semibold">{pendingOrderDraft.topic}</strong>) and proceed to checkout.
            </div>
          )}

          {adminNeedsVerification && (
            <div className="bg-amber-50 border border-amber-300 text-amber-950 px-4 py-3 rounded-lg text-xs space-y-2">
              <p className="font-bold">Email verification required for Administrator access.</p>
              <p>Click the verification link sent to your email, or sign in with Google below.</p>
              <button
                type="button"
                onClick={handleResendVerification}
                disabled={isSubmitting}
                className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg text-[11px]"
              >
                Resend Verification Email
              </button>
            </div>
          )}

          {/* Exactly 2 buttons: [Login as Client] [Login as Worker] */}
          <div>
            <label className="block text-center font-bold text-slate-800 text-xs uppercase tracking-wider mb-2">
              Login as Client or Worker?
            </label>
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl border border-slate-200">
              <button
                type="button"
                onClick={() => {
                  setSelectedRole('client');
                  setErrorMessage('');
                }}
                className={`py-2.5 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  selectedRole === 'client'
                    ? 'bg-[#0E7A4C] text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <GraduationCap className="w-4 h-4" />
                <span>Login as Client</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSelectedRole('worker');
                  setErrorMessage('');
                }}
                className={`py-2.5 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  selectedRole === 'worker'
                    ? 'bg-[#0E7A4C] text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Briefcase className="w-4 h-4" />
                <span>Login as Worker</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-500 text-center mt-1.5">
              {selectedRole === 'client'
                ? 'Clients can order tasks, chat with specialists, pay securely & track delivery.'
                : 'Workers can view available tasks, track earnings, upload work & withdraw to M-Pesa.'}
            </p>
          </div>

          {errorMessage && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-2.5 rounded-lg text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {infoMessage && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-2.5 rounded-lg text-xs flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{infoMessage}</span>
            </div>
          )}

          {showResetMode ? (
            <form onSubmit={handlePasswordReset} className="space-y-4 text-xs">
              <div>
                <label htmlFor="reset-email-input" className="block font-semibold text-slate-800 mb-1">
                  Registered Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id="reset-email-input"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your account email"
                    className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowResetMode(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Back to Login
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 py-2.5 bg-[#0E7A4C] hover:bg-[#0b633d] disabled:opacity-60 text-white font-bold rounded-xl flex items-center justify-center gap-1.5"
                >
                  {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                  <span>Send Reset Link</span>
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleLogin} className="space-y-4 text-xs">
              <div>
                <label htmlFor="login-email-input" className="block font-semibold text-slate-800 mb-1">
                  {selectedRole === 'client' ? 'Client Email Address' : 'Worker Registered Email'}
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id="login-email-input"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your registered account email"
                    className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label htmlFor="login-password-input" className="font-semibold text-slate-800">
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setShowResetMode(true);
                      setErrorMessage('');
                    }}
                    className="text-[11px] text-[#0E7A4C] font-semibold hover:underline"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id="login-password-input"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0E7A4C]"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 bg-[#0E7A4C] hover:bg-[#0b633d] disabled:opacity-60 text-white font-bold text-xs rounded-xl transition shadow-sm flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Signing In...</span>
                  </>
                ) : (
                  <>
                    <span>Login as {selectedRole === 'client' ? 'Client' : 'Worker'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          )}

          <div className="relative flex items-center py-1">
            <div className="flex-grow border-t border-slate-200" />
            <span className="shrink mx-3 text-[11px] text-slate-400 font-semibold uppercase">or</span>
            <div className="flex-grow border-t border-slate-200" />
          </div>

          <button
            type="button"
            onClick={handleGoogleSignIn}
            disabled={isSubmitting}
            className="w-full py-2.5 px-4 bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 font-bold text-xs rounded-xl transition flex items-center justify-center gap-2 shadow-2xs"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24" aria-hidden="true">
              <path
                fill="#4285F4"
                d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
              />
              <path
                fill="#34A853"
                d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.11-6.72-4.96H1.29v3.14C3.26 21.3 7.31 24 12 24z"
              />
              <path
                fill="#FBBC05"
                d="M5.28 14.24c-.24-.72-.38-1.49-.38-2.24s.14-1.52.38-2.24V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.99-3.14z"
              />
              <path
                fill="#EA4335"
                d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.99 3.14c.95-2.85 3.6-4.96 6.72-4.96z"
              />
            </svg>
            <span>Continue with Google</span>
          </button>

          {/* Links for Registration only */}
          <div className="pt-2 text-center text-[11px] text-slate-500 space-x-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => navigate('/client/register')}
              className="text-[#0E7A4C] font-semibold hover:underline"
            >
              Sign up as Client
            </button>
            <span>·</span>
            <button
              type="button"
              onClick={() => navigate('/worker/register')}
              className="text-slate-700 font-semibold hover:underline"
            >
              Apply as Worker
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
