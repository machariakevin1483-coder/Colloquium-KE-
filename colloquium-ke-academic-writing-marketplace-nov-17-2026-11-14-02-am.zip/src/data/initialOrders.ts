import { AppSettings } from '../types';

export const DEFAULT_PLATFORM_SETTINGS: Omit<AppSettings, 'paybill' | 'account'> = {
  businessName: 'Colloquium KE',
  pricePerPage: 700,
  depositPercentage: 25,
  writerPercentage: 65,
  adminPercentage: 35,
  appApkLink: '',
};

export const DEFAULT_ESCROW_SETTINGS = {
  paybill: '247247',
  account: '7770187709',
  businessName: 'Colloquium KE',
};
